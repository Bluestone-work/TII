"""
RLlib 兼容的 GNN-MARL 环境包装器
支持动态图构建和增强观测
"""
import numpy as np
from typing import Dict, List, Tuple, Optional
from ray.rllib.env.multi_agent_env import MultiAgentEnv
from gymnasium import spaces
from gnn_marl_training.gnn_marl_env import GNNMARLEnv


class GNNMARLRLlibEnv(MultiAgentEnv):
    """
    RLlib MultiAgentEnv 接口的 GNN-MARL 环境
    
    关键特性:
    1. 动态图结构编码到观测中
    2. 邻居状态感知
    3. 增强的避障奖励
    """
    
    def __init__(self, config: Dict):
        super().__init__()
        
        # 创建底层环境
        self.env = GNNMARLEnv(config)
        
        # 环境配置（避免与基类属性冲突，使用不同的名称）
        self._num_agents = config.get('num_agents', 2)
        self._communication_range = config.get('communication_range', 5.0)
        
        # 定义空间
        self.observation_space = self.env.observation_space
        self.action_space = self.env.action_space
        self._agent_ids = set(self.env.agent_ids)
        
        # 奖励塑形权重（加强避障和协作）
        self.collision_penalty_weight = config.get('collision_penalty_weight', 2.0)
        self.proximity_penalty_weight = config.get('proximity_penalty_weight', 0.5)
        self.cooperation_reward_weight = config.get('cooperation_reward_weight', 0.3)
        
        # 统计信息
        self.episode_stats = {
            'total_collisions': 0,
            'near_misses': 0,
            'successful_navigations': 0
        }
    
    def reset(self, *, seed=None, options=None) -> Tuple[Dict, Dict]:
        """重置环境"""
        obs_dict, info_dict = self.env.reset(seed=seed)
        
        # 重置统计
        self.episode_stats = {
            'total_collisions': 0,
            'near_misses': 0,
            'successful_navigations': 0
        }
        
        # 为每个智能体添加图结构信息到 info
        adjacency_matrix = self.env._build_communication_graph()
        for i, aid in enumerate(self.env.agent_ids):
            info_dict[aid]['adjacency_row'] = adjacency_matrix[i]
            info_dict[aid]['robot_positions'] = self.env.robot_positions.copy()
        
        return obs_dict, info_dict
    
    def step(self, action_dict: Dict) -> Tuple[Dict, Dict, Dict, Dict, Dict]:
        """环境步进，增强奖励塑形"""
        obs_dict, rew_dict, done_dict, truncated_dict, info_dict = self.env.step(action_dict)
        
        # 增强奖励函数：加强避障和协作
        enhanced_rew_dict = self._enhance_rewards(
            rew_dict, info_dict, self.env.robot_positions
        )
        
        # 更新统计
        for aid, info in info_dict.items():
            if info.get('event') == 'collision':
                self.episode_stats['total_collisions'] += 1
            elif info.get('event') == 'goal':
                self.episode_stats['successful_navigations'] += 1
        
        # 添加 episode 统计到最终 info
        if done_dict.get("__all__"):
            for aid in self.env.agent_ids:
                info_dict[aid]['episode_stats'] = self.episode_stats.copy()
        
        return obs_dict, enhanced_rew_dict, done_dict, truncated_dict, info_dict
    
    def _enhance_rewards(
        self, 
        base_rewards: Dict, 
        info_dict: Dict,
        robot_positions: Dict
    ) -> Dict:
        """
        增强奖励函数（适配多智能体集群导航）
        
        奖励项:
        1. 距离惩罚：机器人过近时增加惩罚
        2. 碰撞加权：碰撞惩罚翻倍
        3. 协作奖励：机器人保持适当距离
        4. 速度对齐奖励：鼓励集群协同运动方向
        5. 碰撞预测惩罚：根据相对速度预测碰撞风险
        6. 激光雷达避障惩罚：近距离障碍物惩罚
        """
        enhanced_rewards = base_rewards.copy()
        
        # 获取所有机器人的位置和速度
        agent_ids = list(robot_positions.keys())
        positions = [robot_positions[aid] for aid in agent_ids]
        velocities = [self.env.robot_velocities.get(aid, np.zeros(2)) for aid in agent_ids]
        
        for i, aid_i in enumerate(agent_ids):
            if aid_i not in enhanced_rewards:
                continue
                
            proximity_penalty = 0.0
            cooperation_bonus = 0.0
            
            for j, aid_j in enumerate(agent_ids):
                if i == j:
                    continue
                
                # 计算距离
                distance = np.linalg.norm(positions[i] - positions[j])
                
                # 1. 距离惩罚（太近时）
                if distance < 1.0:  # 1米内
                    proximity_penalty += -0.5 * (1.0 - distance)
                    self.episode_stats['near_misses'] += 1
                
                # 2. 协作奖励（保持合理距离）
                if 1.0 <= distance <= self._communication_range:
                    cooperation_bonus += 0.1
                    
                    # 3. 速度方向对齐奖励（鼓励集群协同运动）
                    speed_i = np.linalg.norm(velocities[i])
                    speed_j = np.linalg.norm(velocities[j])
                    if speed_i > 0.02 and speed_j > 0.02:
                        cos_sim = np.dot(velocities[i], velocities[j]) / (speed_i * speed_j)
                        cooperation_bonus += 0.05 * max(cos_sim, 0.0)
                
                # 4. 碰撞预测惩罚（基于相对速度判断碰撞风险）
                if distance < 2.0:
                    rel_pos = positions[j] - positions[i]
                    rel_vel = velocities[j] - velocities[i]
                    # 如果正在接近（相对速度指向对方）
                    closing_rate = -np.dot(rel_pos, rel_vel) / (distance + 1e-6)
                    if closing_rate > 0.05:  # 正在快速接近
                        proximity_penalty += -0.15 * closing_rate
            
            # 5. 碰撞惩罚加权
            if aid_i in info_dict:
                info = info_dict[aid_i]
                if info.get('event') == 'collision':
                    enhanced_rewards[aid_i] *= self.collision_penalty_weight
                
                # 6. 激光雷达最小距离惩罚（加强避障）
                min_lidar_dist = info.get('min_dist', 1.0)
                if min_lidar_dist < 0.3:  # 30cm内有障碍物
                    proximity_penalty += -0.2 * (0.3 - min_lidar_dist)
            
            # 应用增强奖励
            enhanced_rewards[aid_i] += (
                proximity_penalty * self.proximity_penalty_weight +
                cooperation_bonus * self.cooperation_reward_weight
            )
        
        return enhanced_rewards
    
    def render(self, mode='human'):
        """渲染（Gazebo自动渲染）"""
        pass
    
    def close(self):
        """关闭环境"""
        self.env.close()


# 环境创建函数（用于 Ray 注册）
def env_creator(env_config):
    return GNNMARLRLlibEnv(env_config)
