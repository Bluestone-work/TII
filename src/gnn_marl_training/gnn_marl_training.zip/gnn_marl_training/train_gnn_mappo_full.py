#!/usr/bin/env python3
"""
GNN-MAPPO 完整训练脚本
基于 RLlib 的多智能体图神经网络强化学习
"""
import ray
from ray import tune
from ray.rllib.algorithms.ppo import PPOConfig
from ray.tune.registry import register_env
from ray.rllib.models import ModelCatalog
import argparse
import os

from gnn_marl_training.gnn_marl_rllib_env import env_creator
from gnn_marl_training.gat_rllib_model import GATRLlibModel, MODEL_NAME


def main():
    parser = argparse.ArgumentParser(description="GNN-MAPPO Training")
    parser.add_argument("--num_agents", type=int, default=2, help="机器人数量")
    parser.add_argument("--communication_range", type=float, default=5.0, help="通信范围(米)")
    parser.add_argument("--num_workers", type=int, default=2, help="并行worker数量")
    parser.add_argument("--train_steps", type=int, default=500000, help="总训练步数")
    parser.add_argument("--checkpoint_freq", type=int, default=20, help="Checkpoint保存频率")
    parser.add_argument("--lr", type=float, default=1e-4, help="学习率")  # 降低学习率：3e-4 -> 1e-4
    parser.add_argument("--train_batch_size", type=int, default=4000, help="训练batch大小")
    parser.add_argument("--enable_neighbor_obs", action="store_true", default=True, help="启用邻居观测")
    parser.add_argument("--collision_penalty_weight", type=float, default=2.0, help="碰撞惩罚权重")
    parser.add_argument("--proximity_penalty_weight", type=float, default=0.5, help="接近惩罚权重")
    parser.add_argument("--cooperation_reward_weight", type=float, default=0.3, help="协作奖励权重")
    args = parser.parse_args()
    
    print(f"{'='*80}")
    print(f"🚀 GNN-MAPPO 训练")
    print(f"{'='*80}")
    print(f"配置:")
    print(f"  机器人数量: {args.num_agents}")
    print(f"  通信范围: {args.communication_range}m")
    print(f"  并行Workers: {args.num_workers}")
    print(f"  训练步数: {args.train_steps:,}")
    print(f"  学习率: {args.lr}")
    print(f"  Batch大小: {args.train_batch_size}")
    print(f"增强奖励:")
    print(f"  碰撞惩罚权重: {args.collision_penalty_weight}")
    print(f"  接近惩罚权重: {args.proximity_penalty_weight}")
    print(f"  协作奖励权重: {args.cooperation_reward_weight}")
    print(f"{'='*80}\n")
    
    # 初始化 Ray
    if ray.is_initialized():
        ray.shutdown()
    ray.init()
    
    # 1. 注册环境
    register_env("gnn_marl", env_creator)
    
    # 2. 注册自定义模型
    ModelCatalog.register_custom_model(MODEL_NAME, GATRLlibModel)
    
    # 3. 配置环境参数
    env_config = {
        "num_agents": args.num_agents,
        "map_number": 3,
        "max_episode_steps": 1000,
        "communication_range": args.communication_range,
        "enable_neighbor_obs": args.enable_neighbor_obs,
        "enable_local_map": False,
        # 奖励塑形
        "collision_penalty_weight": args.collision_penalty_weight,
        "proximity_penalty_weight": args.proximity_penalty_weight,
        "cooperation_reward_weight": args.cooperation_reward_weight,
    }
    
    # 4. 配置 PPO 算法
    policy_name = "shared_policy"
    
    config = (
        PPOConfig()
        .environment(
            env="gnn_marl",
            env_config=env_config,
            disable_env_checking=True
        )
        .framework("torch")
        .env_runners(
            num_env_runners=args.num_workers,
            num_envs_per_env_runner=1,
            sample_timeout_s=600,
            # 【重要】启用完整 episodes 采样（LSTM需要）
            batch_mode="complete_episodes"
        )
        .training(
            lr=args.lr,
            gamma=0.99,
            lambda_=0.95,
            train_batch_size=args.train_batch_size,
            # 注意：新版 RLlib 不再在 .training() 中设置这些参数
            clip_param=0.2,
            entropy_coeff=0.01,
            vf_clip_param=50.0,
            # 【关键】梯度裁剪，防止梯度爆炸
            grad_clip=0.5,
            grad_clip_by="global_norm",
            # 自定义模型配置
            model={
                "custom_model": MODEL_NAME,
                "custom_model_config": {
                    "num_agents": args.num_agents,
                    "max_neighbors": min(args.num_agents - 1, 5),
                    "hidden_dim": 128,
                    "gat_hidden_dim": 128,
                    "lstm_hidden_dim": 256,
                    "n_gat_heads": 4,
                },
                # LSTM配置
                "use_lstm": False,  # 我们在自定义模型中已经有LSTM了
                "max_seq_len": 20,
            }
        )
        .multi_agent(
            policies={
                policy_name: (None, None, None, {})
            },
            policy_mapping_fn=lambda agent_id, episode=None, worker=None, **kwargs: policy_name,
            policies_to_train=[policy_name],
        )
        .resources(
            num_gpus=1  # 如果有GPU
        )
        .api_stack(
            enable_rl_module_and_learner=False,
            enable_env_runner_and_connector_v2=False
        )
    )
    
    # 【修复】手动设置 PPO 特定参数（绕过新版API限制）
    config.sgd_minibatch_size = 256
    config.num_sgd_iter = 10
    
    print("✅ 配置完成，开始训练...\n")
    
    # 5. 启动训练
    tuner = tune.Tuner(
        "PPO",
        param_space=config.to_dict(),
        run_config=tune.RunConfig(
            name="GNN_MAPPO_Enhanced",
            stop={"timesteps_total": args.train_steps},
            storage_path=os.path.abspath("./ray_results"),
            checkpoint_config=tune.CheckpointConfig(
                checkpoint_frequency=args.checkpoint_freq,
                checkpoint_at_end=True,
                num_to_keep=5,  # 保留最近5个checkpoint
            ),
            # 日志配置
            verbose=1,
        ),
    )
    
    results = tuner.fit()
    
    # 6. 打印结果
    best_result = results.get_best_result(metric="episode_reward_mean", mode="max")
    print(f"\n{'='*80}")
    print(f"✅ 训练完成！")
    print(f"{'='*80}")
    print(f"最佳结果:")
    print(f"  平均回报: {best_result.metrics.get('episode_reward_mean', 0):.2f}")
    print(f"  训练步数: {best_result.metrics.get('timesteps_total', 0):,}")
    print(f"  Checkpoint: {best_result.checkpoint}")
    print(f"{'='*80}\n")
    
    ray.shutdown()


if __name__ == "__main__":
    main()
