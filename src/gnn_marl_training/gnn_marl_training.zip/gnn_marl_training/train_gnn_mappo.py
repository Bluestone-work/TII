#!/usr/bin/env python3
"""
GNN-MAPPO 训练脚本
第一阶段：基础架构验证
"""
import torch
import numpy as np
import argparse
from gnn_marl_training.gnn_marl_env import GNNMARLEnv
from gnn_marl_training.gat_policy import GATPolicy


def main():
    parser = argparse.ArgumentParser(description="GNN-MAPPO Training (Phase 1: Architecture Validation)")
    parser.add_argument("--num_agents", type=int, default=2, help="机器人数量")
    parser.add_argument("--communication_range", type=float, default=5.0, help="通信范围(米)")
    parser.add_argument("--test_episodes", type=int, default=5, help="测试回合数")
    args = parser.parse_args()
    
    print(f"{'='*60}")
    print(f"🚀 GNN-MAPPO 架构验证")
    print(f"{'='*60}")
    print(f"机器人数量: {args.num_agents}")
    print(f"通信范围: {args.communication_range}m")
    print(f"测试回合数: {args.test_episodes}")
    print(f"{'='*60}\n")
    
    # 1. 创建环境
    env_config = {
        'num_agents': args.num_agents,
        'map_number': 3,
        'max_episode_steps': 1000,
        'communication_range': args.communication_range,
        'enable_neighbor_obs': True,
        'enable_local_map': False
    }
    
    print("📦 创建 GNN-MARL 环境...")
    env = GNNMARLEnv(env_config)
    
    # 2. 创建策略网络
    obs_dim = env.observation_space.shape[0]
    print(f"   观测维度: {obs_dim}")
    print(f"   - 基础观测: {env.base_obs_dim}")
    print(f"   - 邻居信息: {env.neighbor_dim}")
    print(f"   - 局部地图: {env.local_map_dim}")
    
    policy = GATPolicy(obs_dim=obs_dim, action_dim=2)
    print(f"✅ 策略网络创建成功 (参数量: {sum(p.numel() for p in policy.parameters())})")
    
    # 3. 测试环境和网络交互
    print(f"\n{'='*60}")
    print(f"开始测试...")
    print(f"{'='*60}\n")
    
    for ep in range(args.test_episodes):
        print(f"🎬 Episode {ep + 1}/{args.test_episodes}")
        
        obs_dict, info_dict = env.reset()
        dones = {"__all__": False}
        
        # 初始化LSTM状态
        lstm_states = {
            aid: policy.init_hidden_state(1) 
            for aid in env.agent_ids
        }
        
        step_count = 0
        total_neighbors = 0
        
        while not dones["__all__"] and step_count < 100:  # 限制步数
            # 收集观测和邻接矩阵
            obs_list = []
            for aid in env.agent_ids:
                if aid in obs_dict:
                    obs_list.append(obs_dict[aid])
                else:
                    obs_list.append(np.zeros(obs_dim))
            
            obs_tensor = torch.FloatTensor(np.array(obs_list))  # [n_agents, obs_dim]
            
            # 构建邻接矩阵
            adj_matrix = env._build_communication_graph()
            adj_tensor = torch.FloatTensor(adj_matrix).unsqueeze(0)  # [1, n_agents, n_agents]
            
            # 获取动作
            action_dict = {}
            obs_batch = obs_tensor.unsqueeze(0)  # [1, n_agents, obs_dim]
            
            with torch.no_grad():
                action_mean, _, _ = policy(obs_batch, adj_tensor)
            
            actions = action_mean.cpu().numpy()  # [n_agents, 2]
            
            for i, aid in enumerate(env.agent_ids):
                action_dict[aid] = actions[i]
            
            # 环境步进
            obs_dict, rewards, dones, truncateds, infos = env.step(action_dict)
            
            step_count += 1
            
            # 统计邻居数量
            for aid in env.agent_ids:
                if aid in infos:
                    total_neighbors += infos[aid].get('num_neighbors', 0)
        
        avg_neighbors = total_neighbors / (step_count * args.num_agents) if step_count > 0 else 0
        print(f"   步数: {step_count}")
        print(f"   平均邻居数: {avg_neighbors:.2f}/{args.num_agents-1}")
        print(f"   结束原因: {'超时' if truncateds.get('__all__') else '完成'}")
        print()
    
    env.close()
    
    print(f"{'='*60}")
    print(f"✅ 架构验证完成！")
    print(f"{'='*60}")
    print(f"\n下一步:")
    print(f"1. 集成 RLlib 训练循环")
    print(f"2. 实现完整的 GNN-MAPPO 算法")
    print(f"3. 对比 Baseline MAPPO 性能")


if __name__ == "__main__":
    main()
