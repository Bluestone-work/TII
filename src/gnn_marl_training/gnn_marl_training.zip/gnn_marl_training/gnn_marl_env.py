"""
GNN-MAPPO 环境包装器
基于动态图神经网络的多智能体强化学习环境
"""
import numpy as np
from typing import Dict, List, Tuple, Optional
import torch
import torch.nn as nn
from gymnasium import spaces

# 复用 baseline 环境
from marl_training.independent_env import IndependentRobotEnv


class GNNMARLEnv:
    """
    GNN-MAPPO 环境包装器
    
    核心特性：
    1. 动态图构建：只连接近距离机器人
    2. 消息传递：机器人间信息交换
    3. 增强观测：局部地图 + 邻居状态
    """
    
    def __init__(self, config: Dict):
        self.num_agents = config.get('num_agents', 3)
        self.communication_range = config.get('communication_range', 5.0)  # 米
        self.enable_local_map = config.get('enable_local_map', False)
        self.enable_neighbor_obs = config.get('enable_neighbor_obs', True)
        
        # 创建独立环境实例
        self.agents = {}
        for i in range(self.num_agents):
            self.agents[f"agent_{i}"] = IndependentRobotEnv(
                robot_id=i,
                map_number=config.get('map_number', 3),
                max_episode_steps=config.get('max_episode_steps', 1000)
            )
        
        self.agent_ids = list(self.agents.keys())
        self.current_step_count = 0
        self.max_steps = config.get('max_episode_steps', 1000)
        self.dones = set()  # 已完成的智能体
        
        # 机器人位置缓存（用于构建图）
        self.robot_positions = {aid: np.zeros(2) for aid in self.agent_ids}
        # 机器人速度缓存（用于协作奖励和碰撞预测）
        self.robot_velocities = {aid: np.zeros(2) for aid in self.agent_ids}
        
        # 定义增强后的观测空间
        self._define_observation_space()
        
        # 定义动作空间（与 IndependentRobotEnv 一致: [-1,1]x[-1,1]）
        # 底层环境自动映射: linear_vel=(a[0]+1)/2*0.22, angular_vel=a[1]*1.0
        self.action_space = spaces.Box(
            low=np.array([-1.0, -1.0]),
            high=np.array([1.0, 1.0]),
            dtype=np.float32
        )
    
    def _define_observation_space(self):
        """定义观测空间"""
        # 基础观测: 36 lidar + 2 target + 2 velocity = 40
        base_obs_dim = 40
        
        # 可选：邻居状态（最多 K 个近邻）
        if self.enable_neighbor_obs:
            # 【修复】最多邻居数 = min(其他机器人数量, 5)
            max_neighbors = min(self.num_agents - 1, 5)  # 2个机器人时 = min(1, 5) = 1
            # 每个邻居: 相对位置(2) + 相对速度(2) + 距离(1) = 5
            neighbor_dim = max_neighbors * 5
        else:
            neighbor_dim = 0
        
        # 可选：局部地图（暂时不实现，预留）
        if self.enable_local_map:
            local_map_dim = 128  # CNN编码后的特征维度
        else:
            local_map_dim = 0
        
        total_dim = base_obs_dim + neighbor_dim + local_map_dim
        
        self.observation_space = spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(total_dim,),
            dtype=np.float32
        )
        
        self.base_obs_dim = base_obs_dim
        self.neighbor_dim = neighbor_dim
        self.local_map_dim = local_map_dim
    
    def reset(self, seed=None) -> Tuple[Dict, Dict]:
        """重置环境"""
        self.current_step_count = 0
        self.dones = set()
        
        obs_dict = {}
        info_dict = {}
        
        # 先收集基础观测并更新位置
        base_obs_dict = {}
        for aid, agent in self.agents.items():
            obs, info = agent.reset()
            base_obs_dict[aid] = obs
            # 更新位置缓存
            self.robot_positions[aid] = self._get_robot_position(agent)
            self.robot_velocities[aid] = self._get_robot_velocity(agent)
            info_dict[aid] = info
        
        # 构建通信图
        adjacency_matrix = self._build_communication_graph()
        
        # 构建增强观测（包含邻居信息）
        for aid in self.agent_ids:
            obs_dict[aid] = self._build_enhanced_observation(
                aid, base_obs_dict[aid], adjacency_matrix
            )
        
        return obs_dict, info_dict
    
    def step(self, action_dict: Dict) -> Tuple[Dict, Dict, Dict, Dict, Dict]:
        """环境步进"""
        self.current_step_count += 1
        
        obs_dict = {}
        rew_dict = {}
        done_dict = {}
        truncated_dict = {}
        info_dict = {}
        
        # 1. 执行动作并收集基础观测
        for aid in self.agent_ids:
            if aid not in self.dones:
                if aid in action_dict:
                    obs, rew, done, truncated, info = self.agents[aid].step(action_dict[aid])
                    
                    # 更新位置和速度缓存
                    self.robot_positions[aid] = self._get_robot_position(self.agents[aid])
                    self.robot_velocities[aid] = self._get_robot_velocity(self.agents[aid])
                    
                    # 记录完成状态
                    if info.get('need_reset', False) or done:
                        if aid not in self.dones:
                            self.dones.add(aid)
                        done_dict[aid] = False  # 保持 trajectory 连续
                        truncated_dict[aid] = False
                    else:
                        done_dict[aid] = False
                        truncated_dict[aid] = False
                    
                    obs_dict[aid] = obs  # 暂存基础观测
                    rew_dict[aid] = rew
                    info_dict[aid] = info
                else:
                    obs_dict[aid] = self.agents[aid]._get_obs()
                    rew_dict[aid] = 0.0
                    done_dict[aid] = False
                    truncated_dict[aid] = False
                    info_dict[aid] = {'warning': 'no_action_received'}
            else:
                obs_dict[aid] = self.agents[aid]._get_obs()
                rew_dict[aid] = 0.0
                done_dict[aid] = False
                truncated_dict[aid] = False
                info_dict[aid] = {'status': 'waiting'}
        
        # 2. 构建通信图
        adjacency_matrix = self._build_communication_graph()
        
        # 3. 为每个智能体构建增强观测（包含邻居信息）
        enhanced_obs_dict = {}
        for aid in self.agent_ids:
            enhanced_obs = self._build_enhanced_observation(
                aid, obs_dict[aid], adjacency_matrix
            )
            enhanced_obs_dict[aid] = enhanced_obs
        
        # 4. 添加图信息到 info
        for aid in self.agent_ids:
            neighbors = np.where(adjacency_matrix[int(aid.split('_')[1])] > 0)[0]
            info_dict[aid]['neighbors'] = [f"agent_{n}" for n in neighbors]
            info_dict[aid]['num_neighbors'] = len(neighbors)
        
        # 5. 全局终止逻辑
        all_done = (len(self.dones) == self.num_agents)
        timeout = (self.current_step_count >= self.max_steps)
        
        done_dict["__all__"] = all_done or timeout
        truncated_dict["__all__"] = timeout
        
        if done_dict["__all__"]:
            for aid in self.agent_ids:
                if aid in self.dones:
                    done_dict[aid] = True
                    info_dict[aid]['episode_complete'] = True
                else:
                    done_dict[aid] = False
                    info_dict[aid]['episode_incomplete'] = True
                
                if timeout:
                    truncated_dict[aid] = True
        
        return enhanced_obs_dict, rew_dict, done_dict, truncated_dict, info_dict
    
    def _build_communication_graph(self) -> np.ndarray:
        """
        构建动态通信图
        返回: adjacency_matrix [n_agents, n_agents]
        """
        n = self.num_agents
        adjacency = np.zeros((n, n))
        
        positions = [self.robot_positions[f"agent_{i}"] for i in range(n)]
        
        for i in range(n):
            for j in range(i+1, n):
                distance = np.linalg.norm(positions[i] - positions[j])
                if distance < self.communication_range:
                    adjacency[i, j] = 1.0
                    adjacency[j, i] = 1.0
        
        # 添加自环（GAT中每个节点需要关注自身信息）
        np.fill_diagonal(adjacency, 1.0)
        
        return adjacency
    
    def _build_enhanced_observation(
        self, 
        agent_id: str, 
        base_obs: np.ndarray,
        adjacency_matrix: Optional[np.ndarray] = None
    ) -> np.ndarray:
        """
        构建增强观测
        
        组成:
        1. 基础观测: lidar + target + velocity (40维)
        2. 邻居状态: K个近邻的相对状态 (K*5维)
        3. 局部地图: CNN编码特征 (128维，暂未实现)
        """
        components = [base_obs]
        
        # 添加邻居信息
        if self.enable_neighbor_obs and adjacency_matrix is not None:
            neighbor_obs = self._encode_neighbor_states(agent_id, adjacency_matrix)
            components.append(neighbor_obs)
        
        # TODO: 添加局部地图
        # if self.enable_local_map:
        #     local_map_features = self._encode_local_map(agent_id)
        #     components.append(local_map_features)
        
        return np.concatenate(components)
    
    def _encode_neighbor_states(
        self, 
        agent_id: str, 
        adjacency_matrix: np.ndarray
    ) -> np.ndarray:
        """
        编码邻居状态
        
        对于每个邻居，编码:
        - 相对位置 (2维)
        - 相对速度 (2维)
        - 距离 (1维)
        """
        agent_idx = int(agent_id.split('_')[1])
        my_pos = self.robot_positions[agent_id]
        my_vel = self._get_robot_velocity(self.agents[agent_id])
        
        # 找到邻居
        neighbor_indices = np.where(adjacency_matrix[agent_idx] > 0)[0]
        
        max_neighbors = min(self.num_agents - 1, 5)
        neighbor_features = []
        
        # 按距离排序邻居
        neighbor_distances = []
        for n_idx in neighbor_indices:
            n_id = f"agent_{n_idx}"
            n_pos = self.robot_positions[n_id]
            dist = np.linalg.norm(my_pos - n_pos)
            neighbor_distances.append((dist, n_id))
        
        neighbor_distances.sort(key=lambda x: x[0])
        
        # 编码最近的 K 个邻居
        for i in range(max_neighbors):
            if i < len(neighbor_distances):
                _, n_id = neighbor_distances[i]
                n_pos = self.robot_positions[n_id]
                n_vel = self._get_robot_velocity(self.agents[n_id])
                
                relative_pos = n_pos - my_pos
                relative_vel = n_vel - my_vel
                distance = np.linalg.norm(relative_pos)
                
                features = np.concatenate([
                    relative_pos,
                    relative_vel,
                    [distance]
                ])
            else:
                # 填充零向量
                features = np.zeros(5)
            
            neighbor_features.append(features)
        
        return np.concatenate(neighbor_features)
    
    def _get_robot_position(self, agent: IndependentRobotEnv) -> np.ndarray:
        """获取机器人位置"""
        if hasattr(agent, 'odom_x') and hasattr(agent, 'odom_y'):
            return np.array([agent.odom_x, agent.odom_y])
        else:
            return np.zeros(2)
    
    def _get_robot_velocity(self, agent: IndependentRobotEnv) -> np.ndarray:
        """获取机器人全局坐标系下的速度（使不同机器人速度可比较）"""
        if hasattr(agent, 'linear_x') and hasattr(agent, 'yaw'):
            # 将局部坐标系的速度转换到全局坐标系
            vx = agent.linear_x * np.cos(agent.yaw)
            vy = agent.linear_x * np.sin(agent.yaw)
            return np.array([vx, vy])
        else:
            return np.zeros(2)
    
    def close(self):
        """关闭环境"""
        for agent in self.agents.values():
            if hasattr(agent, 'close'):
                agent.close()
