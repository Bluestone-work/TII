#!/usr/bin/env python3
"""
GNN-MAPPO 测试脚本
"""
import ray
from ray.rllib.algorithms.ppo import PPOConfig
from ray.tune.registry import register_env
from ray.rllib.models import ModelCatalog
import argparse
import os
import numpy as np
import time

from gnn_marl_training.gnn_marl_rllib_env import env_creator, GNNMARLRLlibEnv
from gnn_marl_training.gat_rllib_model import GATRLlibModel, MODEL_NAME


def main():
    parser = argparse.ArgumentParser(description="GNN-MAPPO Testing")
    parser.add_argument("--checkpoint_path", type=str, required=True, help="模型Checkpoint路径")
    parser.add_argument("--num_agents", type=int, default=2, help="机器人数量")
    parser.add_argument("--num_episodes", type=int, default=5, help="测试回合数")
    parser.add_argument("--communication_range", type=float, default=5.0, help="通信范围")
    parser.add_argument("--enable_neighbor_obs", type=bool, default=True, help="启用邻居观测")
    args = parser.parse_args()
    
    # 转换为绝对路径
    checkpoint_path = os.path.abspath(os.path.expanduser(args.checkpoint_path))
    
    if not os.path.exists(checkpoint_path):
        print(f"❌ 找不到checkpoint: {checkpoint_path}", flush=True)
        return
    
    print(f"{'='*80}", flush=True)
    print(f"🧪 GNN-MAPPO 测试", flush=True)
    print(f"{'='*80}", flush=True)
    print(f"Checkpoint: {checkpoint_path}", flush=True)
    print(f"机器人数量: {args.num_agents}", flush=True)
    print(f"测试回合: {args.num_episodes}", flush=True)
    print(f"{'='*80}\n", flush=True)
    
    # 初始化 Ray
    print("🔧 初始化 Ray...", flush=True)
    if ray.is_initialized():
        ray.shutdown()
    ray.init(local_mode=True, ignore_reinit_error=True, log_to_driver=False)
    print("✅ Ray 初始化完成", flush=True)
    
    # 注册环境和模型
    print("📦 注册环境和模型...", flush=True)
    register_env("gnn_marl", env_creator)
    ModelCatalog.register_custom_model(MODEL_NAME, GATRLlibModel)
    print("✅ 注册完成", flush=True)
    
    # 重建配置
    policy_name = "shared_policy"
    env_config = {
        "num_agents": args.num_agents,
        "map_number": 3,
        "max_episode_steps": 1000,
        "communication_range": args.communication_range,
        "enable_neighbor_obs": args.enable_neighbor_obs,
        "enable_local_map": False,
        "collision_penalty_weight": 2.0,
        "proximity_penalty_weight": 0.5,
        "cooperation_reward_weight": 0.3,
    }
    
    config = (
        PPOConfig()
        .environment(
            env="gnn_marl",
            env_config=env_config,
            disable_env_checking=True
        )
        .framework("torch")
        .resources(num_gpus=0)
        .env_runners(
            num_env_runners=0,
            batch_mode="complete_episodes"  # 【重要】与训练时保持一致
        )
        .multi_agent(
            policies={policy_name: (None, None, None, {})},
            policy_mapping_fn=lambda agent_id, **kwargs: policy_name,
            policies_to_train=[policy_name],
        )
        .training(
            model={
                "custom_model": MODEL_NAME,
                "custom_model_config": {
                    "num_agents": args.num_agents,
                    "max_neighbors": min(args.num_agents - 1, 5),
                    "hidden_dim": 128,
                    "gat_hidden_dim": 128,
                    "lstm_hidden_dim": 256,
                    "n_gat_heads": 4,
                },
                "use_lstm": False,
                "max_seq_len": 20,
            }
        )
        .api_stack(
            enable_rl_module_and_learner=False,
            enable_env_runner_and_connector_v2=False
        )
    )
    
    # 加载模型
    print("📥 构建算法配置...", flush=True)
    algo = config.build()
    print(f"📥 从 checkpoint 加载模型...", flush=True)
    print(f"   路径: {checkpoint_path}", flush=True)
    algo.restore(checkpoint_path)
    print("✅ 模型加载成功\n", flush=True)
    print("🌍 创建测试环境...", flush=True)
    env = GNNMARLRLlibEnv(env_config)
    print("✅ 环境创建成功\n", flush=True)
    
    # 测试
    episode_stats = []
    
    try:
        for ep in range(args.num_episodes):
            print(f"{'='*80}", flush=True)
            print(f"🎬 Episode {ep + 1}/{args.num_episodes}", flush=True)
            
            obs_dict, _ = env.reset()
            dones = {"__all__": False}
            
            total_rewards = {f"agent_{i}": 0.0 for i in range(args.num_agents)}
            agent_completed = {f"agent_{i}": False for i in range(args.num_agents)}
            agent_collided = {f"agent_{i}": False for i in range(args.num_agents)}
            step_count = 0
            
            # 【重要】初始化LSTM状态
            states = {aid: algo.get_policy(policy_name).get_initial_state() 
                     for aid in [f"agent_{i}" for i in range(args.num_agents)]}
            
            while not dones["__all__"] and step_count < 1000:
                action_dict = {}
                
                for aid in [f"agent_{i}" for i in range(args.num_agents)]:
                    if aid in obs_dict:
                        # 【重要】传递LSTM状态
                        action, state_out, _ = algo.compute_single_action(
                            observation=obs_dict[aid],
                            state=states[aid],
                            policy_id=policy_name,
                            explore=False
                        )
                        action_dict[aid] = action
                        states[aid] = state_out  # 更新状态
                
                obs_dict, rewards, dones, truncateds, infos = env.step(action_dict)
                step_count += 1
                
                for aid, r in rewards.items():
                    total_rewards[aid] += r
                    
                    if aid in infos:
                        if infos[aid].get('episode_complete'):
                            agent_completed[aid] = True
                            print(f"✅ {aid} 到达目标 (步数: {step_count})", flush=True)
                        elif infos[aid].get('event') == 'collision':
                            agent_collided[aid] = True
                            print(f"💥 {aid} 碰撞 (步数: {step_count})", flush=True)
                
                if step_count % 50 == 0:
                    print(f"Step {step_count}...", end="\r")
            
            # 统计
            completed = sum(agent_completed.values())
            collided = sum(agent_collided.values())
            
            print(f"\n{'='*80}", flush=True)
            print(f"📊 Episode {ep + 1} 结果:", flush=True)
            print(f"   总步数: {step_count}", flush=True)
            print(f"   成功/总数: {completed}/{args.num_agents} ({100*completed/args.num_agents:.1f}%)", flush=True)
            print(f"   碰撞数: {collided}", flush=True)
            print(f"   平均奖励: {sum(total_rewards.values())/args.num_agents:.2f}", flush=True)
            print(f"{'='*80}\n", flush=True)
            
            episode_stats.append({
                'steps': step_count,
                'completed': completed,
                'collided': collided,
                'avg_reward': sum(total_rewards.values())/args.num_agents
            })
            
            time.sleep(1.0)
        
        # 总体统计
        print(f"\n{'='*80}", flush=True)
        print(f"📈 总体测试结果 ({args.num_episodes} Episodes)", flush=True)
        print(f"{'='*80}", flush=True)
        avg_success = sum(s['completed'] for s in episode_stats) / len(episode_stats)
        avg_steps = sum(s['steps'] for s in episode_stats) / len(episode_stats)
        avg_reward = sum(s['avg_reward'] for s in episode_stats) / len(episode_stats)
        total_collisions = sum(s['collided'] for s in episode_stats)
        
        print(f"   平均成功率: {avg_success:.2f}/{args.num_agents} ({100*avg_success/args.num_agents:.1f}%)", flush=True)
        print(f"   平均步数: {avg_steps:.1f}", flush=True)
        print(f"   平均奖励: {avg_reward:.2f}", flush=True)
        print(f"   总碰撞数: {total_collisions}", flush=True)
        print(f"{'='*80}\n", flush=True)
        
    except KeyboardInterrupt:
        print("\n🛑 测试中断", flush=True)
    finally:
        env.close()
        ray.shutdown()


if __name__ == "__main__":
    main()

