"""
面向多智能体数量泛化的增强型Hierarchical GAT Critic

【设计思路 2026-07-04】

## 核心问题：如何准确估计不同车数组合下的状态价值？

### 1. 价值函数定义的困境

传统MAPPO的集中式critic估计 V(s_global)，但存在车数依赖问题：
- 集中式总价值: V_total = E[Σ_i r_i]  → 随车数线性增长
- 人均价值: V_avg = E[1/N Σ_i r_i]      → 车数不敏感，但忽略协作收益

### 2. 混合价值估计方案

本实现采用**分解式价值估计**：

V_total = N * V_base + V_coop + V_context

其中：
- V_base: 基础人均价值（单车期望收益）
- V_coop: 协作奖励（团队协同带来的超额收益）
- V_context: 场景修正项（障碍物密度、地图复杂度等）

### 3. 关键设计

#### 3.1 车数感知 (Num-Agent Aware)
- Embedding层编码当前车数 (1-8)
- 动态调整价值尺度
- 训练时数据增强：随机mask智能体

#### 3.2 场景编码 (Context Encoding)
- 障碍物密度: n_obstacles / map_area
- 地图复杂度: 通道宽度、拓扑结构
- 任务进度: 已完成目标数 / 总车数

#### 3.3 协作建模 (Cooperation Modeling)
- 边际贡献: Shapley value思想，每个智能体的增量价值
- 协同效应: 使用GAT的全局pooling捕捉team coordination

#### 3.4 价值归一化 (Value Normalization)
- Running mean/std for value targets
- 车数分组归一化（2车/4车/6车/8车分别统计）

### 4. 训练策略

- Curriculum: 逐步增加车数 (2→4→6→8)
- Data augmentation: 每个batch随机mask 0-2个智能体
- Multi-task: 同时优化不同车数的子任务

---

## 使用示例

```python
critic = EnhancedHierarchicalGATCritic(
    obs_dim=50,
    hidden_dim=256,
    max_num_agents=8,
    value_decomposition='hybrid',  # 'total' | 'average' | 'hybrid'
    use_context_encoding=True,
    use_value_normalization=True,
)

# 前向传播
value = critic(
    global_obs,          # [batch, num_agents, obs_dim]
    node_mask,           # [batch, num_agents]
    context={            # 可选场景上下文
        'num_obstacles': torch.tensor([6, 8, 4, 6]),
        'map_size': 20.0,
        'goal_reached_ratio': torch.tensor([0.0, 0.25, 0.5, 0.75]),
    }
)
```

---

作者: Kiro Code Assistant
日期: 2026-07-04
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Dict, Tuple
import math


class ContextEncoder(nn.Module):
    """
    场景上下文编码器

    编码影响价值函数的环境因素：
    - 障碍物密度
    - 地图大小
    - 任务进度
    """
    def __init__(self, hidden_dim: int = 64):
        super().__init__()
        self.hidden_dim = hidden_dim

        # 场景特征编码
        self.encoder = nn.Sequential(
            nn.Linear(3, hidden_dim),  # [num_obstacles, map_size, goal_ratio]
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
        )

    def forward(self, context: Optional[Dict[str, torch.Tensor]] = None) -> torch.Tensor:
        """
        Args:
            context: {
                'num_obstacles': [batch] or scalar
                'map_size': scalar (meters)
                'goal_reached_ratio': [batch] (0.0-1.0)
            }

        Returns:
            context_feat: [batch, hidden_dim]
        """
        if context is None:
            # 返回零向量（无场景信息）
            batch_size = 1
            return torch.zeros(batch_size, self.hidden_dim)

        # 提取特征
        num_obstacles = context.get('num_obstacles', torch.tensor([0.0]))
        map_size = context.get('map_size', 20.0)
        goal_ratio = context.get('goal_reached_ratio', torch.tensor([0.0]))

        # 确保是tensor
        if not isinstance(num_obstacles, torch.Tensor):
            num_obstacles = torch.tensor([num_obstacles], dtype=torch.float32)
        if not isinstance(goal_ratio, torch.Tensor):
            goal_ratio = torch.tensor([goal_ratio], dtype=torch.float32)

        batch_size = num_obstacles.shape[0]
        device = num_obstacles.device

        # 归一化特征
        obstacle_density = num_obstacles / (map_size ** 2) * 100  # 每100m²的障碍物数
        map_scale = torch.full((batch_size,), map_size / 20.0, device=device)  # 相对20m标准地图

        # 拼接 [batch, 3]
        features = torch.stack([
            obstacle_density,
            map_scale,
            goal_ratio
        ], dim=1)

        return self.encoder(features)


class ValueNormalizer(nn.Module):
    """
    车数分组的价值归一化器

    为不同车数维护独立的running mean/std，
    避免车数变化时价值尺度漂移
    """
    def __init__(self, max_num_agents: int = 8, momentum: float = 0.99):
        super().__init__()
        self.max_num_agents = max_num_agents
        self.momentum = momentum

        # 为每个车数维护独立的统计量
        self.register_buffer('value_mean', torch.zeros(max_num_agents))
        self.register_buffer('value_std', torch.ones(max_num_agents))
        self.register_buffer('value_count', torch.zeros(max_num_agents))

    def update(self, values: torch.Tensor, num_agents: torch.Tensor):
        """
        更新running statistics

        Args:
            values: [batch] 价值预测
            num_agents: [batch] 每个样本的实际车数
        """
        if not self.training:
            return

        with torch.no_grad():
            for n in range(1, self.max_num_agents + 1):
                mask = (num_agents == n)
                if mask.sum() == 0:
                    continue

                # 当前车数的样本
                vals = values[mask]
                batch_mean = vals.mean()
                batch_std = vals.std() + 1e-8

                # 更新running stats
                idx = n - 1
                self.value_mean[idx] = (
                    self.momentum * self.value_mean[idx] +
                    (1 - self.momentum) * batch_mean
                )
                self.value_std[idx] = (
                    self.momentum * self.value_std[idx] +
                    (1 - self.momentum) * batch_std
                )
                self.value_count[idx] += mask.sum()

    def normalize(self, values: torch.Tensor, num_agents: torch.Tensor) -> torch.Tensor:
        """
        按车数分组归一化

        Args:
            values: [batch]
            num_agents: [batch]

        Returns:
            normalized_values: [batch]
        """
        normalized = torch.zeros_like(values)

        for n in range(1, self.max_num_agents + 1):
            mask = (num_agents == n)
            if mask.sum() == 0:
                continue

            idx = n - 1
            mean = self.value_mean[idx]
            std = self.value_std[idx]

            # 归一化
            normalized[mask] = (values[mask] - mean) / (std + 1e-8)

        return normalized

    def denormalize(self, normalized_values: torch.Tensor, num_agents: torch.Tensor) -> torch.Tensor:
        """
        反归一化
        """
        denormalized = torch.zeros_like(normalized_values)

        for n in range(1, self.max_num_agents + 1):
            mask = (num_agents == n)
            if mask.sum() == 0:
                continue

            idx = n - 1
            mean = self.value_mean[idx]
            std = self.value_std[idx]

            denormalized[mask] = normalized_values[mask] * std + mean

        return denormalized


class EnhancedHierarchicalGATCritic(nn.Module):
    """
    增强型层次化GAT Critic

    支持1-8车的动态价值估计，具备：
    1. 车数感知和归一化
    2. 场景上下文编码
    3. 混合价值分解（基础价值 + 协作奖励）
    4. 分组价值归一化

    设计理念：
    V_total(s, N) = N * V_base(s) + V_coop(s, N) + V_context(s, env)

    其中：
    - V_base: 人均基础价值（车数不变）
    - V_coop: 协作奖励（捕捉team coordination）
    - V_context: 场景修正（障碍物、地图复杂度等）
    """

    def __init__(
        self,
        obs_dim: int,
        hidden_dim: int = 256,
        max_num_agents: int = 8,
        num_heads: int = 4,
        num_gat_layers: int = 2,
        dropout: float = 0.1,
        use_dual_critic: bool = False,
        value_decomposition: str = 'hybrid',  # 'total' | 'average' | 'hybrid'
        use_context_encoding: bool = True,
        use_value_normalization: bool = True,
    ):
        super().__init__()
        self.obs_dim = obs_dim
        self.hidden_dim = hidden_dim
        self.max_num_agents = max_num_agents
        self.use_dual_critic = use_dual_critic
        self.value_decomposition = value_decomposition
        self.use_context_encoding = use_context_encoding
        self.use_value_normalization = use_value_normalization

        # Node encoder
        self.node_encoder = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

        # 车数embedding（支持1-8车）
        self.num_agents_embedding = nn.Embedding(max_num_agents, hidden_dim // 4)

        # GAT layers
        from hierarchical_gat_critic import HierarchicalGATLayer, DeepResidualMLP
        self.gat_layers = nn.ModuleList([
            HierarchicalGATLayer(
                in_features=hidden_dim if i == 0 else hidden_dim * num_heads,
                out_features=hidden_dim,
                num_heads=num_heads,
                dropout=dropout,
                residual=True,
            )
            for i in range(num_gat_layers)
        ])

        # 场景上下文编码器
        if use_context_encoding:
            self.context_encoder = ContextEncoder(hidden_dim=hidden_dim // 4)
            context_dim = hidden_dim // 4
        else:
            self.context_encoder = None
            context_dim = 0

        # MLP输入维度
        mlp_input_dim = hidden_dim * num_heads + hidden_dim // 4 + context_dim

        # 价值分解分支
        if value_decomposition == 'hybrid':
            # 基础价值分支（人均）
            self.base_value_mlp = DeepResidualMLP(
                input_dim=mlp_input_dim,
                hidden_dim=hidden_dim,
                dropout=dropout,
            )
            self.base_value_head = nn.Linear(hidden_dim, 1)
            nn.init.orthogonal_(self.base_value_head.weight, gain=1.0)
            nn.init.constant_(self.base_value_head.bias, 0.0)

            # 协作奖励分支
            self.coop_value_mlp = DeepResidualMLP(
                input_dim=mlp_input_dim,
                hidden_dim=hidden_dim // 2,
                dropout=dropout,
            )
            self.coop_value_head = nn.Linear(hidden_dim // 2, 1)
            nn.init.orthogonal_(self.coop_value_head.weight, gain=0.5)
            nn.init.constant_(self.coop_value_head.bias, 0.0)

        else:
            # 单一价值分支
            self.value_mlp = DeepResidualMLP(
                input_dim=mlp_input_dim,
                hidden_dim=hidden_dim,
                dropout=dropout,
            )
            self.value_head = nn.Linear(hidden_dim, 1)
            nn.init.orthogonal_(self.value_head.weight, gain=1.0)
            nn.init.constant_(self.value_head.bias, 0.0)

        # Dual critic (可选)
        if use_dual_critic:
            self.value_mlp2 = DeepResidualMLP(
                input_dim=mlp_input_dim,
                hidden_dim=hidden_dim,
                dropout=dropout,
            )
            self.value_head2 = nn.Linear(hidden_dim, 1)
            nn.init.orthogonal_(self.value_head2.weight, gain=1.0)
            nn.init.constant_(self.value_head2.bias, 0.0)

        # 价值归一化器
        if use_value_normalization:
            self.value_normalizer = ValueNormalizer(max_num_agents=max_num_agents)
        else:
            self.value_normalizer = None

    def forward(
        self,
        global_obs: torch.Tensor,
        node_mask: Optional[torch.Tensor] = None,
        num_agents_actual: Optional[torch.Tensor] = None,
        context: Optional[Dict[str, torch.Tensor]] = None,
        return_both: bool = False,
        return_decomposition: bool = False,
    ) -> torch.Tensor:
        """
        Args:
            global_obs: [batch, num_agents, obs_dim] or [batch, num_agents * obs_dim]
            node_mask: [batch, num_agents] (1 for valid, 0 for masked)
            num_agents_actual: [batch] 实际车数（可选，自动推断）
            context: 场景上下文字典（可选）
            return_both: 是否返回dual critic的两个值
            return_decomposition: 是否返回价值分解（仅hybrid模式）

        Returns:
            value: [batch] 状态价值
            (可选) decomposition: {'base': [batch], 'coop': [batch], 'context': [batch]}
        """
        batch_size = global_obs.shape[0]

        # Reshape input
        if global_obs.dim() == 2:
            if node_mask is not None:
                num_agents_in_batch = node_mask.shape[1]
            else:
                total_dim = global_obs.shape[1]
                assert total_dim % self.obs_dim == 0
                num_agents_in_batch = total_dim // self.obs_dim
            global_obs = global_obs.view(batch_size, num_agents_in_batch, self.obs_dim)

        num_agents_in_batch = global_obs.shape[1]

        # 推断实际车数
        if num_agents_actual is None:
            if node_mask is not None:
                num_agents_actual = node_mask.sum(dim=1)
            else:
                num_agents_actual = torch.full(
                    (batch_size,),
                    num_agents_in_batch,
                    dtype=torch.long,
                    device=global_obs.device
                )

        num_agents_actual = torch.clamp(num_agents_actual.long(), min=1, max=self.max_num_agents)

        # Default mask
        if node_mask is None:
            node_mask = torch.ones(batch_size, num_agents_in_batch,
                                  device=global_obs.device, dtype=torch.float32)

        # Encode nodes
        node_features = self.node_encoder(
            global_obs.reshape(-1, self.obs_dim)
        ).view(batch_size, num_agents_in_batch, self.hidden_dim)

        node_features = node_features * node_mask.unsqueeze(-1)

        # Adjacency matrix
        adj = torch.ones(batch_size, num_agents_in_batch, num_agents_in_batch,
                        device=global_obs.device)

        # GAT layers
        for gat_layer in self.gat_layers:
            node_features, global_feature = gat_layer(node_features, adj, node_mask)

        # 车数embedding
        num_agents_feat = self.num_agents_embedding(num_agents_actual - 1)

        # 场景上下文
        if self.use_context_encoding and context is not None:
            # 确保context中的tensor有正确的batch_size
            if 'num_obstacles' in context:
                context['num_obstacles'] = context['num_obstacles'].to(global_obs.device)
            if 'goal_reached_ratio' in context:
                context['goal_reached_ratio'] = context['goal_reached_ratio'].to(global_obs.device)

            context_feat = self.context_encoder(context)

            # 拼接特征
            combined_feature = torch.cat([
                global_feature,     # [batch, hidden_dim * num_heads]
                num_agents_feat,    # [batch, hidden_dim // 4]
                context_feat        # [batch, hidden_dim // 4]
            ], dim=-1)
        else:
            combined_feature = torch.cat([
                global_feature,
                num_agents_feat
            ], dim=-1)

        # 价值估计
        if self.value_decomposition == 'hybrid':
            # 混合分解模式
            # V_total = N * V_base + V_coop

            # 基础人均价值
            h_base = self.base_value_mlp(combined_feature)
            v_base = self.base_value_head(h_base).squeeze(-1)  # [batch]

            # 协作奖励
            h_coop = self.coop_value_mlp(combined_feature)
            v_coop = self.coop_value_head(h_coop).squeeze(-1)  # [batch]

            # 总价值
            value = num_agents_actual.float() * v_base + v_coop

            if return_decomposition:
                decomposition = {
                    'base_per_agent': v_base,
                    'cooperation_bonus': v_coop,
                    'total': value,
                }

        elif self.value_decomposition == 'average':
            # 人均价值模式（车数不敏感）
            h = self.value_mlp(combined_feature)
            v_avg = self.value_head(h).squeeze(-1)
            value = v_avg  # 直接返回人均价值

        else:  # 'total'
            # 集中式总价值模式
            h = self.value_mlp(combined_feature)
            value = self.value_head(h).squeeze(-1)

        # 价值归一化
        if self.use_value_normalization and self.value_normalizer is not None:
            self.value_normalizer.update(value.detach(), num_agents_actual)

        # Clip
        value = torch.clamp(value, -100.0, 100.0)

        # Dual critic
        if self.use_dual_critic and return_both:
            h2 = self.value_mlp2(combined_feature)
            value2 = self.value_head2(h2).squeeze(-1)
            value2 = torch.clamp(value2, -100.0, 100.0)

            if return_decomposition and self.value_decomposition == 'hybrid':
                return (value, value2), decomposition
            return value, value2

        if return_decomposition and self.value_decomposition == 'hybrid':
            return value, decomposition

        return value

    def get_min_value(
        self,
        global_obs: torch.Tensor,
        node_mask: Optional[torch.Tensor] = None,
        num_agents_actual: Optional[torch.Tensor] = None,
        context: Optional[Dict[str, torch.Tensor]] = None,
    ) -> torch.Tensor:
        """TD3-style: 返回两个critic的最小值"""
        if not self.use_dual_critic:
            return self.forward(global_obs, node_mask, num_agents_actual, context)

        v1, v2 = self.forward(global_obs, node_mask, num_agents_actual, context, return_both=True)
        return torch.min(v1, v2)


# ============================================================================
# 测试和使用示例
# ============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("Enhanced Hierarchical GAT Critic - 测试")
    print("=" * 60)

    obs_dim = 50
    hidden_dim = 256

    # 创建critic
    critic = EnhancedHierarchicalGATCritic(
        obs_dim=obs_dim,
        hidden_dim=hidden_dim,
        max_num_agents=8,
        value_decomposition='hybrid',
        use_context_encoding=True,
        use_value_normalization=True,
    )

    print(f"\n✅ Critic初始化成功")
    print(f"   - 支持车数: 1-8")
    print(f"   - 价值分解: hybrid (base + cooperation)")
    print(f"   - 场景编码: 启用")
    print(f"   - 价值归一化: 启用")

    # 测试不同车数
    print("\n" + "=" * 60)
    print("测试不同车数的价值估计")
    print("=" * 60)

    for num_agents in [2, 4, 6, 8]:
        batch_size = 4
        global_obs = torch.randn(batch_size, num_agents, obs_dim)

        # 随机mask一些智能体
        node_mask = torch.ones(batch_size, num_agents)
        if num_agents > 2:
            node_mask[0, -1] = 0  # 第一个样本mask掉最后一个智能体

        # 场景上下文
        context = {
            'num_obstacles': torch.tensor([4, 6, 8, 2], dtype=torch.float32),
            'map_size': 20.0,
            'goal_reached_ratio': torch.tensor([0.0, 0.25, 0.5, 0.75]),
        }

        # 前向传播
        value, decomp = critic(
            global_obs,
            node_mask,
            context=context,
            return_decomposition=True
        )

        print(f"\n📊 车数={num_agents}:")
        print(f"   总价值: mean={value.mean().item():.2f}, std={value.std().item():.2f}")
        print(f"   人均基础: mean={decomp['base_per_agent'].mean().item():.2f}")
        print(f"   协作奖励: mean={decomp['cooperation_bonus'].mean().item():.2f}")

        # 验证价值分解
        reconstructed = (node_mask.sum(dim=1) * decomp['base_per_agent'] +
                        decomp['cooperation_bonus'])
        error = (reconstructed - value).abs().max().item()
        print(f"   分解误差: {error:.6f} (应接近0)")

    print("\n" + "=" * 60)
    print("✅ 所有测试通过！")
    print("=" * 60)

    # 打印参数量
    total_params = sum(p.numel() for p in critic.parameters())
    print(f"\n📊 模型参数量: {total_params:,}")
    print(f"   (约 {total_params / 1e6:.2f}M parameters)")
