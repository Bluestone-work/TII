"""
车数泛化Critic快速修复方案

【修复 2026-07-04】
解决HierarchicalGATCritic在车数变化时估计不准的问题

修改点:
1. 添加车数embedding，让模型感知当前智能体数量
2. 支持动态车数输入（通过node_mask自动推断）
3. 可选的per-agent价值归一化

使用方法:
1. 替换 hierarchical_gat_critic.py 中的 HierarchicalGATCritic 类
2. 在训练时启用数据增强: 随机mask掉1-2个智能体
3. 重新训练模型

"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple


class HierarchicalGATCriticScalable(nn.Module):
    """
    支持可变车数的层次化图注意力 Critic 网络

    改进:
    1. 车数感知: 通过embedding层编码当前智能体数量
    2. 动态维度: 移除硬编码的num_agents限制
    3. 归一化选项: 可选per-agent价值归一化

    架构：
    1. Node encoder (per-agent features)
    2. 2-layer Hierarchical GAT
    3. Num-agents embedding融合
    4. Deep Residual MLP
    5. Value head with normalization
    """
    def __init__(
        self,
        obs_dim: int,
        hidden_dim: int = 256,
        max_num_agents: int = 8,  # 改名: 仅用于embedding层大小
        num_heads: int = 4,
        num_gat_layers: int = 2,
        dropout: float = 0.1,
        use_dual_critic: bool = False,
        normalize_by_num_agents: bool = False,  # 新增: 是否归一化
    ):
        super().__init__()
        self.obs_dim = obs_dim
        self.hidden_dim = hidden_dim
        self.max_num_agents = max_num_agents
        self.use_dual_critic = use_dual_critic
        self.normalize_by_num_agents = normalize_by_num_agents

        # Node encoder (encode individual agent observations)
        self.node_encoder = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

        # 【新增】车数embedding: 支持1到max_num_agents辆车
        self.num_agents_embedding = nn.Embedding(
            max_num_agents,  # 支持1-max_num_agents
            hidden_dim // 4  # embedding维度
        )

        # Hierarchical GAT layers (从原实现导入)
        # 注意: 需要确保HierarchicalGATLayer也支持动态车数
        from hierarchical_gat_critic import HierarchicalGATLayer
        self.gat_layers = nn.ModuleList([
            HierarchicalGATLayer(
                in_features=hidden_dim if i == 0 else hidden_dim * num_heads,
                out_features=hidden_dim,
                num_heads=num_heads,
                dropout=dropout,
                residual=True,
            )
            for i in range(num_gat_layers)
        ])

        # Deep residual MLP (输入拼接车数embedding)
        mlp_input_dim = hidden_dim * num_heads + hidden_dim // 4
        from hierarchical_gat_critic import DeepResidualMLP
        self.value_mlp = DeepResidualMLP(
            input_dim=mlp_input_dim,
            hidden_dim=hidden_dim,
            dropout=dropout,
        )

        # Value head
        self.value_head = nn.Linear(hidden_dim, 1)
        nn.init.orthogonal_(self.value_head.weight, gain=1.0)
        nn.init.constant_(self.value_head.bias, 0.0)

        # Dual critic (optional)
        if use_dual_critic:
            self.value_mlp2 = DeepResidualMLP(
                input_dim=mlp_input_dim,
                hidden_dim=hidden_dim,
                dropout=dropout,
            )
            self.value_head2 = nn.Linear(hidden_dim, 1)
            nn.init.orthogonal_(self.value_head2.weight, gain=1.0)
            nn.init.constant_(self.value_head2.bias, 0.0)

    def forward(
        self,
        global_obs: torch.Tensor,
        node_mask: Optional[torch.Tensor] = None,
        num_agents_actual: Optional[torch.Tensor] = None,
        return_both: bool = False,
    ) -> torch.Tensor:
        """
        Args:
            global_obs: [batch, num_agents, obs_dim] or [batch, num_agents * obs_dim]
            node_mask: [batch, num_agents] (1 for valid, 0 for masked)
            num_agents_actual: [batch] 实际车数（可选，会自动从node_mask推断）
            return_both: 如果是 dual critic，是否返回两个值

        Returns:
            value: [batch] - 状态价值
        """
        batch_size = global_obs.shape[0]

        # 【改进】动态推断车数和obs_dim
        if global_obs.dim() == 2:
            # Flattened input: [batch, num_agents * obs_dim]
            # 需要知道num_agents才能reshape
            if node_mask is not None:
                num_agents_in_batch = node_mask.shape[1]
            else:
                # 尝试从total_dim推断（假设能整除）
                total_dim = global_obs.shape[1]
                assert total_dim % self.obs_dim == 0, \
                    f"Cannot infer num_agents: {total_dim} not divisible by obs_dim={self.obs_dim}"
                num_agents_in_batch = total_dim // self.obs_dim

            global_obs = global_obs.view(batch_size, num_agents_in_batch, self.obs_dim)

        num_agents_in_batch = global_obs.shape[1]

        # 【新增】推断实际车数（考虑mask）
        if num_agents_actual is None:
            if node_mask is not None:
                num_agents_actual = node_mask.sum(dim=1)  # [batch]
            else:
                num_agents_actual = torch.full(
                    (batch_size,),
                    num_agents_in_batch,
                    dtype=torch.long,
                    device=global_obs.device
                )

        # Clamp to valid range
        num_agents_actual = torch.clamp(
            num_agents_actual.long(),
            min=1,
            max=self.max_num_agents
        )

        # Default mask (all agents valid)
        if node_mask is None:
            node_mask = torch.ones(
                batch_size, num_agents_in_batch,
                device=global_obs.device,
                dtype=torch.float32
            )

        # Encode individual agent observations
        node_features = self.node_encoder(
            global_obs.reshape(-1, self.obs_dim)
        ).view(batch_size, num_agents_in_batch, self.hidden_dim)

        # Apply node mask
        node_features = node_features * node_mask.unsqueeze(-1)

        # Full adjacency (all-to-all communication)
        adj = torch.ones(
            batch_size, num_agents_in_batch, num_agents_in_batch,
            device=global_obs.device
        )

        # Hierarchical GAT layers
        for gat_layer in self.gat_layers:
            node_features, global_feature = gat_layer(
                node_features, adj, node_mask
            )

        # 【新增】车数embedding
        # num_agents_actual: [batch], 1-indexed, 需要转为0-indexed
        num_agents_feat = self.num_agents_embedding(num_agents_actual - 1)  # [batch, hidden_dim//4]

        # 拼接全局特征和车数特征
        global_feature_enhanced = torch.cat([
            global_feature,      # [batch, hidden_dim * num_heads]
            num_agents_feat      # [batch, hidden_dim // 4]
        ], dim=-1)

        # Deep MLP
        h = self.value_mlp(global_feature_enhanced)

        # Value head
        value = self.value_head(h).squeeze(-1)

        # 【新增】可选的车数归一化
        if self.normalize_by_num_agents:
            value = value / num_agents_actual.float()

        # Clip value to prevent explosion
        value = torch.clamp(value, -100.0, 100.0)

        # Dual critic
        if self.use_dual_critic and return_both:
            h2 = self.value_mlp2(global_feature_enhanced)
            value2 = self.value_head2(h2).squeeze(-1)
            if self.normalize_by_num_agents:
                value2 = value2 / num_agents_actual.float()
            value2 = torch.clamp(value2, -100.0, 100.0)
            return value, value2

        return value

    def get_min_value(
        self,
        global_obs: torch.Tensor,
        node_mask: Optional[torch.Tensor] = None,
        num_agents_actual: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        获取两个 Critic 的最小值（TD3 思想）
        """
        if not self.use_dual_critic:
            return self.forward(global_obs, node_mask, num_agents_actual)

        v1, v2 = self.forward(global_obs, node_mask, num_agents_actual, return_both=True)
        return torch.min(v1, v2)


# ============================================================================
# 训练时的数据增强: 随机mask智能体
# ============================================================================

def augment_with_random_masking(
    batch: dict,
    mask_prob: float = 0.3,
    min_agents: int = 2,
) -> dict:
    """
    随机mask掉部分智能体，增强车数泛化能力

    Args:
        batch: RLlib batch dict
        mask_prob: 每个智能体被mask的概率
        min_agents: 最少保留的智能体数量

    Returns:
        augmented_batch: 添加了node_mask的batch
    """
    # 假设batch["obs"]是 [batch, num_agents * obs_dim]
    obs = batch["obs"]
    batch_size = obs.shape[0]

    # 推断车数
    total_dim = obs.shape[1]
    obs_dim = batch.get("obs_dim", None)
    if obs_dim is None:
        raise ValueError("Need obs_dim to apply masking")

    num_agents = total_dim // obs_dim

    # 生成随机mask
    node_mask = torch.rand(batch_size, num_agents) > mask_prob

    # 确保至少保留min_agents个
    num_valid = node_mask.sum(dim=1)
    for i in range(batch_size):
        if num_valid[i] < min_agents:
            # 随机激活一些被mask的智能体
            masked_indices = torch.where(~node_mask[i])[0]
            num_to_activate = min_agents - int(num_valid[i])
            activate_indices = masked_indices[
                torch.randperm(len(masked_indices))[:num_to_activate]
            ]
            node_mask[i, activate_indices] = True

    # 将mask掉的智能体obs置零
    obs_reshaped = obs.view(batch_size, num_agents, obs_dim)
    obs_reshaped = obs_reshaped * node_mask.unsqueeze(-1)
    batch["obs"] = obs_reshaped.view(batch_size, -1)

    # 添加mask到batch
    batch["node_mask"] = node_mask.float()

    return batch


# ============================================================================
# 使用示例
# ============================================================================

if __name__ == "__main__":
    # 测试不同车数
    obs_dim = 50
    hidden_dim = 256

    critic = HierarchicalGATCriticScalable(
        obs_dim=obs_dim,
        hidden_dim=hidden_dim,
        max_num_agents=8,
        normalize_by_num_agents=False,  # 根据任务选择
    )

    print("Testing critic with different num_agents...")

    for num_agents in [2, 4, 6]:
        batch_size = 16
        global_obs = torch.randn(batch_size, num_agents, obs_dim)
        node_mask = torch.ones(batch_size, num_agents)

        # 随机mask掉一些智能体
        node_mask[0, -1] = 0  # 第一个样本mask掉最后一个智能体

        value = critic(global_obs, node_mask)

        print(f"  num_agents={num_agents}: value.shape={value.shape}, "
              f"mean={value.mean().item():.2f}, std={value.std().item():.2f}")

    print("\n✅ Critic可以处理不同车数！")

    # 测试数据增强
    print("\nTesting data augmentation...")
    fake_batch = {
        "obs": torch.randn(16, 4 * obs_dim),
        "obs_dim": obs_dim,
    }

    augmented = augment_with_random_masking(fake_batch, mask_prob=0.3)
    print(f"  node_mask: {augmented['node_mask'][0]}")  # 第一个样本的mask
    print(f"  有效智能体数: {augmented['node_mask'][0].sum().item()}")
