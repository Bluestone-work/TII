#!/usr/bin/env python3
"""
测试静态障碍物修复：验证在单个stage内，静态障碍物不会在每次episode重置时重新spawn
"""
import sys
import os

# 添加路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_static_obstacles_behavior():
    """测试静态障碍物的spawn行为"""
    print("=" * 70)
    print("测试静态障碍物修复")
    print("=" * 70)

    # 模拟测试用例
    print("\n【测试场景】")
    print("1. Stage 1 首次reset -> 应该spawn静态障碍物")
    print("2. Stage 1 第2次reset -> 应该复用现有障碍物，不重新spawn")
    print("3. Stage 1 第3次reset -> 应该复用现有障碍物，不重新spawn")
    print("4. Stage 2 首次reset (调用reset_stage_obstacles后) -> 应该spawn新密度的障碍物")
    print("5. Stage 2 第2次reset -> 应该复用现有障碍物，不重新spawn")

    print("\n【关键修复点】")
    print("✓ GNNMARLEnv.reset() 中添加了 static_obs_already_spawned 检查")
    print("✓ 只有当 _static_obstacles_spawned=False 时才调用 randomize_obstacles()")
    print("✓ 课程切换时通过 reset_stage_obstacles() 清理旧障碍物并重置标志")
    print("✓ 单个stage内的后续episode直接复用现有障碍物布局")

    print("\n【预期行为】")
    print("Stage 1:")
    print("  Episode 1: 🟫 首次spawn静态障碍物 (8个)")
    print("  Episode 2: ♻️  复用现有静态障碍物 (8个)")
    print("  Episode 3: ♻️  复用现有静态障碍物 (8个)")
    print("  ...")
    print("\nStage 2 (切换后):")
    print("  调用 reset_stage_obstacles() -> 清理旧障碍物 + 重置标志")
    print("  Episode 1: 🟫 首次spawn静态障碍物 (10个)")
    print("  Episode 2: ♻️  复用现有静态障碍物 (10个)")
    print("  Episode 3: ♻️  复用现有静态障碍物 (10个)")
    print("  ...")

    print("\n【静态障碍物密度课程】")
    print("  Stage 1: 8个静态障碍物  (基础避障)")
    print("  Stage 2: 10个静态障碍物 (多体交互)")
    print("  Stage 3: 12个静态障碍物 (渐进密度)")
    print("  Stage 4: 15个静态障碍物 (高密度协调)")

    print("\n【修复前的Bug】")
    print("❌ 每次episode reset都会调用 randomize_obstacles()")
    print("❌ randomize_obstacles() 会删除并重新spawn所有静态障碍物")
    print("❌ 导致单个stage内，每个episode的静态障碍物布局都不同")
    print("❌ 训练不稳定，智能体无法学习固定布局的避障策略")

    print("\n【修复后的行为】")
    print("✓ 首次reset时spawn静态障碍物，设置 _static_obstacles_spawned=True")
    print("✓ 后续reset检查标志，如果已spawn则跳过 randomize_obstacles()")
    print("✓ 单个stage内所有episode使用相同的静态障碍物布局")
    print("✓ 只在stage切换时（调用reset_stage_obstacles）才改变障碍物密度")
    print("✓ 训练稳定，智能体可以学习适应固定布局")

    print("\n" + "=" * 70)
    print("测试完成！请运行训练验证修复效果")
    print("=" * 70)

    return True

if __name__ == "__main__":
    test_static_obstacles_behavior()
