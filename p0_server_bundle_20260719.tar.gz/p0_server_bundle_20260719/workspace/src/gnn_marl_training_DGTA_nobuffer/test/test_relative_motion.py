import math
from types import SimpleNamespace

import numpy as np

from gnn_marl_training.gnn_marl_env import (
    IndependentRobotEnv,
    compute_relative_motion_metrics,
    unicycle_body_trajectory,
)
from gnn_marl_training.global_planner import AStarPlanner, PathTrackingUtils


def test_robot_motion_is_included_in_relative_ttc():
    metrics = compute_relative_motion_metrics(
        np.array([1.0, 0.0]),
        np.array([-0.2, 0.0]),
        horizon=5.0,
        clearance_radius=0.2,
    )

    assert math.isclose(metrics["closing_speed"], 0.2, rel_tol=1e-6)
    assert math.isclose(metrics["ttc"], 4.0, rel_tol=1e-6)
    assert metrics["closest_clearance"] < -0.19


def test_crossing_motion_detects_small_closest_approach():
    metrics = compute_relative_motion_metrics(
        np.array([0.5, 0.5]),
        np.array([0.0, -0.25]),
        horizon=3.0,
        clearance_radius=0.3,
    )

    assert math.isclose(metrics["closest_time"], 2.0, rel_tol=1e-6)
    assert math.isclose(metrics["closest_distance"], 0.5, rel_tol=1e-6)
    assert math.isclose(metrics["closest_clearance"], 0.2, rel_tol=1e-6)


def test_receding_motion_has_infinite_ttc():
    metrics = compute_relative_motion_metrics(
        np.array([0.8, 0.0]),
        np.array([0.2, 0.0]),
        horizon=2.0,
        clearance_radius=0.2,
    )

    assert metrics["closing_speed"] == 0.0
    assert math.isinf(metrics["ttc"])
    assert metrics["closest_time"] == 0.0


def test_unicycle_trajectory_matches_straight_and_turning_motion():
    times = np.array([0.0, 1.0], dtype=np.float32)
    straight = unicycle_body_trajectory(0.2, 0.0, times)
    turning = unicycle_body_trajectory(0.2, 1.0, times)

    np.testing.assert_allclose(straight[-1], [0.2, 0.0], atol=1e-6)
    np.testing.assert_allclose(
        turning[-1],
        [0.2 * math.sin(1.0), 0.2 * (1.0 - math.cos(1.0))],
        atol=1e-6,
    )


def _motion_filter_env():
    env = IndependentRobotEnv.__new__(IndependentRobotEnv)
    env.robot_id = 0
    env.current_pose = {"x": 0.0, "y": 0.0, "yaw": 0.0}
    env.current_vel_x = 0.0
    env.control_dt = 0.1
    env.predictive_horizon_sec = 1.2
    env.predictive_social_range = 2.5
    env.scan_max_range = 3.5
    env.max_forward_vel = 0.22
    env.max_angular_vel = 1.2
    env.obstacle_motion_dim = 0
    env.obstacle_motion_top_k = 0
    env.obstacle_motion_feature_dim = 7
    env.obstacle_filter_range = 2.0
    env._last_motion_features = None
    env.parent_env = SimpleNamespace(
        robot_positions={
            "agent_0": np.array([0.0, 0.0], dtype=np.float32),
            "agent_1": np.array([0.65, 0.0], dtype=np.float32),
        },
        robot_velocities={
            "agent_0": np.zeros(2, dtype=np.float32),
            "agent_1": np.zeros(2, dtype=np.float32),
        },
        dones=set(),
    )
    return env


def test_motion_projection_reduces_agent_collision_risk():
    env = _motion_filter_env()
    before = env._predict_command_motion_safety(0.22, 0.0)
    projected_v, projected_w, projected = env._project_motion_safe_command(
        0.22,
        0.0,
        0.0,
        soft_filter=True,
    )

    assert before["margin"] < 0.08
    assert projected["active"]
    assert projected["margin"] > before["margin"]
    assert projected_v < 0.22
    assert abs(projected_w) <= env.max_angular_vel


def test_motion_projection_preserves_safe_command():
    env = _motion_filter_env()
    env.parent_env.robot_positions["agent_1"] = np.array([2.0, 0.0], dtype=np.float32)
    projected_v, projected_w, projected = env._project_motion_safe_command(
        0.18,
        0.2,
        0.0,
        soft_filter=True,
    )

    assert not projected["active"]
    assert projected_v == 0.18
    assert projected_w == 0.2


def test_progress_window_prevents_parallel_aisle_branch_jump():
    path = [(0.0, 0.0), (4.0, 0.0), (4.0, 0.4), (0.0, 0.4)]
    point = (1.0, 0.38)

    unconstrained = PathTrackingUtils.get_path_projection(point, path)
    constrained = PathTrackingUtils.get_path_projection(
        point,
        path,
        reference_progress=1.0,
        max_backtrack=0.4,
        max_forward_snap=1.0,
    )

    assert unconstrained["segment_index"] == 2
    assert constrained["segment_index"] == 0
    assert constrained["arc_progress"] <= 2.0


def test_invalid_inflated_endpoint_projects_to_nearest_valid_cell():
    planner = AStarPlanner.__new__(AStarPlanner)
    planner.width = 7
    planner.height = 7
    planner.inflated_map = np.full((7, 7), 100, dtype=np.uint8)
    planner.inflated_map[3, 5] = 0

    assert planner._find_nearest_valid_cell((3, 3), max_radius=3) == (5, 3)
    assert planner._find_nearest_valid_cell((3, 3), max_radius=1) is None
