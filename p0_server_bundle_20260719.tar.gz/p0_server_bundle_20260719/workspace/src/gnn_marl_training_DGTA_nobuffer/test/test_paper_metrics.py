import math

import numpy as np

from gnn_marl_training.paper_metrics import (
    EpisodeMetricTracker,
    MetricThresholds,
    initial_state_description,
    pair_time_to_collision,
    polyline_length,
)


def test_polyline_length_and_pair_ttc():
    assert polyline_length([(3.0, 4.0)], start=(0.0, 0.0)) == 5.0
    ttc = pair_time_to_collision(
        (-1.0, 0.0), (1.0, 0.0),
        (1.0, 0.0), (-1.0, 0.0),
        collision_distance=0.4,
    )
    assert math.isclose(ttc, 0.8)


def test_initial_state_fingerprint_is_order_stable_and_sensitive():
    positions = {"agent_1": (1.0, 2.0), "agent_0": (0.0, 0.0)}
    goals = {"agent_0": (3.0, 4.0), "agent_1": (-1.0, -2.0)}
    routes, fingerprint = initial_state_description(
        ["agent_1", "agent_0"], positions, goals
    )
    reordered, same_fingerprint = initial_state_description(
        ["agent_0", "agent_1"], positions, goals
    )
    assert routes == reordered
    assert fingerprint == same_fingerprint
    changed_goals = dict(goals, agent_1=(-1.1, -2.0))
    _changed, changed_fingerprint = initial_state_description(
        ["agent_0", "agent_1"], positions, changed_goals
    )
    assert changed_fingerprint != fingerprint


def test_episode_tracker_metrics():
    thresholds = MetricThresholds(
        control_dt=0.1,
        near_collision_clearance_m=0.5,
        deadlock_window_steps=2,
        oscillation_angular_speed_rps=0.2,
    )
    tracker = EpisodeMetricTracker(
        ["agent_0"],
        {"agent_0": (0.0, 0.0)},
        {"agent_0": 1.0},
        thresholds,
    )
    commands = [
        {"raw_linear_vel": 0.2, "raw_angular_vel": 0.4, "executed_linear_vel": 0.0, "executed_angular_vel": 0.4},
        {"raw_linear_vel": 0.2, "raw_angular_vel": -0.4, "executed_linear_vel": 0.0, "executed_angular_vel": -0.4},
        {"raw_linear_vel": 0.2, "raw_angular_vel": 0.4, "executed_linear_vel": 0.0, "executed_angular_vel": 0.4},
    ]
    for step, command in enumerate(commands, 1):
        tracker.record_step(
            positions={"agent_0": (0.1 * step, 0.0)},
            velocities={"agent_0": np.zeros(2)},
            infos={"agent_0": {"min_dist": 0.4, "dist_to_goal": 1.0}},
            commands={"agent_0": command},
            active_ids=["agent_0"],
        )
    tracker.mark_event("agent_0", "goal", 3)
    summary = tracker.summary(reached_agents={"agent_0"}, steps=3)
    assert math.isclose(summary["path_length"], 0.3)
    assert summary["near_collision_count"] == 1
    assert summary["deadlock"] is True
    assert summary["oscillation_count"] == 2
    assert 0.0 < summary["filter_intervention_rate"] <= 1.0
    assert summary["filter_intervention_count"] == 3
    assert summary["filter_action_samples"] == 3
    assert summary["successful_agent_completion_time_count"] == 1
    assert math.isclose(summary["successful_agent_completion_time_sum"], 0.3)
    assert math.isclose(summary["team_completion_time"], 0.3)
