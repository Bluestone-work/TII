#!/usr/bin/env bash
set -euo pipefail

ROOT="/home/wj/work/multi-robot-exploration-rl"
RUN_TAG="${RUN_TAG:-p0_core_v1}"
MATRIX="$ROOT/experiments/p0_core_training_matrix.tsv"
TRAIN_ROOT="${TRAIN_ROOT:-$ROOT/ray_results/$RUN_TAG}"
LOG_ROOT="${LOG_ROOT:-$ROOT/curriculum_logs/$RUN_TAG}"
OUT_ROOT="${OUT_ROOT:-$ROOT/paper_results/$RUN_TAG}"
PYTHON="${PYTHON:-/home/wj/anaconda3/envs/ros2/bin/python}"
CONFIRM_START_P0="${CONFIRM_START_P0:-0}"
STEPS_PER_MAP="${STEPS_PER_MAP:-400000}"
MAX_PARALLEL="${MAX_PARALLEL:-2}"

mkdir -p "$OUT_ROOT"
PYTHONPATH="$ROOT/src/gnn_marl_training_DGTA_nobuffer" "$PYTHON" \
  "$ROOT/scripts/validate_p0_core_protocol.py" --matrix "$MATRIX" \
  --output "$OUT_ROOT/common_initialization_manifest.json"
bash "$ROOT/experiments/verify_p0_core_protocol.sh"

if [[ "$CONFIRM_START_P0" != "1" ]]; then
  echo "[ready] P0 protocol validated; training remains stopped."
  echo "[ready] start explicitly with CONFIRM_START_P0=1."
  exit 0
fi

for path in "$TRAIN_ROOT" "$LOG_ROOT"; do
  if [[ -e "$path" ]] && find -H "$path" -mindepth 1 -print -quit | grep -q .; then
    echo "[FATAL] P0 requires a fresh output root; refusing existing path: $path" >&2
    exit 4
  fi
done

mkdir -p "$TRAIN_ROOT" "$LOG_ROOT"
MODE=formal RUN_TAG="$RUN_TAG" MATRIX="$MATRIX" \
  TRAIN_ROOT="$TRAIN_ROOT" LOG_ROOT="$LOG_ROOT" \
  SEEDS="1 2 3" MAPS="4 9" STEPS_PER_MAP="$STEPS_PER_MAP" \
  MAX_PARALLEL="$MAX_PARALLEL" MAX_RETRIES=2 RESUME_ACROSS_MAPS=1 \
  EARLY_STOP_PATIENCE_ITERS=0 \
  PROTOCOL_VERIFY_SCRIPT="$ROOT/experiments/verify_p0_core_protocol.sh" \
  RAY_GPU_PER_RUN=0.30 RAY_CPUS_PER_RUN=2 RAY_OBJECT_STORE_MEMORY_MB=256 \
  TRAIN_SAFETY_FILTER=0 ALLOW_SHIELD_DURING_TRAINING=0 \
  bash "$ROOT/experiments/run_formal_training_matrix.sh"

TRAIN_MANIFEST="$LOG_ROOT/training_manifest.tsv" MATRIX="$MATRIX" OUT_ROOT="$OUT_ROOT" \
  SEEDS="1 2 3" EPISODES=50 MAX_PARALLEL=3 \
  bash "$ROOT/experiments/run_p0_core_evaluation.sh"

TRAIN_MANIFEST="$LOG_ROOT/training_manifest.tsv" MATRIX="$MATRIX" OUT_ROOT="$OUT_ROOT" \
  SEEDS="1 2 3" EPISODES=50 MAX_PARALLEL=3 \
  bash "$ROOT/experiments/run_p0_p1_map3_evaluation.sh"

TRAIN_MANIFEST="$LOG_ROOT/training_manifest.tsv" MATRIX="$MATRIX" \
  OUT_ROOT="$OUT_ROOT/complexity" TEAM_SIZES="1 4 8" DEVICES="cpu gpu" \
  bash "$ROOT/experiments/run_p0_p1_complexity.sh"
