#!/usr/bin/env bash
set -euo pipefail

ROOT="/home/wj/work/multi-robot-exploration-rl"
PYTHON="${PYTHON:-/home/wj/anaconda3/envs/ros2/bin/python}"
HASH_FILE="${P0_PROTOCOL_HASH:-$ROOT/paper_results/p0_core_v1/source_sha256.txt}"

[[ -s "$HASH_FILE" ]] || {
  echo "[FATAL] missing frozen P0 source hash: $HASH_FILE" >&2
  exit 2
}
cd "$ROOT"
sha256sum --check "$HASH_FILE" >/dev/null || {
  echo "[FATAL] P0 source hash mismatch: $HASH_FILE" >&2
  exit 3
}
PYTHONPATH="$ROOT/src/gnn_marl_training_DGTA_nobuffer" "$PYTHON" \
  "$ROOT/scripts/validate_p0_core_protocol.py" \
  --matrix "$ROOT/experiments/p0_core_training_matrix.tsv" >/dev/null
echo "[verified] P0 core protocol source hash=$HASH_FILE"
