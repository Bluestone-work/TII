#!/usr/bin/env bash
set -euo pipefail

ROOT="/home/wj/work/multi-robot-exploration-rl"
RUNNER="$ROOT/scripts/run_fixed_scenario_bank_eval.sh"
VALIDATOR="$ROOT/scripts/validate_formal_episode_artifacts.py"
PAIR_VALIDATOR="$ROOT/scripts/validate_paired_collection.py"
STATISTICS="$ROOT/scripts/formal_statistics.py"
SUMMARY="$ROOT/scripts/summarize_p0_core_results.py"
PYTHON="${PYTHON:-/home/wj/anaconda3/envs/ros2/bin/python}"
TRAIN_MANIFEST="${TRAIN_MANIFEST:?TRAIN_MANIFEST is required}"
MATRIX="${MATRIX:-$ROOT/experiments/p0_core_training_matrix.tsv}"
OUT_ROOT="${OUT_ROOT:-$ROOT/paper_results/p0_core_v1}"
SOURCE_MAP="${SOURCE_MAP:-9}"
SEEDS="${SEEDS:-1 2 3}"
EPISODES="${EPISODES:-50}"
EVAL_SEED="${EVAL_SEED:-20260720}"
MAX_PARALLEL="${MAX_PARALLEL:-3}"
MAX_RETRIES="${MAX_RETRIES:-2}"
MANIFEST="$OUT_ROOT/evaluation_manifest.tsv"
MASTER_LOG="$OUT_ROOT/evaluation.log"

mkdir -p "$OUT_ROOT"

log() {
  printf '[%s] %s\n' "$(date '+%F %T')" "$*" | tee -a "$MASTER_LOG"
}

checkpoint_for() {
  awk -F '\t' -v v="$1" -v s="$2" -v m="$SOURCE_MAP" '
    NR>1 && $1==v && $2==s && $3==m && $4=="trained" {value=$7}
    END {print value}
  ' "$TRAIN_MANIFEST"
}

condition_complete() {
  local out="$1"
  [[ -s "$out/episodes.csv" && -s "$out/episodes.jsonl" && -s "$out/scenario_bank.json" ]] || return 1
  "$PYTHON" "$VALIDATOR" \
    --csv "$out/episodes.csv" --jsonl "$out/episodes.jsonl" \
    --scenario-manifest "$out/scenario_bank.json" --expected-records "$((3 * EPISODES))" \
    --map "4:$EPISODES:2000" --map "9:$EPISODES:2000" --map "5:$EPISODES:2000" \
    >/dev/null
}

run_task() {
  local method="$1" seed="$2" worker="$3" checkpoint out attempt rc=1
  checkpoint="$(checkpoint_for "$method" "$seed")"
  out="$OUT_ROOT/evaluation/$method/seed${seed}"
  [[ -f "$checkpoint/algorithm_state.pkl" ]] || {
    log "FAIL missing checkpoint method=$method seed=$seed source_map=$SOURCE_MAP"
    return 3
  }
  if condition_complete "$out"; then
    log "SKIP complete method=$method seed=$seed"
    return 0
  fi
  mkdir -p "$out"
  for ((attempt=1; attempt<=MAX_RETRIES; attempt++)); do
    rm -rf "$out/cases"
    rm -f "$out/episodes.csv" "$out/episodes.jsonl" "$out/scenario_bank.json"
    log "EVAL method=$method seed=$seed attempt=$attempt episodes_per_map=$EPISODES"
    set +e
    CKPT="$checkpoint" TRAINING_SEED="$seed" METHOD_LABEL="$method" \
      SCENARIO_BANK=p0_core_v1 NUM_EPISODES="$EPISODES" EVAL_SEED="$EVAL_SEED" \
      SAFETY_FILTER_ENABLE=0 COLLECT_CF_TRACE=0 EXPERIMENT_CONDITION=policy_only \
      ROS_DOMAIN_ID_EVAL="$((231 + worker))" GAZEBO_PORT_EVAL="$((12431 + worker))" \
      OUT_DIR="$out" bash "$RUNNER" >>"$OUT_ROOT/${method}_seed${seed}.log" 2>&1
    rc=$?
    set -e
    if (( rc == 0 )) && condition_complete "$out"; then
      { flock 9; printf '%s\t%s\tcomplete\t%s\t%s\n' \
          "$method" "$seed" "$out" "$(date --iso-8601=seconds)" >&9; } 9>>"$MANIFEST"
      log "DONE method=$method seed=$seed"
      return 0
    fi
    log "WARN method=$method seed=$seed attempt=$attempt rc=$rc"
  done
  return 3
}

worker() {
  local worker_id="$1" index
  for ((index=worker_id; index<${#TASKS[@]}; index+=MAX_PARALLEL)); do
    IFS='|' read -r method seed <<<"${TASKS[$index]}"
    run_task "$method" "$seed" "$worker_id"
  done
}

main() {
  [[ -f "$TRAIN_MANIFEST" && -f "$MATRIX" ]] || { log "FATAL missing manifest or matrix"; return 2; }
  if [[ ! -f "$MANIFEST" ]]; then
    printf 'method\ttraining_seed\tstatus\toutput\tcompleted_at\n' >"$MANIFEST"
  fi
  TASKS=()
  METHODS=()
  while IFS=$'\t' read -r order _covers method _extra; do
    [[ "$order" == order || -z "$method" ]] && continue
    METHODS+=("$method")
    for seed in $SEEDS; do TASKS+=("$method|$seed"); done
  done <"$MATRIX"
  log "PLAN methods=[${METHODS[*]}] seeds=[$SEEDS] maps=[4 9 5] episodes=$EPISODES parallel=$MAX_PARALLEL"
  local -a pids=()
  local worker_id failures=0 pid
  for ((worker_id=0; worker_id<MAX_PARALLEL; worker_id++)); do worker "$worker_id" & pids+=("$!"); done
  for pid in "${pids[@]}"; do wait "$pid" || failures=$((failures + 1)); done
  (( failures == 0 )) || { log "FAILED workers=$failures"; return 4; }

  find "$OUT_ROOT/evaluation" -type f -name episodes.jsonl -print0 | sort -z | xargs -0 -r cat \
    >"$OUT_ROOT/episodes_all.jsonl"
  first=1
  : >"$OUT_ROOT/episodes_all.csv"
  while IFS= read -r -d '' path; do
    if (( first )); then cat "$path"; first=0; else tail -n +2 "$path"; fi
  done < <(find "$OUT_ROOT/evaluation" -type f -name episodes.csv -print0 | sort -z) \
    >"$OUT_ROOT/episodes_all.csv"
  scenario_manifest="$(find "$OUT_ROOT/evaluation" -type f -name scenario_bank.json | sort | head -n 1)"
  "$PYTHON" "$PAIR_VALIDATOR" "$OUT_ROOT/episodes_all.jsonl" \
    --methods "${METHODS[@]}" --seeds $SEEDS --conditions policy_only \
    --episodes-per-case "$EPISODES" --scenario-manifest "$scenario_manifest" \
    --eval-seed "$EVAL_SEED" --output "$OUT_ROOT/paired_validation.json"
  "$PYTHON" "$SUMMARY" "$OUT_ROOT/episodes_all.jsonl" \
    --episodes "$EPISODES" --out-dir "$OUT_ROOT/statistics"
  "$PYTHON" "$STATISTICS" "$OUT_ROOT/episodes_all.jsonl" \
    --out-dir "$OUT_ROOT/statistics/inference" --reference p0_graph_off \
    --metrics agent_success_rate team_success collision_rate timeout_rate \
      successful_agent_completion_time_mean path_length spl filter_intervention_rate \
    --require-pairing-metadata --bootstrap-samples 5000
  log "COMPLETE output=$OUT_ROOT"
}

main "$@"
