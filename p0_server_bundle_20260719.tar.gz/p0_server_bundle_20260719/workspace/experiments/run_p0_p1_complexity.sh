#!/usr/bin/env bash
set -euo pipefail

ROOT="/home/wj/work/multi-robot-exploration-rl"
PYTHON="${PYTHON:-/home/wj/anaconda3/envs/ros2/bin/python}"
TRAIN_MANIFEST="${TRAIN_MANIFEST:?TRAIN_MANIFEST is required}"
MATRIX="${MATRIX:-$ROOT/experiments/p0_core_training_matrix.tsv}"
OUT_ROOT="${OUT_ROOT:-$ROOT/paper_results/p0_core_v1/complexity}"
SOURCE_MAP="${SOURCE_MAP:-9}"
SOURCE_SEED="${SOURCE_SEED:-1}"
PROFILE="$ROOT/scripts/profile_policy_complexity.py"
SUMMARIZE="$ROOT/scripts/summarize_policy_complexity.py"
TEAM_SIZES="${TEAM_SIZES:-1 4 8}"
DEVICES="${DEVICES:-cpu gpu}"
WARMUP="${WARMUP:-30}"
REPEATS="${REPEATS:-200}"

mkdir -p "$OUT_ROOT/profiles"

checkpoint_for() {
  awk -F '\t' -v v="$1" -v s="$SOURCE_SEED" -v m="$SOURCE_MAP" '
    NR>1 && $1==v && $2==s && $3==m && $4=="trained" {value=$7}
    END {print value}
  ' "$TRAIN_MANIFEST"
}

main() {
  [[ -f "$TRAIN_MANIFEST" && -f "$MATRIX" ]] || {
    echo "[FATAL] missing training manifest or P0 matrix" >&2
    return 2
  }
  local -a profiles=()
  local order covers method extra checkpoint device team output
  while IFS=$'\t' read -r order covers method extra; do
    [[ "$order" == order || -z "$method" ]] && continue
    checkpoint="$(checkpoint_for "$method")"
    [[ -f "$checkpoint/algorithm_state.pkl" ]] || {
      echo "[FATAL] missing seed-$SOURCE_SEED Map-$SOURCE_MAP checkpoint for $method" >&2
      return 3
    }
    for device in $DEVICES; do
      if [[ "$device" == gpu ]] && ! command -v nvidia-smi >/dev/null 2>&1; then
        echo "[WARN] GPU profile skipped because nvidia-smi is unavailable"
        continue
      fi
      for team in $TEAM_SIZES; do
        output="$OUT_ROOT/profiles/${method}_${device}_robots${team}.json"
        if [[ ! -s "$output" ]]; then
          if [[ "$device" == cpu ]]; then
            CUDA_VISIBLE_DEVICES="" OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
              timeout 600 "$PYTHON" "$PROFILE" --checkpoint "$checkpoint" \
              --method "$method" --device-label cpu --team-size "$team" --batch-size 1 \
              --warmup "$WARMUP" --repeats "$REPEATS" --torch-threads 1 --output "$output"
          else
            CUDA_VISIBLE_DEVICES=0 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
              timeout 600 "$PYTHON" "$PROFILE" --checkpoint "$checkpoint" \
              --method "$method" --device-label gpu --team-size "$team" --batch-size 1 \
              --warmup "$WARMUP" --repeats "$REPEATS" --torch-threads 1 --output "$output"
          fi
        fi
        profiles+=("$output")
      done
    done
  done <"$MATRIX"
  (( ${#profiles[@]} > 0 )) || { echo "[FATAL] no P0 complexity profiles" >&2; return 4; }
  "$PYTHON" "$SUMMARIZE" "${profiles[@]}" --out-dir "$OUT_ROOT"
  echo "[complete] P0 P1 complexity output=$OUT_ROOT"
}

main "$@"
