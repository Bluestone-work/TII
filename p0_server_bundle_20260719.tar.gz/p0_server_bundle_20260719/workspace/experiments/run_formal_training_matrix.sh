#!/usr/bin/env bash
set -euo pipefail

ROOT="/home/wj/work/multi-robot-exploration-rl"
PROTOCOL_VERIFY_SCRIPT="${PROTOCOL_VERIFY_SCRIPT:-$ROOT/experiments/verify_formal_protocol.sh}"
bash "$PROTOCOL_VERIFY_SCRIPT"
TRAIN_RUNNER="$ROOT/src/gnn_marl_training_DGTA_nobuffer/run_curriculum.sh"
MATRIX="${MATRIX:-$ROOT/experiments/formal_training_matrix.tsv}"
MODE="${MODE:-smoke}"
RUN_TAG="${RUN_TAG:-formal_${MODE}_$(date +%Y%m%d)}"
TRAIN_ROOT="${TRAIN_ROOT:-$ROOT/ray_results/$RUN_TAG}"
LOG_ROOT="${LOG_ROOT:-$ROOT/curriculum_logs/$RUN_TAG}"
MANIFEST="$LOG_ROOT/training_manifest.tsv"
MASTER_LOG="$LOG_ROOT/master.log"
MAX_PARALLEL="${MAX_PARALLEL:-2}"
MAX_RETRIES="${MAX_RETRIES:-2}"
RAY_GPU_PER_RUN="${RAY_GPU_PER_RUN:-0.40}"
RAY_CPUS_PER_RUN="${RAY_CPUS_PER_RUN:-2}"
RAY_OBJECT_STORE_MEMORY_MB="${RAY_OBJECT_STORE_MEMORY_MB:-256}"
VARIANTS="${VARIANTS:-all}"
MIN_FREE_GB="${MIN_FREE_GB:-6}"
DISK_POLL_SEC="${DISK_POLL_SEC:-300}"
CHECKPOINT_FREQ="${CHECKPOINT_FREQ:-5}"
EARLY_STOP_PATIENCE_ITERS="${EARLY_STOP_PATIENCE_ITERS:-}"
TRAIN_SAFETY_FILTER="${TRAIN_SAFETY_FILTER:-1}"
ALLOW_SHIELD_DURING_TRAINING="${ALLOW_SHIELD_DURING_TRAINING:-1}"
RESUME_ACROSS_MAPS="${RESUME_ACROSS_MAPS:-1}"

if [[ "$MODE" == "smoke" ]]; then
  SEEDS="${SEEDS:-1}"
  MAPS="${MAPS:-4}"
  STEPS_PER_MAP="${STEPS_PER_MAP:-10000}"
  EVAL_EPISODES="${EVAL_EPISODES:-2}"
elif [[ "$MODE" == "formal" ]]; then
  SEEDS="${SEEDS:-1 2 3 4 5}"
  MAPS="${MAPS:-3 4 5 9}"
  STEPS_PER_MAP="${STEPS_PER_MAP:-100000}"
  EVAL_EPISODES="${EVAL_EPISODES:-50}"
else
  echo "[FATAL] MODE must be smoke or formal" >&2
  exit 2
fi

mkdir -p "$TRAIN_ROOT" "$LOG_ROOT"

log() {
  printf '[%s] %s\n' "$(date '+%F %T')" "$*" | tee -a "$MASTER_LOG"
}

is_checkpoint() {
  [[ -f "$1/algorithm_state.pkl" && -d "$1/policies/shared_policy" ]]
}

find_checkpoint() {
  find "$1" -type f -path '*/final/algorithm_state.pkl' -printf '%h\n' | sort | tail -n 1
}

checkpointed_steps() {
  local monitor="$1"
  awk -F ',' -v checkpoint_freq="$CHECKPOINT_FREQ" '
    NR == 1 {
      for (i = 1; i <= NF; i++) {
        if ($i == "environment_steps") steps_col = i
        if ($i == "iteration") iter_col = i
      }
      next
    }
    steps_col && iter_col && ($(iter_col) + 0) % checkpoint_freq == 0 {
      steps = $(steps_col) + 0
      if (steps > max_steps) max_steps = steps
    }
    END { print max_steps + 0 }
  ' "$monitor"
}

find_best_partial() {
  local out="$1" attempt_dir monitor checkpoint local_steps base_steps total_steps
  for attempt_dir in "$out"/attempt*; do
    [[ -d "$attempt_dir" ]] || continue
    base_steps=0
    if [[ -f "$attempt_dir/resume_base_steps.txt" ]]; then
      base_steps="$(<"$attempt_dir/resume_base_steps.txt")"
      [[ "$base_steps" =~ ^[0-9]+$ ]] || base_steps=0
    fi
    while IFS= read -r -d '' monitor; do
      checkpoint="$(dirname "$monitor")"
      is_checkpoint "$checkpoint" || continue
      local_steps="$(checkpointed_steps "$monitor")"
      [[ "$local_steps" =~ ^[0-9]+$ ]] || continue
      (( local_steps > 0 )) || continue
      total_steps=$((base_steps + local_steps))
      printf '%012d\t%s\n' "$total_steps" "$checkpoint"
    done < <(find "$attempt_dir" -type f -name training_monitor.csv -print0)
  done | sort -r -n -k1,1 | sed -n '1p'
}

next_attempt_number() {
  local out="$1" attempt_dir attempt_num max_attempt=0
  for attempt_dir in "$out"/attempt*; do
    [[ -d "$attempt_dir" ]] || continue
    attempt_num="${attempt_dir##*/attempt}"
    if [[ "$attempt_num" =~ ^[0-9]+$ ]] && (( attempt_num > max_attempt )); then
      max_attempt="$attempt_num"
    fi
  done
  echo $((max_attempt + 1))
}

variant_selected() {
  local candidate="$1" item
  [[ "$VARIANTS" == "all" ]] && return 0
  for item in $VARIANTS; do
    [[ "$candidate" == "$item" ]] && return 0
  done
  return 1
}

map_obstacles() {
  case "$1" in
    3|9) echo 6 ;;
    4) echo 2 ;;
    5) echo 0 ;;
    *) echo 0 ;;
  esac
}

wait_for_disk() {
  local required=$((MIN_FREE_GB * 1024 * 1024 * 1024)) available
  while true; do
    available="$(df --output=avail -B1 "$ROOT" | tail -n 1 | tr -d ' ')"
    if [[ "$available" =~ ^[0-9]+$ ]] && (( available >= required )); then
      return 0
    fi
    log "WAIT disk free=${available:-unknown} required_bytes=$required"
    sleep "$DISK_POLL_SEC"
  done
}

task_complete() {
  local variant="$1" seed="$2" map="$3" checkpoint_file
  checkpoint_file="$TRAIN_ROOT/$variant/seed${seed}/map${map}/checkpoint.txt"
  [[ -f "$checkpoint_file" ]] || return 1
  is_checkpoint "$(<"$checkpoint_file")" || return 1
  awk -F '\t' -v v="$variant" -v s="$seed" -v m="$map" \
    'NR>1 && $1==v && $2==s && $3==m && $4=="trained" {found=1} END{exit !found}' \
    "$MANIFEST"
}

append_manifest() {
  local line="$1"
  {
    flock 9
    printf '%s\n' "$line" >&9
  } 9>>"$MANIFEST"
}

run_chain() {
  local variant="$1" extra_args="$2" seed="$3" worker="$4"
  local resume="" map obstacles out attempt checkpoint rc suffix
  local first_attempt last_attempt attempt_dir partial partial_steps map_resume
  local resume_base_steps remaining_steps
  for map in $MAPS; do
    if [[ "$RESUME_ACROSS_MAPS" != "1" ]]; then
      resume=""
    fi
    if task_complete "$variant" "$seed" "$map"; then
      resume="$(<"$TRAIN_ROOT/$variant/seed${seed}/map${map}/checkpoint.txt")"
      log "SKIP TRAIN variant=$variant seed=$seed map=$map checkpoint=$resume"
      continue
    fi
    obstacles="$(map_obstacles "$map")"
    wait_for_disk
    out="$TRAIN_ROOT/$variant/seed${seed}/map${map}"
    mkdir -p "$out"
    checkpoint=""
    rc=1
    first_attempt="$(next_attempt_number "$out")"
    last_attempt=$((first_attempt + MAX_RETRIES - 1))
    for ((attempt=first_attempt; attempt<=last_attempt; attempt++)); do
      local -a cmd resume_args args_array
      map_resume="$resume"
      resume_base_steps=0
      partial="$(find_best_partial "$out")"
      if [[ -n "$partial" ]]; then
        partial_steps="$((10#${partial%%$'\t'*}))"
        if (( partial_steps > resume_base_steps )); then
          resume_base_steps="$partial_steps"
          map_resume="${partial#*$'\t'}"
        fi
      fi
      if (( resume_base_steps >= STEPS_PER_MAP )); then
        checkpoint="$map_resume"
        rc=0
        log "RECOVER COMPLETE variant=$variant seed=$seed map=$map steps=$resume_base_steps checkpoint=$checkpoint"
        break
      fi
      remaining_steps=$((STEPS_PER_MAP - resume_base_steps))
      suffix="${RUN_TAG}_${variant}_seed${seed}_map${map}_a${attempt}"
      read -r -a args_array <<< "$extra_args"
      resume_args=()
      if [[ -n "$map_resume" ]]; then
        resume_args=(--resume "$map_resume" --exact_resume)
      fi
      attempt_dir="$out/attempt${attempt}"
      mkdir -p "$attempt_dir"
      printf '%s\n' "$resume_base_steps" >"$attempt_dir/resume_base_steps.txt"
      printf '%s\n' "$map_resume" >"$attempt_dir/resume_checkpoint.txt"
      cmd=(
        bash "$TRAIN_RUNNER"
        --curriculum_preset narrow_corridor
        --action_mode continuous --ppo_profile auto
        --num_agents 4 --num_workers 1 --start_stage 1 --end_stage 1
        --map_number "$map" --num_obstacles "$obstacles" --num_static_obstacles 0
        --obs_speed_scale 0.25 --safety_filter_enable "$TRAIN_SAFETY_FILTER"
        --allow_shield_during_training "$ALLOW_SHIELD_DURING_TRAINING"
        --train_steps "$remaining_steps" --train_batch_size 2000 --rollout_fragment_length 200
        --checkpoint_freq "$CHECKPOINT_FREQ" --sample_timeout_s 1200 --batch_mode truncate_episodes
        --seed "$seed" --run_suffix "$suffix" --output_dir "$attempt_dir"
        --ray_num_cpus "$RAY_CPUS_PER_RUN" --ray_num_gpus "$RAY_GPU_PER_RUN"
        --ray_object_store_memory_mb "$RAY_OBJECT_STORE_MEMORY_MB"
        --ros_domain_id "$((181 + worker))" --gazebo_port "$((12081 + worker))"
        --parallel_safe --headless_sim --disable_visualization --disable_rviz
        "${resume_args[@]}" "${args_array[@]}"
      )
      if [[ -n "$EARLY_STOP_PATIENCE_ITERS" ]]; then
        cmd+=(--early_stop_patience_iters "$EARLY_STOP_PATIENCE_ITERS")
      fi
      log "TRAIN variant=$variant seed=$seed map=$map attempt=$attempt completed=$resume_base_steps remaining=$remaining_steps target=$STEPS_PER_MAP resume=${map_resume:-none}"
      if TRAIN_VERBOSE=0 ENV_VERBOSE=0 RAY_memory_usage_threshold=0.97 MALLOC_ARENA_MAX=2 \
        OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 \
        "${cmd[@]}" >>"$LOG_ROOT/${variant}_seed${seed}_map${map}.log" 2>&1; then
        checkpoint="$(find_checkpoint "$attempt_dir")"
        if is_checkpoint "$checkpoint"; then
          rc=0
          break
        fi
        rc=3
      else
        rc=$?
      fi
      log "WARN variant=$variant seed=$seed map=$map attempt=$attempt rc=$rc"
    done
    if (( rc != 0 )) || ! is_checkpoint "$checkpoint"; then
      append_manifest "$variant"$'\t'"$seed"$'\t'"$map"$'\t'"failed"$'\t'"$STEPS_PER_MAP"$'\t'"$map_resume"$'\t\t'"$(date --iso-8601=seconds)"$'\t'"$extra_args"
      log "FATAL variant=$variant seed=$seed map=$map"
      return 3
    fi
    printf '%s\n' "$checkpoint" >"$out/checkpoint.txt"
    append_manifest "$variant"$'\t'"$seed"$'\t'"$map"$'\t'"trained"$'\t'"$STEPS_PER_MAP"$'\t'"$map_resume"$'\t'"$checkpoint"$'\t'"$(date --iso-8601=seconds)"$'\t'"$extra_args"
    if [[ "$RESUME_ACROSS_MAPS" == "1" ]]; then
      resume="$checkpoint"
    else
      resume=""
    fi
    log "DONE TRAIN variant=$variant seed=$seed map=$map checkpoint=$checkpoint"
  done
}

worker() {
  local worker_id="$1" index
  for ((index=worker_id; index<${#TASKS[@]}; index+=MAX_PARALLEL)); do
    IFS='|' read -r variant seed extra_args <<<"${TASKS[$index]}"
    run_chain "$variant" "$extra_args" "$seed" "$worker_id"
  done
}

main() {
  [[ -f "$MATRIX" ]] || { log "FATAL missing matrix=$MATRIX"; return 2; }
  if [[ ! -f "$MANIFEST" ]]; then
    printf 'variant\tseed\tmap\tstatus\tsteps\tresume\tcheckpoint\tcompleted_at\textra_args\n' >"$MANIFEST"
  fi
  cp -p "$MATRIX" "$LOG_ROOT/formal_training_matrix.tsv"
  sha256sum "$MATRIX" "$TRAIN_RUNNER" >"$LOG_ROOT/protocol_sha256.txt"
  TASKS=()
  while IFS=$'\t' read -r order covers variant extra_args; do
    [[ "$order" == "order" || -z "$variant" ]] && continue
    variant_selected "$variant" || continue
    for seed in $SEEDS; do
      TASKS+=("$variant|$seed|$extra_args")
    done
  done <"$MATRIX"
  log "PLAN phase=$MODE tasks=${#TASKS[@]} maps=[$MAPS] seeds=[$SEEDS] steps_per_map=$STEPS_PER_MAP parallel=$MAX_PARALLEL resume_across_maps=$RESUME_ACROSS_MAPS"
  local -a pids=()
  local worker_id failures=0 pid
  for ((worker_id=0; worker_id<MAX_PARALLEL; worker_id++)); do
    worker "$worker_id" &
    pids+=("$!")
  done
  for pid in "${pids[@]}"; do
    wait "$pid" || failures=$((failures + 1))
  done
  if (( failures > 0 )); then
    log "FAILED phase=$MODE worker_failures=$failures result=$TRAIN_ROOT"
    return 4
  fi
  log "COMPLETE phase=$MODE result=$TRAIN_ROOT manifest=$MANIFEST next=paired_evaluation"
}

main "$@"
