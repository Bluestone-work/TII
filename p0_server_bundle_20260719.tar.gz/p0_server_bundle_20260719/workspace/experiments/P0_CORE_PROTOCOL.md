# P0 Core Orthogonal Experiment Protocol

## Scope

P0 estimates architecture effects only. Value-difference shaping is disabled in
every method (`counterfactual_advantage_coef=0`). No legacy checkpoint is admitted.

The three primary methods are:

1. `p0_graph_off`: the MAPPO-LSTM actor trunk inside the identical graph-model
   shell, with the graph residual fixed to zero.
2. `p0_unified_graph`: robot and dynamic-obstacle tokens in one shared, widened
   GAT. Its active graph parameter count must be within 1% of Dual Graph.
3. `p0_dual_graph`: separate social and dynamic-obstacle GAT encoders followed
   by learned fusion.

The same model class instantiates all modules before architecture selection, so
the complete initial state hash is identical across methods for a given seed.
Graph-off is the primary controlled baseline. A standalone `model_type=mlp`
checkpoint may be reported separately, but is not substituted for Graph-off.

## Training

- Training seeds: 1, 2, and 3.
- Curriculum order: Map 4 then Map 9, exact optimizer/checkpoint continuation.
- Budget: 400,000 environment steps per map; early stopping disabled.
- Four robots; Map 4 uses two dynamic obstacles and Map 9 uses six.
- Common PPO hyperparameters, rewards, reset rules, obstacle speed, and safety
  filter setting. The action-modifying safety filter is disabled during training.
- Every output root must be empty. The runner rejects existing results rather
  than discovering or importing legacy checkpoints.

MAPPO is on-policy. Once policies differ, their action-conditioned transitions
cannot literally be identical without changing the experiment into offline RL.
The fairness requirement is therefore the same exogenous curriculum, reset
distribution, seed schedule, and simulator implementation, not identical
post-action transitions.

## Evaluation

- The final Map 9 checkpoint is evaluated without further updates.
- Primary maps: Map 4 (structured medium interaction) and Map 9 (strong
  interaction).
- Held-out robustness map: Map 5.
- Exactly 50 episode indices per map, method, and training seed.
- Start/goal routes and episode seeds are fixed by `p0_core_v1`.
- Dynamic-obstacle trajectories are precomputed as a function of episode seed
  and environment step. Wall-clock timers are disabled for paired episodes.
- The full obstacle position sequence is SHA-256 fingerprinted. Collection is
  rejected unless every method and seed has the same start/goal, episode seed,
  and trajectory fingerprint for each paired episode.
- Policy-only evaluation is primary; the safety filter is disabled.

## Reporting

Report `SR`, `TSR`, `CR`, and `Timeout` for every method/map/training seed, then
report mean and sample standard deviation across the three training seeds.
Episode-level paired bootstrap output is secondary and must not replace
training-seed variability.

Navigation efficiency is reported with successful-agent time-to-goal, mean path
length, and SPL. Successful-agent time-to-goal excludes failed agents and always
includes its successful-agent denominator.

## P1 Low-Cost Supplement

- Map 3 is evaluated for 50 paired episodes with the safety filter both off and
  on. The filter-off condition measures policy-only behavior; the filter-on
  condition exists to quantify deployment-filter intervention and is not
  substituted for the primary P0 comparison.
- Every episode reports the number of modified agent-actions, total executed
  agent-actions, and their ratio. Filter effects are paired on start, goal,
  episode seed, and dynamic-obstacle trajectory.
- Parameter and latency profiling uses the seed-1 final Map 9 checkpoint from
  each method. It reports total actor-critic shell parameters, effective actor
  parameters, and active graph parameters.
- Actor latency is stratified by fixed CPU/GPU hardware. A team decision cycle
  executes 1, 4, or 8 shared decentralized actors sequentially with fixed
  micro-batch size 1, after warm-up, while bypassing the training-only critic.
