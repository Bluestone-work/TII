#!/usr/bin/env python3
"""Static validation for the formal experiment matrix and scenario bank."""

from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path

from gnn_marl_training.formal_scenario_bank import get_scenario_bank


def option(args, name, default=None):
    match = re.search(rf"(?:^|\s){re.escape(name)}\s+([^\s]+)", args)
    return match.group(1) if match else default


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("matrix", type=Path)
    parser.add_argument("--experiment-order", type=Path)
    args = parser.parse_args()
    with args.matrix.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    variants = {row["variant"]: row for row in rows}
    expected = {
        "full", "ippo", "mlp_lstm", "no_cf", "social_only", "obstacle_only",
        "single_graph", "gate_none", "gate_fixed", "gate_scalar",
        "lambda_005", "lambda_010", "lambda_030", "lambda_050",
        "mask_mean_agent", "mask_social", "mask_obstacle",
        "target_critic", "frozen_critic",
    }
    if set(variants) != expected:
        raise ValueError(f"variant matrix mismatch missing={expected-set(variants)} extra={set(variants)-expected}")
    lambda_values = {
        float(option(row["extra_args"], "--counterfactual_advantage_coef"))
        for row in rows
        if "exp5_" in row["covers"]
    }
    if lambda_values != {0.0, 0.05, 0.10, 0.15, 0.30, 0.50}:
        raise ValueError(f"lambda sweep mismatch: {sorted(lambda_values)}")
    gate_modes = {
        option(row["extra_args"], "--graph_gate_mode")
        for row in rows
        if "exp4_" in row["covers"]
    }
    if gate_modes != {"none", "fixed", "scalar", "vector"}:
        raise ValueError(f"gate modes mismatch: {gate_modes}")
    categories = {case.category for case in get_scenario_bank("paper_micro_v1")}
    if categories != {"head_on", "merge", "crossing", "bottleneck", "deadlock"}:
        raise ValueError(f"micro scenario categories mismatch: {categories}")
    orders = [int(row["order"]) for row in rows]
    if orders != sorted(orders) or len(orders) != len(set(orders)):
        raise ValueError("matrix order must be unique and ascending")
    if args.experiment_order:
        with args.experiment_order.open(newline="", encoding="utf-8") as handle:
            experiment_rows = list(csv.DictReader(handle, delimiter="\t"))
        experiment_orders = [int(row["order"]) for row in experiment_rows]
        if experiment_orders != list(range(1, 15)):
            raise ValueError(
                "formal experiment order must contain each experiment exactly once in order 1..14"
            )
    print(f"OK variants={len(rows)} lambdas={sorted(lambda_values)} gate_modes={sorted(gate_modes)}")


if __name__ == "__main__":
    main()
