#!/usr/bin/env python3
"""Project a full paired-rollout cost from a pilot and enforce a wall-time gate."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("pilot_summary", type=Path)
    parser.add_argument("--target-states", type=int, default=400)
    parser.add_argument("--max-hours", type=float, default=4.0)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    payload = json.loads(args.pilot_summary.read_text(encoding="utf-8"))
    pilot_states = int(payload["completed_states"])
    wall_seconds = float(payload["wall_seconds"])
    if pilot_states < 1 or not math.isfinite(wall_seconds) or wall_seconds <= 0.0:
        raise SystemExit("pilot summary needs positive completed_states and wall_seconds")
    projected_seconds = wall_seconds * args.target_states / pilot_states
    result = {
        "pilot_states": pilot_states,
        "pilot_wall_seconds": wall_seconds,
        "seconds_per_state": wall_seconds / pilot_states,
        "target_states": args.target_states,
        "projected_wall_seconds": projected_seconds,
        "projected_wall_hours": projected_seconds / 3600.0,
        "max_hours": args.max_hours,
        "gate_passed": projected_seconds <= args.max_hours * 3600.0,
    }
    rendered = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0 if result["gate_passed"] else 3


if __name__ == "__main__":
    raise SystemExit(main())
