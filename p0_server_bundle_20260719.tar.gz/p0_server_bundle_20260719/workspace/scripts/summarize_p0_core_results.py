#!/usr/bin/env python3
"""Write P0 per-seed outcomes and mean +/- SD across training seeds."""

from __future__ import annotations

import argparse
from collections import defaultdict
import csv
import json
import math
from pathlib import Path
import statistics


METHODS = ("p0_graph_off", "p0_unified_graph", "p0_dual_graph")
MAPS = (4, 9, 5)
SEEDS = (1, 2, 3)
METRICS = {
    "SR": "agent_success_rate",
    "TSR": "team_success",
    "CR": "collision_rate",
    "Timeout": "timeout_rate",
    "PathLength": "path_length",
    "SPL": "spl",
}
RATIO_METRICS = {
    "SuccessOnlyTTG": (
        "successful_agent_completion_time_sum",
        "successful_agent_completion_time_count",
    ),
    "FilterInterventionRate": (
        "filter_intervention_count",
        "filter_action_samples",
    ),
}
REPORT_METRICS = (
    "SR", "TSR", "CR", "Timeout", "SuccessOnlyTTG", "PathLength", "SPL",
    "FilterInterventionRate",
)


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def ratio(rows: list[dict], numerator: str, denominator: str) -> tuple[float, float, int]:
    numerator_sum = sum(float(row[numerator]) for row in rows)
    denominator_sum = sum(int(row[denominator]) for row in rows)
    value = numerator_sum / denominator_sum if denominator_sum else float("nan")
    return value, numerator_sum, denominator_sum


def display(value: float, digits: int = 3) -> str:
    return f"{value:.{digits}f}" if math.isfinite(value) else "NA"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--episodes", type=int, default=50)
    args = parser.parse_args()
    records = [
        json.loads(line)
        for line in args.input.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    grouped = defaultdict(list)
    for record in records:
        grouped[(
            str(record["method"]),
            int(record["map_number"]),
            int(record["training_seed"]),
        )].append(record)
    expected = {(method, map_number, seed) for method in METHODS for map_number in MAPS for seed in SEEDS}
    if set(grouped) != expected:
        missing = sorted(expected - set(grouped))
        extra = sorted(set(grouped) - expected)
        raise SystemExit(f"P0 coverage mismatch missing={missing} extra={extra}")

    per_seed = []
    for key in sorted(grouped):
        method, map_number, seed = key
        rows = grouped[key]
        if len(rows) != args.episodes:
            raise SystemExit(f"P0 episode count mismatch key={key} count={len(rows)}")
        output = {
            "method": method,
            "map_number": map_number,
            "training_seed": seed,
            "episodes": len(rows),
        }
        for label, field in METRICS.items():
            output[label] = statistics.fmean(float(row[field]) for row in rows)
        for label, (numerator, denominator) in RATIO_METRICS.items():
            value, numerator_sum, denominator_sum = ratio(rows, numerator, denominator)
            output[label] = value
            output[f"{label}_numerator"] = numerator_sum
            output[f"{label}_denominator"] = denominator_sum
        per_seed.append(output)

    across_seed = []
    for method in METHODS:
        for map_number in MAPS:
            rows = [
                row for row in per_seed
                if row["method"] == method and row["map_number"] == map_number
            ]
            output = {
                "method": method,
                "map_number": map_number,
                "n_training_seeds": len(rows),
            }
            for label in REPORT_METRICS:
                values = [float(row[label]) for row in rows]
                output[f"{label}_mean"] = statistics.fmean(values)
                output[f"{label}_std"] = statistics.stdev(values)
            across_seed.append(output)

    args.out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.out_dir / "per_training_seed.csv", per_seed)
    write_csv(args.out_dir / "mean_std_across_training_seeds.csv", across_seed)
    lines = [
        "# P0 Core Results",
        "",
        "Values are mean +/- sample standard deviation across three independent training seeds.",
        "Episodes are paired evaluation cases and are not treated as independent training runs.",
        "",
        "`Success-only TTG` is the mean simulated time over successful agents only. "
        "Filter intervention rate is modified agent-actions divided by all executed agent-actions.",
        "",
        "| Method | Map | SR | TSR | CR | Timeout | TTG success (s) | Path (m) | SPL | Filter rate |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in across_seed:
        cells = []
        for label in REPORT_METRICS:
            cells.append(
                f"{display(row[f'{label}_mean'])} +/- {display(row[f'{label}_std'])}"
            )
        lines.append(
            f"| {row['method']} | {row['map_number']} | " + " | ".join(cells) + " |"
        )
    (args.out_dir / "REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote P0 seed-aware results to {args.out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
