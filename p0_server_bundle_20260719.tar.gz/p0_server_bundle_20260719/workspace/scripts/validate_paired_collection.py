#!/usr/bin/env python3
"""Fail closed unless every method/filter result shares the frozen paired scenarios."""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path


def truthy(value):
    return value is True or str(value).strip().lower() in {"1", "true", "yes"}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--methods", nargs="+", required=True)
    parser.add_argument("--seeds", nargs="+", type=int, required=True)
    parser.add_argument("--conditions", nargs="+", required=True)
    parser.add_argument("--episodes-per-case", type=int, required=True)
    parser.add_argument("--scenario-manifest", type=Path)
    parser.add_argument("--eval-seed", type=int)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows = [json.loads(line) for line in args.input.read_text(encoding="utf-8").splitlines() if line.strip()]
    cases = sorted({str(row.get("scenario_case")) for row in rows})
    if args.scenario_manifest:
        document = json.loads(args.scenario_manifest.read_text(encoding="utf-8"))
        expected_cases = sorted(str(case["case_id"]) for case in document.get("cases", []))
    else:
        expected_cases = cases
    expected = len(args.methods) * len(args.seeds) * len(args.conditions) * len(cases) * args.episodes_per_case
    errors = []
    if cases != expected_cases:
        errors.append(f"scenario_cases={cases} expected={expected_cases}")
    expected = len(args.methods) * len(args.seeds) * len(args.conditions) * len(expected_cases) * args.episodes_per_case
    if len(rows) != expected:
        errors.append(f"records={len(rows)} expected={expected}")
    observed_keys = Counter()
    pairing = defaultdict(lambda: {"start": set(), "trajectory": set(), "episode_seed": set()})
    for row in rows:
        method = str(row.get("method"))
        seed = int(row.get("training_seed"))
        condition = str(row.get("experiment_condition"))
        case = str(row.get("scenario_case"))
        episode = int(row.get("episode_index"))
        observed_keys[(method, seed, condition, case, episode)] += 1
        if method not in args.methods or seed not in args.seeds or condition not in args.conditions:
            errors.append(f"unexpected result key={(method, seed, condition, case, episode)}")
        if not truthy(row.get("paired_scenario_eligible")):
            errors.append(f"ineligible paired row={(method, seed, condition, case, episode)}")
        if bool(row.get("shield_enable")) != (condition == "filter_on"):
            errors.append(f"filter attribution mismatch={(method, seed, condition, case, episode)}")
        unit = pairing[(case, episode)]
        unit["start"].add(str(row.get("initial_state_fingerprint") or ""))
        trajectory = str(row.get("dynamic_obstacle_trajectory_fingerprint") or "")
        if int(row.get("num_dynamic_obstacles") or 0) > 0:
            unit["trajectory"].add(trajectory)
        unit["episode_seed"].add(int(row.get("episode_seed")))
        if args.eval_seed is not None and int(row.get("episode_seed")) != args.eval_seed + episode:
            errors.append(f"episode seed schedule mismatch unit={(case, episode)}")
    duplicates = [key for key, count in observed_keys.items() if count != 1]
    if duplicates:
        errors.append(f"duplicate/missing unique keys={duplicates[:5]}")
    for unit, fingerprints in pairing.items():
        if any(len(fingerprints[name]) != 1 for name in ("start", "episode_seed")):
            errors.append(f"unpaired start or seed unit={unit}")
        if fingerprints["trajectory"] and (
            len(fingerprints["trajectory"]) != 1 or "" in fingerprints["trajectory"]
        ):
            errors.append(f"unpaired dynamic trajectory unit={unit}")
    summary = {
        "status": "failed" if errors else "ok",
        "records": len(rows),
        "expected_records": expected,
        "methods": sorted(set(args.methods)),
        "training_seeds": sorted(set(args.seeds)),
        "conditions": sorted(set(args.conditions)),
        "scenario_cases": cases,
        "paired_units": len(pairing),
        "errors": errors[:100],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if errors:
        raise SystemExit("paired collection validation failed: " + "; ".join(errors[:5]))
    print(f"OK paired collection: records={len(rows)} units={len(pairing)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
