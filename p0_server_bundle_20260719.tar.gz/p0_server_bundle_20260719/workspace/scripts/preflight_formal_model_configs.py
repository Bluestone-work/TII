#!/usr/bin/env python3
"""Instantiate and forward-check every new graph/CF configuration family."""

from __future__ import annotations

import argparse
import pickle
from pathlib import Path

import torch
from ray.rllib.models import ModelCatalog
from ray.rllib.policy.policy import Policy

from gnn_marl_training.counterfactual_ppo_policy import register_counterfactual_policy
from gnn_marl_training.gat_rllib_model import GATRLlibModel, MODEL_NAME


CONFIGS = (
    ("dual", "vector", "zero_agent", "online"),
    ("single", "vector", "zero_agent", "online"),
    ("dual", "none", "mean_agent", "online"),
    ("dual", "fixed", "zero_social", "online"),
    ("dual", "scalar", "zero_obstacle", "target"),
    ("dual", "vector", "zero_agent", "frozen"),
)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("checkpoint", type=Path)
    args = parser.parse_args()
    checkpoint = args.checkpoint.resolve()
    ModelCatalog.register_custom_model(MODEL_NAME, GATRLlibModel)
    register_counterfactual_policy()
    policy = Policy.from_checkpoint(str(checkpoint / "policies" / "shared_policy"))
    with (checkpoint / "algorithm_state.pkl").open("rb") as handle:
        model_config = pickle.load(handle)["config"]["model"]

    for architecture, gate, mask, source in CONFIGS:
        config = dict(model_config)
        custom = dict(config["custom_model_config"])
        custom.update(
            graph_architecture=architecture,
            graph_gate_mode=gate,
            counterfactual_mask_strategy=mask,
            counterfactual_critic_source=source,
        )
        config["custom_model_config"] = custom
        model = GATRLlibModel(
            policy.observation_space,
            policy.action_space,
            policy.model.num_outputs,
            config,
            f"preflight_{architecture}_{gate}_{mask}_{source}",
        )
        observations = torch.zeros((2, policy.observation_space.shape[0]), dtype=torch.float32)
        state = [
            torch.zeros((2, model.lstm_hidden_dim)),
            torch.zeros((2, model.lstm_hidden_dim)),
        ]
        action, _ = model(
            {"obs": observations, "obs_flat": observations},
            state,
            torch.tensor([1, 1]),
        )
        full = model.compute_full_values(observations)
        masked = model.compute_counterfactual_values(observations, torch.tensor([0, 1]))
        if not (
            action.shape[0] == 2
            and full.shape == masked.shape == (2,)
            and torch.isfinite(action).all()
            and torch.isfinite(full).all()
            and torch.isfinite(masked).all()
        ):
            raise RuntimeError(f"non-finite output for {(architecture, gate, mask, source)}")
        print(f"OK architecture={architecture} gate={gate} mask={mask} critic={source}")


if __name__ == "__main__":
    main()
