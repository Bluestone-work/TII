#!/usr/bin/env python3
"""Aggregate training stability and evaluation metrics for parameter sweeps."""

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def finite(values) -> np.ndarray:
    array = np.asarray(list(values), dtype=float)
    return array[np.isfinite(array)]


def mean(values) -> float:
    array = finite(values)
    return float(np.mean(array)) if array.size else float("nan")


def bootstrap_ci(values, rng: np.random.Generator, samples: int = 10000) -> tuple[float, float]:
    array = finite(values)
    if not array.size:
        return float("nan"), float("nan")
    if array.size == 1:
        return float(array[0]), float(array[0])
    indices = rng.integers(0, array.size, size=(samples, array.size))
    boot = np.mean(array[indices], axis=1)
    low, high = np.percentile(boot, [2.5, 97.5])
    return float(low), float(high)


def read_manifest(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    latest = {}
    for row in rows:
        latest[(row["phase"], row["candidate"], row["map"], row["seed"])] = row
    return list(latest.values())


def training_metrics(path: Path) -> dict:
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    steps, rewards = [], []
    for row in rows:
        try:
            step = float(row["timesteps"])
            reward = float(row["episode_reward_mean"])
        except (KeyError, TypeError, ValueError):
            continue
        if math.isfinite(step) and math.isfinite(reward):
            steps.append(step)
            rewards.append(reward)
    if not rewards:
        return {
            "training_auc": float("nan"),
            "convergence_step": float("nan"),
            "final_reward": float("nan"),
            "peak_reward": float("nan"),
        }
    x = np.asarray(steps, dtype=float)
    y = np.asarray(rewards, dtype=float)
    order = np.argsort(x)
    x, y = x[order], y[order]
    window = min(10, y.size)
    smooth = np.convolve(y, np.ones(window) / window, mode="valid")
    smooth_x = x[window - 1:]
    auc = float(np.trapezoid(y, x) / max(1.0, x[-1] - x[0])) if y.size > 1 else float(y[0])
    low, high = float(np.min(smooth)), float(np.max(smooth))
    target = low + 0.9 * (high - low)
    convergence = float(smooth_x[-1])
    # Require three complete consecutive smoothed points.  Treating the final
    # one or two points as a full persistence window biases convergence early.
    persistence = min(3, smooth.size)
    for index in range(smooth.size - persistence + 1):
        if np.all(smooth[index:index + persistence] >= target):
            convergence = float(smooth_x[index])
            break
    return {
        "training_auc": auc,
        "convergence_step": convergence,
        "final_reward": float(np.mean(y[-window:])),
        "peak_reward": float(np.max(smooth)),
    }


def evaluation_metrics(path: Path) -> dict:
    records = []
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(record, dict):
                records.append(record)
    completion = [
        float(record.get("reached_agents") or 0) / max(1, int(record.get("num_agents") or 1))
        for record in records
    ]
    collision = [
        float(record.get("collided_agents") or 0) / max(1, int(record.get("num_agents") or 1))
        for record in records
    ]
    return {
        "n_episodes": len(records),
        "agent_success_pct": 100.0 * mean(completion),
        "team_success_pct": 100.0 * mean(value >= 1.0 for value in completion),
        "agent_collision_pct": 100.0 * mean(collision),
        "timeout_pct": 100.0 * mean(bool(record.get("truncated")) for record in records),
        "min_lidar_m": mean(record.get("min_dist", math.nan) for record in records),
        "inference_ms_p95": mean(record.get("inference_ms_p95", math.nan) for record in records),
    }


def build_run_rows(manifest_rows: list[dict]) -> list[dict]:
    runs = []
    for row in manifest_rows:
        monitor = Path(row["monitor_csv"])
        episodes = Path(row["eval_jsonl"])
        if not monitor.is_file() or not episodes.is_file():
            continue
        run = dict(row)
        for key in ("map", "seed", "train_steps"):
            run[key] = int(run[key])
        for key in ("counterfactual_coef", "risk_bias", "gate_bias", "predictive_horizon"):
            run[key] = float(run[key])
        run.update(training_metrics(monitor))
        run.update(evaluation_metrics(episodes))
        run["selection_score"] = (
            run["agent_success_pct"]
            - run["agent_collision_pct"]
            - 0.5 * run["timeout_pct"]
        )
        runs.append(run)
    return runs


def write_csv(rows: list[dict], path: Path) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def summarize(runs: list[dict]) -> list[dict]:
    groups = defaultdict(list)
    for run in runs:
        groups[(run["candidate"], run["map"])].append(run)
    rng = np.random.default_rng(20260713)
    rows = []
    metrics = [
        "agent_success_pct", "team_success_pct", "agent_collision_pct", "timeout_pct",
        "min_lidar_m", "training_auc", "convergence_step", "final_reward", "selection_score",
    ]
    for (candidate, map_number), items in sorted(groups.items()):
        first = items[0]
        row = {
            key: first[key] for key in (
                "candidate", "factor", "factor_value", "counterfactual_coef",
                "risk_bias", "gate_bias", "predictive_horizon",
            )
        }
        row.update({"map": map_number, "n_training_seeds": len({item["seed"] for item in items})})
        for metric in metrics:
            values = [item[metric] for item in items]
            avg = mean(values)
            finite_values = finite(values)
            std = (
                float(np.std(finite_values, ddof=1))
                if finite_values.size > 1
                else (0.0 if finite_values.size == 1 else float("nan"))
            )
            low, high = bootstrap_ci(values, rng)
            row[f"{metric}_mean"] = avg
            row[f"{metric}_std"] = std
            row[f"{metric}_ci_low"] = low
            row[f"{metric}_ci_high"] = high
            row[f"{metric}_cv"] = std / abs(avg) if math.isfinite(avg) and abs(avg) > 1e-9 else float("nan")
        rows.append(row)
    return rows


def ranking(runs: list[dict]) -> list[dict]:
    screening = [run for run in runs if run["phase"] == "screening" and run["seed"] == 1]
    groups = defaultdict(list)
    for run in screening:
        groups[run["candidate"]].append(run)
    rows = []
    for candidate, items in groups.items():
        if {item["map"] for item in items} != {4, 9}:
            continue
        first = items[0]
        rows.append({
            "candidate": candidate,
            "factor": first["factor"],
            "factor_value": first["factor_value"],
            "counterfactual_coef": first["counterfactual_coef"],
            "risk_bias": first["risk_bias"],
            "gate_bias": first["gate_bias"],
            "predictive_horizon": first["predictive_horizon"],
            "cross_map_selection_score": mean(item["selection_score"] for item in items),
            "cross_map_agent_success_pct": mean(item["agent_success_pct"] for item in items),
            "cross_map_agent_collision_pct": mean(item["agent_collision_pct"] for item in items),
            "cross_map_timeout_pct": mean(item["timeout_pct"] for item in items),
            "cross_map_training_auc": mean(item["training_auc"] for item in items),
        })
    return sorted(rows, key=lambda row: row["cross_map_selection_score"], reverse=True)


def plot_screening(rank_rows: list[dict], out_dir: Path) -> None:
    specs = [
        ("counterfactual", "counterfactual_coef", r"$\lambda_{cf}$", 0.15),
        ("risk_bias", "risk_bias", r"Risk bias $\beta$", 2.5),
        ("gate_bias", "gate_bias", r"Gate bias $b_g$", -1.0),
        ("horizon", "predictive_horizon", "Predictive horizon (s)", 1.2),
    ]
    baseline = next((row for row in rank_rows if row["candidate"] == "baseline"), None)
    fig, axes = plt.subplots(2, 2, figsize=(9, 7), dpi=220)
    for ax, (factor, value_key, xlabel, baseline_value) in zip(axes.flat, specs):
        selected = [row for row in rank_rows if row["factor"] == factor]
        if baseline is not None:
            selected.append(dict(baseline, **{value_key: baseline_value}))
        selected.sort(key=lambda row: float(row[value_key]))
        x = [float(row[value_key]) for row in selected]
        ax.plot(x, [row["cross_map_agent_success_pct"] for row in selected], marker="o", label="Success")
        ax.plot(x, [row["cross_map_agent_collision_pct"] for row in selected], marker="s", label="Collision")
        ax.plot(x, [row["cross_map_timeout_pct"] for row in selected], marker="^", label="Timeout")
        ax.set_xlabel(xlabel)
        ax.set_ylabel("Rate (%)")
        ax.grid(alpha=0.25)
    axes[0, 0].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out_dir / "parameter_screening_outcomes.png", bbox_inches="tight")
    fig.savefig(out_dir / "parameter_screening_outcomes.pdf", bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args()
    runs = build_run_rows(read_manifest(args.manifest))
    if not runs:
        raise SystemExit("No completed sensitivity runs found")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    summaries = summarize(runs)
    rank_rows = ranking(runs)
    write_csv(runs, args.out_dir / "parameter_sensitivity_runs.csv")
    write_csv(summaries, args.out_dir / "parameter_sensitivity_summary.csv")
    write_csv(rank_rows, args.out_dir / "parameter_ranking.csv")
    if rank_rows:
        plot_screening(rank_rows, args.out_dir)
    print(f"wrote {len(runs)} runs, {len(summaries)} summaries, {len(rank_rows)} rankings")


if __name__ == "__main__":
    main()
