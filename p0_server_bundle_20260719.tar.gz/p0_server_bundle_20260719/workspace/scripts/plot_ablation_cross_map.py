#!/usr/bin/env python3
"""Aggregate and plot cross-map evaluation results for ablation variants."""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


METHODS = ["ours_dual_cf", "ours_dual", "social_only", "obstacle_only"]
METHOD_LABELS = {
    "ours_dual_cf": "Full (Dual graph + CF)",
    "ours_dual": "Dual graph (no CF)",
    "social_only": "Social only",
    "obstacle_only": "Obstacle only",
}
MAPS = [3, 4, 5, 9]
MAP_LABELS = {3: "Map 3", 4: "Map 4", 5: "Map 5", 9: "Map 9"}
COLORS = ["#2878B5", "#7A5195", "#E88B2D", "#3FA65B"]


def load_records(path: Path) -> list[dict]:
    records = []
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(record, dict):
                records.append(record)
    return records


def mean(values) -> float:
    values = np.asarray(list(values), dtype=float)
    values = values[np.isfinite(values)]
    return float(np.mean(values)) if values.size else float("nan")


def mean_std_by_training_seed(items: list[dict], values) -> tuple[float, float, int, str]:
    grouped = defaultdict(list)
    finite_values = []
    for item, value in zip(items, values):
        try:
            value = float(value)
        except (TypeError, ValueError):
            continue
        if not np.isfinite(value):
            continue
        finite_values.append(value)
        seed = item.get("training_seed")
        if seed is not None:
            grouped[int(seed)].append(value)
    if len(grouped) >= 2:
        units = np.asarray([np.mean(grouped[seed]) for seed in sorted(grouped)], dtype=float)
        level = "training_seed"
    else:
        units = np.asarray(finite_values, dtype=float)
        level = "episode"
    if not units.size:
        return float("nan"), float("nan"), len(grouped), level
    return float(np.mean(units)), float(np.std(units)), len(grouped), level


def aggregate(records: list[dict]) -> list[dict]:
    groups: dict[tuple[str, int], list[dict]] = defaultdict(list)
    for record in records:
        try:
            key = (str(record.get("method")), int(record.get("map_number")))
        except (TypeError, ValueError):
            continue
        groups[key].append(record)

    rows = []
    for method in METHODS:
        for map_number in MAPS:
            items = groups.get((method, map_number), [])
            if not items:
                continue
            completion = [
                float(item.get("reached_agents") or 0) / max(1, int(item.get("num_agents") or 1))
                for item in items
            ]
            collision = [
                float(item.get("collided_agents") or 0) / max(1, int(item.get("num_agents") or 1))
                for item in items
            ]
            metric_values = {
                "agent_success_pct": [100.0 * value for value in completion],
                "team_success_pct": [100.0 * float(value >= 1.0) for value in completion],
                "agent_collision_pct": [100.0 * value for value in collision],
                "timeout_pct": [100.0 * float(bool(item.get("truncated"))) for item in items],
                "episode_steps": [item.get("steps", np.nan) for item in items],
                "avg_reward": [item.get("avg_reward", np.nan) for item in items],
                "min_lidar_m": [item.get("min_dist", np.nan) for item in items],
                "shield_activation": [item.get("avg_shield_active", np.nan) for item in items],
            }
            summaries = {
                name: mean_std_by_training_seed(items, values)
                for name, values in metric_values.items()
            }
            seed_count = max((summary[2] for summary in summaries.values()), default=0)
            aggregation_level = "training_seed" if seed_count >= 2 else "episode"
            rows.append({
                "method": method,
                "method_label": METHOD_LABELS[method],
                "map_number": map_number,
                "n_episodes": len(items),
                "n_training_seeds": seed_count,
                "aggregation_level": aggregation_level,
                **{
                    key: value
                    for name, summary in summaries.items()
                    for key, value in ((name, summary[0]), (f"{name}_std", summary[1]))
                },
            })
    return rows


def write_csv(rows: list[dict], path: Path) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_latex(rows: list[dict], path: Path) -> None:
    by_key = {(row["method"], row["map_number"]): row for row in rows}
    lines = [
        r"\begin{table*}[t]",
        r"\centering",
        r"\caption{Cross-map evaluation of the trained ablation variants.}",
        r"\label{tab:ablation_cross_map}",
        r"\begin{tabular}{llrrrr}",
        r"\toprule",
        r"Map & Variant & Agent success (\%) & Team success (\%) & Collision (\%) & Timeout (\%) \\",
        r"\midrule",
    ]
    for map_number in MAPS:
        for method in METHODS:
            row = by_key.get((method, map_number))
            if row is None:
                continue
            lines.append(
                f"{MAP_LABELS[map_number]} & {METHOD_LABELS[method]} & "
                f"{row['agent_success_pct']:.1f} & {row['team_success_pct']:.1f} & "
                f"{row['agent_collision_pct']:.1f} & {row['timeout_pct']:.1f} \\\\"
            )
        lines.append(r"\midrule")
    lines[-1] = r"\bottomrule"
    lines.extend([r"\end{tabular}", r"\end{table*}"])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def value_matrix(rows: list[dict], metric: str) -> np.ndarray:
    lookup = {(row["method"], row["map_number"]): row for row in rows}
    return np.asarray([
        [lookup.get((method, map_number), {}).get(metric, np.nan) for map_number in MAPS]
        for method in METHODS
    ], dtype=float)


def plot_bars(rows: list[dict], out_dir: Path) -> None:
    specs = [
        ("agent_success_pct", "Agent success (%)"),
        ("team_success_pct", "Full-team success (%)"),
        ("agent_collision_pct", "Agent collision (%)"),
        ("timeout_pct", "Timeout episodes (%)"),
    ]
    x = np.arange(len(MAPS))
    width = 0.19
    fig, axes = plt.subplots(2, 2, figsize=(12, 8), dpi=220)
    for ax, (metric, title) in zip(axes.flat, specs):
        matrix = value_matrix(rows, metric)
        error_matrix = value_matrix(rows, f"{metric}_std")
        for index, method in enumerate(METHODS):
            ax.bar(
                x + (index - (len(METHODS) - 1) / 2.0) * width,
                matrix[index],
                width,
                yerr=error_matrix[index],
                capsize=2,
                label=METHOD_LABELS[method],
                color=COLORS[index],
                edgecolor="black",
                linewidth=0.6,
            )
        ax.set_title(title)
        ax.set_xticks(x, [MAP_LABELS[value] for value in MAPS])
        ax.set_ylim(0.0, 105.0)
        ax.grid(axis="y", alpha=0.25)
    axes[0, 0].legend(fontsize=8, ncol=1)
    fig.tight_layout()
    fig.savefig(out_dir / "ablation_cross_map_outcomes.png", bbox_inches="tight")
    fig.savefig(out_dir / "ablation_cross_map_outcomes.pdf", bbox_inches="tight")
    plt.close(fig)


def plot_heatmaps(rows: list[dict], out_dir: Path) -> None:
    specs = [
        ("agent_success_pct", "Agent success (%)", "YlGn"),
        ("team_success_pct", "Full-team success (%)", "YlGn"),
        ("agent_collision_pct", "Agent collision (%)", "YlOrRd"),
        ("timeout_pct", "Timeout episodes (%)", "YlOrRd"),
    ]
    fig, axes = plt.subplots(2, 2, figsize=(11, 7.5), dpi=220)
    for ax, (metric, title, cmap) in zip(axes.flat, specs):
        matrix = value_matrix(rows, metric)
        image = ax.imshow(matrix, cmap=cmap, vmin=0.0, vmax=100.0, aspect="auto")
        ax.set_title(title)
        ax.set_xticks(range(len(MAPS)), [MAP_LABELS[value] for value in MAPS])
        ax.set_yticks(range(len(METHODS)), [METHOD_LABELS[value] for value in METHODS])
        for row_index in range(matrix.shape[0]):
            for column_index in range(matrix.shape[1]):
                value = matrix[row_index, column_index]
                if np.isfinite(value):
                    ax.text(column_index, row_index, f"{value:.1f}", ha="center", va="center", fontsize=9)
        fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(out_dir / "ablation_cross_map_heatmaps.png", bbox_inches="tight")
    fig.savefig(out_dir / "ablation_cross_map_heatmaps.pdf", bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("episodes_jsonl", type=Path)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    rows = aggregate(load_records(args.episodes_jsonl))
    if not rows:
        raise SystemExit("No ablation records found")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(rows, args.out_dir / "ablation_cross_map_metrics.csv")
    write_latex(rows, args.out_dir / "ablation_cross_map_table.tex")
    plot_bars(rows, args.out_dir)
    plot_heatmaps(rows, args.out_dir)
    print(f"wrote {len(rows)} method-map summaries to {args.out_dir}")


if __name__ == "__main__":
    main()
