#!/usr/bin/env python3
"""Fail when formal per-iteration training logs omit required columns or values."""

from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path


REQUIRED_FIELDS = (
    "environment_steps", "episode_reward", "agent_success", "team_success",
    "collision_rate", "timeout_rate", "policy_loss", "value_loss", "entropy",
    "KL", "clip_fraction", "explained_variance", "gradient_norm",
    "advantage_mean", "advantage_std", "credit_mean", "credit_std",
    "credit_sign_flip_rate", "gate_mean", "gate_std", "training_fps",
    "GPU_memory",
)

LEARNER_FIELDS = (
    "policy_loss", "value_loss", "entropy", "KL", "clip_fraction",
    "explained_variance", "gradient_norm", "advantage_mean", "advantage_std",
    "credit_mean", "credit_std", "credit_sign_flip_rate", "gate_mean", "gate_std",
    "training_fps",
)


def has_finite(rows, field):
    for row in rows:
        try:
            if math.isfinite(float(row.get(field, ""))):
                return True
        except (TypeError, ValueError):
            continue
    return False


def validate(path, require_gpu=False):
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        fields = set(reader.fieldnames or ())
    missing = sorted(set(REQUIRED_FIELDS) - fields)
    empty = sorted(field for field in LEARNER_FIELDS if not has_finite(rows, field))
    if require_gpu and not has_finite(rows, "GPU_memory"):
        empty.append("GPU_memory")
    if not rows:
        empty.append("<no_rows>")
    return missing, sorted(set(empty))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("paths", nargs="+", type=Path)
    parser.add_argument("--require-gpu", action="store_true")
    args = parser.parse_args()
    failures = []
    for path in args.paths:
        missing, empty = validate(path, require_gpu=args.require_gpu)
        if missing or empty:
            failures.append((path, missing, empty))
        else:
            print(f"OK {path}")
    if failures:
        for path, missing, empty in failures:
            print(f"FAIL {path} missing_columns={missing} no_finite_values={empty}")
        raise SystemExit(2)


if __name__ == "__main__":
    main()
