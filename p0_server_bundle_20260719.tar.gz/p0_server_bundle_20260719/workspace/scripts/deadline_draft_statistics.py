#!/usr/bin/env python3
"""Time-boxed statistics that keep training-seed and episode uncertainty separate."""

from __future__ import annotations

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy import stats


METRICS = (
    "agent_success_rate",
    "team_success",
    "collision_rate",
    "timeout_rate",
    "spl",
    "completion_time",
    "minimum_clearance",
    "clearance_p05",
    "minimum_ttc",
    "near_collision_count",
    "deadlock",
    "policy_only_inference_latency_ms_mean",
    "safety_filter_latency_ms_mean",
    "real_time_factor",
)
MAIN_METHODS = frozenset({"full", "ippo", "mlp_lstm", "orca_dwa"})
ABLATION_METHODS = frozenset({"full", "no_cf", "social_only", "obstacle_only"})
NON_LEARNING = frozenset({"orca_dwa"})


def finite(value):
    if isinstance(value, bool):
        return float(value)
    text = str(value).strip().lower()
    if text in {"true", "false"}:
        return float(text == "true")
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def truthy(value) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def load(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(rows[0])
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def values(rows: list[dict], metric: str) -> list[float]:
    return [number for row in rows if (number := finite(row.get(metric))) is not None]


def percentile_interval(samples: np.ndarray) -> tuple[float, float]:
    low, high = np.percentile(samples, [2.5, 97.5])
    return float(low), float(high)


def episode_bootstrap(data: list[float], rng, samples: int) -> tuple[float, float]:
    array = np.asarray(data, dtype=float)
    indices = rng.integers(0, len(array), size=(samples, len(array)))
    return percentile_interval(array[indices].mean(axis=1))


def hierarchical_bootstrap(grouped: dict[int, list[float]], rng, samples: int):
    seeds = sorted(grouped)
    draws = np.empty(samples, dtype=float)
    for index in range(samples):
        selected = rng.choice(seeds, size=len(seeds), replace=True)
        seed_means = []
        for seed in selected:
            array = np.asarray(grouped[int(seed)], dtype=float)
            seed_means.append(float(np.mean(rng.choice(array, size=len(array), replace=True))))
        draws[index] = float(np.mean(seed_means))
    return percentile_interval(draws)


def analysis_rows(records: list[dict], analysis: str) -> list[dict]:
    if analysis == "main_seed1":
        return [
            row for row in records
            if row.get("method") in MAIN_METHODS
            and int(float(row.get("training_seed") or 0)) in {0, 1}
        ]
    return [row for row in records if row.get("method") in ABLATION_METHODS]


def condition_summaries(records: list[dict], rng, samples: int) -> list[dict]:
    output = []
    for analysis in ("main_seed1", "core_ablation_seed12"):
        subset = analysis_rows(records, analysis)
        groups = defaultdict(list)
        for row in subset:
            groups[(row.get("method"), int(float(row.get("map_number") or 0)))].append(row)
        for (method, map_number), items in sorted(groups.items()):
            for metric in METRICS:
                by_seed = defaultdict(list)
                for row in items:
                    number = finite(row.get(metric))
                    if number is not None:
                        by_seed[int(float(row.get("training_seed") or 0))].append(number)
                by_seed = {seed: data for seed, data in by_seed.items() if data}
                if not by_seed:
                    continue
                learning_seeds = sorted(seed for seed in by_seed if method not in NON_LEARNING)
                seed_means = [float(np.mean(by_seed[seed])) for seed in sorted(by_seed)]
                estimate = float(np.mean(seed_means))
                if len(learning_seeds) >= 2:
                    low, high = hierarchical_bootstrap(by_seed, rng, samples)
                    aggregation = "hierarchical_training_seed_then_episode"
                    seed_std = float(np.std(seed_means, ddof=1))
                else:
                    pooled = [number for data in by_seed.values() for number in data]
                    low, high = episode_bootstrap(pooled, rng, samples)
                    aggregation = "evaluation_episode_fixed_checkpoint"
                    seed_std = float("nan")
                output.append({
                    "analysis": analysis,
                    "method": method,
                    "map_number": map_number,
                    "metric": metric,
                    "estimate": estimate,
                    "ci95_low": low,
                    "ci95_high": high,
                    "training_seed_std": seed_std,
                    "n_training_seeds": 0 if method in NON_LEARNING else len(learning_seeds),
                    "n_evaluation_episodes": sum(len(data) for data in by_seed.values()),
                    "aggregation_level": aggregation,
                    "supports_training_seed_stability_claim": len(learning_seeds) >= 3,
                })
    return output


def cliffs_delta(left: list[float], right: list[float]) -> float:
    a, b = np.asarray(left), np.asarray(right)
    return float((np.sum(a[:, None] > b) - np.sum(a[:, None] < b)) / (len(a) * len(b)))


def paired_values(reference: list[dict], candidate: list[dict], metric: str):
    def keyed(rows):
        result = {}
        for row in rows:
            value = finite(row.get(metric))
            fingerprint = str(row.get("initial_state_fingerprint") or "")
            if value is None or not fingerprint or not truthy(row.get("paired_scenario_eligible")):
                continue
            key = (int(float(row.get("episode_index") or 0)), fingerprint)
            result[key] = value
        return result

    left, right = keyed(reference), keyed(candidate)
    common = sorted(set(left) & set(right))
    return [left[key] for key in common], [right[key] for key in common]


def bootstrap_difference(reference: dict[int, list[float]], candidate: dict[int, list[float]], rng, samples):
    common = sorted(set(reference) & set(candidate))
    draws = np.empty(samples, dtype=float)
    for index in range(samples):
        selected = rng.choice(common, size=len(common), replace=True)
        differences = []
        for seed in selected:
            ref = np.asarray(reference[int(seed)], dtype=float)
            alt = np.asarray(candidate[int(seed)], dtype=float)
            ref_mean = float(np.mean(rng.choice(ref, size=len(ref), replace=True)))
            alt_mean = float(np.mean(rng.choice(alt, size=len(alt), replace=True)))
            differences.append(alt_mean - ref_mean)
        draws[index] = float(np.mean(differences))
    return percentile_interval(draws)


def pairwise_summaries(records: list[dict], rng, samples: int) -> list[dict]:
    output = []
    for analysis in ("main_seed1", "core_ablation_seed12"):
        subset = analysis_rows(records, analysis)
        methods = sorted({row.get("method") for row in subset if row.get("method") != "full"})
        maps = sorted({int(float(row.get("map_number") or 0)) for row in subset})
        for method in methods:
            for map_number in maps:
                reference_rows = [row for row in subset if row.get("method") == "full" and int(float(row.get("map_number") or 0)) == map_number]
                candidate_rows = [row for row in subset if row.get("method") == method and int(float(row.get("map_number") or 0)) == map_number]
                for metric in METRICS:
                    reference_by_seed = defaultdict(list)
                    candidate_by_seed = defaultdict(list)
                    for row in reference_rows:
                        if (number := finite(row.get(metric))) is not None:
                            reference_by_seed[int(float(row.get("training_seed") or 0))].append(number)
                    for row in candidate_rows:
                        if (number := finite(row.get(metric))) is not None:
                            candidate_by_seed[int(float(row.get("training_seed") or 0))].append(number)
                    common_seeds = sorted(set(reference_by_seed) & set(candidate_by_seed))
                    if not common_seeds:
                        continue
                    estimate = float(np.mean([
                        np.mean(candidate_by_seed[seed]) - np.mean(reference_by_seed[seed])
                        for seed in common_seeds
                    ]))
                    low, high = bootstrap_difference(
                        reference_by_seed, candidate_by_seed, rng, samples
                    )
                    ref_paired, alt_paired = paired_values(reference_rows, candidate_rows, metric)
                    p_value = float("nan")
                    test = "none"
                    if len(common_seeds) == 1 and len(ref_paired) >= 10:
                        differences = np.asarray(alt_paired) - np.asarray(ref_paired)
                        if np.any(differences != 0):
                            p_value = float(stats.wilcoxon(differences).pvalue)
                            test = "paired_wilcoxon_eligible_fingerprints"
                    pooled_ref = [number for seed in common_seeds for number in reference_by_seed[seed]]
                    pooled_alt = [number for seed in common_seeds for number in candidate_by_seed[seed]]
                    output.append({
                        "analysis": analysis,
                        "reference": "full",
                        "candidate": method,
                        "map_number": map_number,
                        "metric": metric,
                        "difference_candidate_minus_full": estimate,
                        "difference_ci95_low": low,
                        "difference_ci95_high": high,
                        "common_training_seeds": len(common_seeds),
                        "paired_eligible_episodes": len(ref_paired),
                        "test": test,
                        "p_value_raw": p_value,
                        "p_value_holm": float("nan"),
                        "cliffs_delta_candidate_vs_full": cliffs_delta(pooled_alt, pooled_ref),
                        "training_seed_inference": len(common_seeds) >= 3,
                    })

    valid = [index for index, row in enumerate(output) if math.isfinite(row["p_value_raw"])]
    ordered = sorted(valid, key=lambda index: output[index]["p_value_raw"])
    total = len(ordered)
    adjusted = 0.0
    for rank, index in enumerate(ordered):
        value = min(1.0, output[index]["p_value_raw"] * (total - rank))
        adjusted = max(adjusted, value)
        output[index]["p_value_holm"] = adjusted
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--bootstrap-samples", type=int, default=5000)
    args = parser.parse_args()
    records = load(args.input)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(20260716)
    summaries = condition_summaries(records, rng, max(1000, args.bootstrap_samples))
    pairwise = pairwise_summaries(records, rng, max(1000, args.bootstrap_samples))
    write(args.out_dir / "condition_bootstrap_ci.csv", summaries)
    write(args.out_dir / "pairwise_effects.csv", pairwise)
    readme = """# Statistical Interpretation\n\n- `main_seed1` fixes one learned checkpoint per method. Its confidence intervals quantify evaluation-scenario uncertainty only; they do not establish training-seed stability.\n- `core_ablation_seed12` uses a hierarchical seed-then-episode bootstrap when both training seeds complete. Two seeds are still insufficient for a training-stability claim; the output field remains false until at least three seeds exist.\n- Pairwise Wilcoxon tests are emitted only when at least ten records share an accepted initial-state fingerprint and are explicitly pairing-eligible. Otherwise the report retains bootstrap differences and effect sizes without inventing a paired p-value.\n- Holm correction is applied only to tests that meet that pairing rule. Cliff's delta is descriptive at the episode level and must not be described as training-seed evidence.\n- Moving-obstacle episodes whose trajectories are not reset reproducibly are expected to be pairing-ineligible.\n"""
    (args.out_dir / "STATISTICAL_INTERPRETATION.md").write_text(readme, encoding="utf-8")
    print(f"wrote {len(summaries)} condition rows and {len(pairwise)} pairwise rows")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
