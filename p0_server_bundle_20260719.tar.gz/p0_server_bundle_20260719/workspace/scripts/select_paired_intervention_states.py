#!/usr/bin/env python3
"""Select reproducible joint states from value-difference evaluation traces."""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import gzip
import hashlib
import heapq
import json
from pathlib import Path
from typing import Iterable


def iter_jsonl(path: Path) -> Iterable[dict]:
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}:{line_number}: invalid JSON: {exc}") from exc


def state_key(row: dict) -> tuple:
    return (
        str(row.get("method") or ""),
        row.get("training_seed"),
        int(row.get("eval_seed", row.get("episode_seed", -1))),
        int(row.get("map_number", -1)),
        int(row.get("episode_seed", -1)),
        int(row.get("episode", -1)),
        int(row.get("step", -1)),
    )


def stable_state_id(key: tuple) -> str:
    payload = json.dumps(key, separators=(",", ":"), ensure_ascii=True).encode("ascii")
    return "state_" + hashlib.sha256(payload).hexdigest()[:20]


def priority_for(state_id: str, seed: int) -> int:
    payload = f"{seed}:{state_id}".encode("ascii")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")


def build_candidate(key: tuple, records: list[dict], source: Path, expected_agents: int | None) -> dict | None:
    if key[-1] < 0:
        return None
    by_agent = {}
    for row in records:
        try:
            index = int(row["agent_index"])
            raw_credit = row.get("counterfactual_credit")
            if raw_credit is None:
                raw_credit = row["delta_v_zero_agent"]
            credit = float(raw_credit)
        except (KeyError, TypeError, ValueError):
            return None
        if index in by_agent:
            return None
        if row.get("terminated") or row.get("truncated") or str(row.get("event") or ""):
            return None
        by_agent[index] = {
            "agent": str(row.get("agent", f"agent_{index}")),
            "agent_index": index,
            "trace_credit_reference": credit,
        }
    count = expected_agents if expected_agents is not None else len(by_agent)
    if count < 2 or set(by_agent) != set(range(count)):
        return None
    method, training_seed, eval_seed, map_number, episode_seed, episode, step = key
    state_id = stable_state_id(key)
    return {
        "schema_version": "paired_intervention_plan_v1",
        "state_id": state_id,
        "method": method,
        "training_seed": training_seed,
        "eval_seed": eval_seed,
        "map_number": map_number,
        "episode_seed": episode_seed,
        "episode": episode,
        "step": step,
        "num_agents": count,
        "agents": [by_agent[index] for index in range(count)],
        "source_trace": str(source.resolve()),
    }


def bounded_add(heap: list, candidate: dict, priority: int, capacity: int) -> None:
    # heapq is a min heap; store negative priorities so the worst retained item is first.
    item = (-priority, candidate["state_id"], candidate)
    if len(heap) < capacity:
        heapq.heappush(heap, item)
    elif item > heap[0]:
        heapq.heapreplace(heap, item)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("traces", nargs="+", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--target-states", type=int, default=400)
    parser.add_argument("--seed", type=int, default=20260718)
    parser.add_argument("--expected-agents", type=int)
    parser.add_argument("--min-step", type=int, default=20)
    parser.add_argument("--min-step-gap", type=int, default=20)
    parser.add_argument("--allow-fewer", action="store_true")
    args = parser.parse_args()
    if args.target_states < 1 or args.min_step < 0 or args.min_step_gap < 0:
        parser.error("target and step constraints must be non-negative")

    capacity = max(args.target_states * 10, 1000)
    heaps = defaultdict(list)
    rejection_counts = Counter()
    seen_ids = set()
    for path in args.traces:
        current_key = None
        current_records = []

        def flush() -> None:
            nonlocal current_key, current_records
            if current_key is None:
                return
            if current_key[-1] < args.min_step:
                rejection_counts["before_min_step"] += 1
            else:
                candidate = build_candidate(
                    current_key, current_records, path, args.expected_agents)
                if candidate is None:
                    rejection_counts["invalid_or_non_joint_state"] += 1
                elif candidate["state_id"] in seen_ids:
                    rejection_counts["duplicate_state"] += 1
                else:
                    seen_ids.add(candidate["state_id"])
                    stratum = int(candidate["map_number"])
                    bounded_add(
                        heaps[stratum], candidate,
                        priority_for(candidate["state_id"], args.seed), capacity)
            current_key = None
            current_records = []

        for row in iter_jsonl(path):
            key = state_key(row)
            if current_key is not None and key != current_key:
                flush()
            current_key = key
            current_records.append(row)
        flush()

    eligible = {}
    for stratum, heap in heaps.items():
        candidates = [item[2] for item in heap]
        candidates.sort(key=lambda row: priority_for(row["state_id"], args.seed))
        accepted = []
        selected_steps = defaultdict(list)
        for candidate in candidates:
            episode_key = (
                candidate["method"], candidate["training_seed"],
                candidate["episode_seed"], candidate["episode"],
            )
            step = int(candidate["step"])
            if any(abs(step - other) < args.min_step_gap for other in selected_steps[episode_key]):
                rejection_counts["min_step_gap"] += 1
                continue
            accepted.append(candidate)
            selected_steps[episode_key].append(step)
        eligible[stratum] = accepted

    selected = []
    positions = {stratum: 0 for stratum in eligible}
    strata = sorted(eligible)
    while len(selected) < args.target_states:
        made_progress = False
        for stratum in strata:
            index = positions[stratum]
            if index < len(eligible[stratum]):
                selected.append(eligible[stratum][index])
                positions[stratum] += 1
                made_progress = True
                if len(selected) == args.target_states:
                    break
        if not made_progress:
            break

    if len(selected) < args.target_states and not args.allow_fewer:
        raise SystemExit(
            f"only {len(selected)} eligible states for target {args.target_states}; "
            "use --allow-fewer to accept this"
        )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as handle:
        for candidate in selected:
            handle.write(json.dumps(candidate, sort_keys=True) + "\n")
    manifest = {
        "schema_version": "paired_intervention_selection_v1",
        "target_states": args.target_states,
        "selected_states": len(selected),
        "seed": args.seed,
        "expected_agents": args.expected_agents,
        "min_step": args.min_step,
        "min_step_gap": args.min_step_gap,
        "selected_by_map": dict(Counter(str(row["map_number"]) for row in selected)),
        "rejections": dict(sorted(rejection_counts.items())),
        "source_traces": [str(path.resolve()) for path in args.traces],
    }
    manifest_path = args.output.with_suffix(args.output.suffix + ".manifest.json")
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"selected {len(selected)} states -> {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
