#!/usr/bin/env bash
set -euo pipefail

OUTPUT="${1:?resource CSV path is required}"
shift
mkdir -p "$(dirname "$OUTPUT")"
printf 'elapsed_s,process_rss_kb,process_cpu_pct,system_available_kb,process_gpu_memory_mb\n' >"$OUTPUT"
start_epoch="$(date +%s)"
setsid "$@" &
pid=$!

monitor() {
  while kill -0 "$pid" 2>/dev/null; do
    elapsed=$(( $(date +%s) - start_epoch ))
    read -r rss cpu < <(
      ps -eo sid=,rss=,%cpu= | awk -v sid="$pid" \
        '$1 == sid {rss += $2; cpu += $3} END {printf "%.0f %.2f\n", rss, cpu}'
    ) || true
    available="$(awk '/MemAvailable:/ {print $2}' /proc/meminfo)"
    gpu="$(
      session_pids="$(ps -eo sid=,pid= | awk -v sid="$pid" '$1 == sid {print $2}')"
      { nvidia-smi --query-compute-apps=pid,used_gpu_memory --format=csv,noheader,nounits \
          2>/dev/null || true; } | awk -F, -v pids="$session_pids" '
          BEGIN {
            count = split(pids, values, /[[:space:]]+/)
            for (i = 1; i <= count; i++) wanted[values[i]] = 1
          }
          {
            process_id = $1
            memory = $2
            gsub(/[[:space:]]/, "", process_id)
            gsub(/[^0-9.]/, "", memory)
            if (wanted[process_id]) total += memory
          }
          END {print total+0}
        '
    )"
    printf '%s,%s,%s,%s,%s\n' "$elapsed" "${rss:-0}" "${cpu:-0}" \
      "${available:-0}" "${gpu:-0}" >>"$OUTPUT"
    sleep 5
  done
}

monitor &
monitor_pid=$!
set +e
wait "$pid"
rc=$?
set -e
wait "$monitor_pid" 2>/dev/null || true
exit "$rc"
