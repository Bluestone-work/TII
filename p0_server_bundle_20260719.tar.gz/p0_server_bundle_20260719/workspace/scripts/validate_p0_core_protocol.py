#!/usr/bin/env python3
"""Validate the orthogonal P0 matrix, initialization, and graph capacity match."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import re

import gymnasium as gym
import torch

from gnn_marl_training.gat_rllib_model import GATRLlibModel
from gnn_marl_training.formal_scenario_bank import get_scenario_bank


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MATRIX = ROOT / "experiments/p0_core_training_matrix.tsv"
EXPECTED_VARIANTS = ("p0_graph_off", "p0_unified_graph", "p0_dual_graph")


def option(arguments: str, name: str, default: str | None = None) -> str | None:
    match = re.search(rf"(?:^|\s){re.escape(name)}\s+([^\s]+)", arguments)
    return match.group(1) if match else default


def read_matrix(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    if tuple(row["variant"] for row in rows) != EXPECTED_VARIANTS:
        raise ValueError("P0 matrix must contain graph-off, unified, and dual in order")
    for row in rows:
        args = row["extra_args"]
        if float(option(args, "--counterfactual_advantage_coef", "nan")) != 0.0:
            raise ValueError(f"P0 shaping must be zero for {row['variant']}")
        if option(args, "--graph_ablation") != "dual_graph":
            raise ValueError(f"P0 methods must expose both relation token sets: {row['variant']}")
        if option(args, "--graph_gate_mode") != "vector":
            raise ValueError(f"P0 methods must keep the same vector-gate shell: {row['variant']}")
    expected_architecture = {
        "p0_graph_off": "dual",
        "p0_unified_graph": "single",
        "p0_dual_graph": "dual",
    }
    for row in rows:
        if option(row["extra_args"], "--graph_architecture") != expected_architecture[row["variant"]]:
            raise ValueError(f"incorrect graph architecture for {row['variant']}")
    graph_off = rows[0]
    if float(option(graph_off["extra_args"], "--graph_residual_scale", "1")) != 0.0:
        raise ValueError("graph-off must zero only the graph residual path")
    return rows


def model_config(architecture: str, residual_scale: float) -> dict:
    return {
        "custom_model_config": {
            "num_agents": 4,
            "max_neighbors": 5,
            "neighbor_feature_dim": 7,
            "hidden_dim": 128,
            "gat_hidden_dim": 128,
            "unified_gat_hidden_dim": 256,
            "lstm_hidden_dim": 256,
            "n_gat_heads": 4,
            "actor_graph_mode": "neighbor",
            "graph_ablation": "dual_graph",
            "graph_architecture": architecture,
            "graph_gate_mode": "vector",
            "graph_residual_scale": residual_scale,
            "critic_mode": "mlp",
            "scan_history_len": 8,
            "target_obs_dim": 6,
            "base_safety_feature_dim": 2,
            "predictive_feature_dim": 0,
            "gap_feature_dim": 0,
            "neighbor_prediction_dim": 14,
            "neighbor_prediction_feature_dim": 7,
            "obstacle_motion_dim": 21,
            "obstacle_motion_feature_dim": 7,
            "local_map_dim": 4096,
            "agent_id_dim": 8,
        }
    }


def build_model(architecture: str, residual_scale: float, seed: int) -> GATRLlibModel:
    torch.manual_seed(seed)
    return GATRLlibModel(
        gym.spaces.Box(-1.0, 1.0, shape=(4397,)),
        gym.spaces.Box(-1.0, 1.0, shape=(2,)),
        4,
        model_config(architecture, residual_scale),
        f"p0_{architecture}_{residual_scale}_{seed}",
    )


def state_hash(model: GATRLlibModel) -> str:
    digest = hashlib.sha256()
    for name, tensor in model.state_dict().items():
        digest.update(name.encode("utf-8"))
        digest.update(tensor.detach().cpu().numpy().tobytes())
    return digest.hexdigest()


def validate_models() -> dict:
    manifest = {"capacity_tolerance": 0.01, "training_seeds": {}}
    capacity = None
    for seed in (1, 2, 3):
        models = {
            "p0_graph_off": build_model("dual", 0.0, seed),
            "p0_unified_graph": build_model("single", 1.0, seed),
            "p0_dual_graph": build_model("dual", 1.0, seed),
        }
        hashes = {name: state_hash(model) for name, model in models.items()}
        if len(set(hashes.values())) != 1:
            raise RuntimeError(f"P0 common initialization mismatch for seed={seed}")
        observations = torch.zeros((2, 4397), dtype=torch.float32)
        state = [torch.zeros((2, 256)), torch.zeros((2, 256))]
        for name, model in models.items():
            actions, _ = model(
                {"obs": observations, "obs_flat": observations},
                state,
                torch.tensor([1, 1]),
            )
            if actions.shape != (2, 4) or not torch.isfinite(actions).all():
                raise RuntimeError(f"non-finite P0 model output for {name}")
        counts = {
            name: model.active_graph_parameter_count()
            for name, model in models.items()
        }
        relative_gap = abs(counts["p0_unified_graph"] - counts["p0_dual_graph"]) / counts["p0_dual_graph"]
        if relative_gap > manifest["capacity_tolerance"]:
            raise RuntimeError(
                f"unified/dual active graph capacity mismatch: counts={counts} gap={relative_gap:.6f}"
            )
        capacity = {**counts, "unified_dual_relative_gap": relative_gap}
        manifest["training_seeds"][str(seed)] = {
            "initial_state_sha256": next(iter(hashes.values())),
        }
    manifest["active_graph_parameters"] = capacity
    return manifest


def validate_scenario_banks() -> dict:
    core = get_scenario_bank("p0_core_v1")
    supplement = get_scenario_bank("p0_p1_map3_v1")
    if tuple(case.map_number for case in core) != (4, 9, 5):
        raise RuntimeError("P0 core scenario bank must contain Maps 4, 9, and 5")
    if tuple(case.map_number for case in supplement) != (3,):
        raise RuntimeError("P1 policy/filter supplement must contain Map 3 only")
    for case in (*core, *supplement):
        if case.num_agents != 4 or case.max_episode_steps != 2000:
            raise RuntimeError(f"invalid P0/P1 scenario shape: {case.case_id}")
    return {
        "p0_core_v1": [case.case_id for case in core],
        "p0_p1_map3_v1": [case.case_id for case in supplement],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--matrix", type=Path, default=DEFAULT_MATRIX)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    read_matrix(args.matrix)
    manifest = validate_models()
    manifest["scenario_banks"] = validate_scenario_banks()
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(manifest, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
