#!/usr/bin/env python3
"""Generate a paper-ready experiment report from the completed five-day artifacts."""

from __future__ import annotations

import argparse
from collections import defaultdict
import csv
import json
import math
from pathlib import Path

import numpy as np


METRICS = ("agent_success_rate", "collision_rate", "timeout_rate", "spl")
METHODS = ("graph_off_cf0", "social_cf0", "obstacle_cf0", "dual_cf0", "dual_cf015")
MAPS = (3, 4, 5, 9)
TRAINING_SEEDS = (1, 2, 3)
CONDITIONS = ("filter_off", "filter_on")
DEVICES = ("cpu", "gpu")
FILTER_METRICS = (
    "agent_success_rate", "team_success", "collision_rate", "timeout_rate",
    "spl", "minimum_clearance",
)
INTERVENTION_METHODS = ("dual_cf0", "dual_cf015")
INTERVENTIONS = ("zero_agent", "mean_agent", "zero_social", "zero_obstacle")
EPISODES_PER_CASE = 25


def read_csv(path):
    if not path.is_file():
        return []
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def number(value, digits=3):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return "NA"
    return f"{value:.{digits}f}" if math.isfinite(value) else "NA"


def require(condition, message):
    if not condition:
        raise SystemExit(f"incomplete five-day artifacts: {message}")


def finite(value):
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def required_csv(path):
    rows = read_csv(path)
    require(rows, f"missing or empty {path}")
    return rows


def validate_complete_artifacts(root, validation, episodes, filter_rows, intervention_rows, complexity_rows):
    expected_records = len(METHODS) * len(TRAINING_SEEDS) * len(CONDITIONS) * len(MAPS) * EPISODES_PER_CASE
    require(validation.get("status") == "ok", "paired validation status is not ok")
    require(int(validation.get("records", -1)) == expected_records, f"paired records != {expected_records}")
    require(int(validation.get("expected_records", -1)) == expected_records, "paired validator expected-record count mismatch")
    require(set(validation.get("methods", ())) == set(METHODS), "paired validator method set mismatch")
    require(set(map(int, validation.get("training_seeds", ()))) == set(TRAINING_SEEDS), "paired validator seed set mismatch")
    require(set(validation.get("conditions", ())) == set(CONDITIONS), "paired validator condition set mismatch")
    require(len(validation.get("scenario_cases", ())) == len(MAPS), "paired validator scenario-case count mismatch")
    require(int(validation.get("paired_units", -1)) == len(MAPS) * EPISODES_PER_CASE, "paired-unit count mismatch")

    expected_episode_keys = {
        (method, map_number, seed)
        for method in METHODS for map_number in MAPS for seed in TRAINING_SEEDS
    }
    episode_groups = defaultdict(list)
    for row in episodes:
        key = (str(row.get("method")), int(row.get("map_number", -1)), int(row.get("training_seed", -1)))
        episode_groups[key].append(row)
    require(set(episode_groups) == expected_episode_keys, "filter-off method/map/seed coverage mismatch")
    for key, rows in episode_groups.items():
        require(len(rows) == EPISODES_PER_CASE, f"filter-off episode count mismatch for {key}")
        for metric in METRICS:
            require(all(finite(row.get(metric)) for row in rows), f"non-finite {metric} for {key}")

    expected_filter_keys = {(method, metric) for method in METHODS for metric in FILTER_METRICS}
    filter_by_key = {(row.get("method"), row.get("metric")): row for row in filter_rows}
    require(set(filter_by_key) == expected_filter_keys, "safety-filter summary coverage mismatch")
    for key, row in filter_by_key.items():
        require(int(row.get("n_training_seeds", 0)) == len(TRAINING_SEEDS), f"safety-filter seed count mismatch for {key}")
        require(finite(row.get("mean_paired_delta_on_minus_off")), f"non-finite safety-filter mean for {key}")
        require(finite(row.get("std_across_seeds")), f"non-finite safety-filter SD for {key}")
    filter_seed_rows = required_csv(root / "statistics/safety_filter/filter_paired_by_seed.csv")
    expected_filter_seed_keys = {
        (method, seed, metric)
        for method in METHODS for seed in TRAINING_SEEDS for metric in FILTER_METRICS
    }
    filter_seed_by_key = {
        (row.get("method"), int(row.get("training_seed", -1)), row.get("metric")): row
        for row in filter_seed_rows
    }
    require(set(filter_seed_by_key) == expected_filter_seed_keys, "safety-filter per-seed coverage mismatch")
    for key, row in filter_seed_by_key.items():
        require(int(row.get("n_paired_episodes", 0)) == len(MAPS) * EPISODES_PER_CASE, f"safety-filter pair count mismatch for {key}")

    expected_intervention_keys = {
        (method, intervention)
        for method in INTERVENTION_METHODS for intervention in INTERVENTIONS
    }
    intervention_by_key = {
        (row.get("method"), row.get("intervention")): row for row in intervention_rows
    }
    require(set(intervention_by_key) == expected_intervention_keys, "value-intervention summary coverage mismatch")
    for key, row in intervention_by_key.items():
        require(int(row.get("n_training_seeds", 0)) == len(TRAINING_SEEDS), f"value-intervention seed count mismatch for {key}")
        require(finite(row.get("mean_abs_delta_v_across_seeds")), f"non-finite intervention mean for {key}")
        require(finite(row.get("std_abs_delta_v_across_seeds")), f"non-finite intervention SD for {key}")
    intervention_seed_rows = required_csv(root / "statistics/value_interventions/value_intervention_by_seed.csv")
    expected_intervention_seed_keys = {
        (method, seed, intervention)
        for method in INTERVENTION_METHODS for seed in TRAINING_SEEDS for intervention in INTERVENTIONS
    }
    intervention_seed_by_key = {
        (row.get("method"), int(row.get("training_seed", -1)), row.get("intervention")): row
        for row in intervention_seed_rows
    }
    require(set(intervention_seed_by_key) == expected_intervention_seed_keys, "value-intervention per-seed coverage mismatch")
    require(all(int(row.get("n_states", 0)) > 0 for row in intervention_seed_rows), "value intervention has an empty state sample")

    expected_complexity_keys = {(method, device) for method in METHODS for device in DEVICES}
    complexity_by_key = {
        (row.get("method"), row.get("device_label")): row for row in complexity_rows
    }
    require(set(complexity_by_key) == expected_complexity_keys, "CPU/GPU complexity coverage mismatch")
    for (method, device), row in complexity_by_key.items():
        require(int(float(row.get("total_parameters", 0))) > 0, f"invalid parameter count for {(method, device)}")
        require(int(float(row.get("latency_repeats", 0))) >= 200, f"insufficient latency repeats for {(method, device)}")
        require(finite(row.get("latency_ms_mean")) and finite(row.get("latency_ms_p95")), f"non-finite latency for {(method, device)}")
        actual_device = str(row.get("actual_device", ""))
        require((device == "cpu" and actual_device == "cpu") or (device == "gpu" and actual_device.startswith("cuda")), f"actual device mismatch for {(method, device)}")

    curve_rows = required_csv(root / "learning_curves/learning_curves_per_seed.csv")
    curve_max_steps = defaultdict(int)
    for row in curve_rows:
        key = (row.get("method"), int(row.get("training_seed", -1)), int(row.get("map_number", -1)))
        curve_max_steps[key] = max(curve_max_steps[key], int(float(row.get("environment_steps", 0))))
    expected_curve_keys = {
        (method, seed, map_number)
        for method in METHODS for seed in TRAINING_SEEDS for map_number in (3, 9)
    }
    require(set(curve_max_steps) == expected_curve_keys, "learning-curve method/seed/map coverage mismatch")
    require(all(step >= 60000 for step in curve_max_steps.values()), "one or more learning curves end before 60k")
    curve_summary = required_csv(root / "learning_curves/learning_curves_mean_std.csv")
    final_curve_keys = {
        (row.get("method"), int(row.get("map_number", -1)), row.get("metric"))
        for row in curve_summary
        if int(float(row.get("environment_steps", 0))) >= 60000
        and int(row.get("n_training_seeds", 0)) == len(TRAINING_SEEDS)
        and finite(row.get("mean")) and finite(row.get("std"))
    }
    expected_final_curve_keys = {
        (method, map_number, metric)
        for method in METHODS for map_number in (3, 9)
        for metric in ("episode_reward", "agent_success", "collision_rate", "timeout_rate")
    }
    require(expected_final_curve_keys <= final_curve_keys, "cross-seed 60k learning-curve summary incomplete")
    for name in ("learning_curves_cross_seed.png", "learning_curves_cross_seed.pdf"):
        path = root / "learning_curves" / name
        require(path.is_file() and path.stat().st_size > 0, f"missing learning-curve figure {name}")

    for condition in CONDITIONS:
        stats_root = root / "statistics" / condition
        for name in ("seed_summary.csv", "friedman_tests.csv", "wilcoxon_holm_effect_sizes.csv", "paired_scenario_bootstrap.csv"):
            rows = required_csv(stats_root / name)
            if name == "seed_summary.csv":
                require(all(int(row.get("n_training_seeds", 0)) == len(TRAINING_SEEDS) for row in rows), f"statistics seed count mismatch in {condition}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-root", required=True, type=Path)
    args = parser.parse_args()
    root = args.out_root
    validation = json.loads((root / "paired_validation.json").read_text(encoding="utf-8"))
    episodes = required_csv(root / "filter_off_episodes.csv")
    grouped = defaultdict(list)
    for row in episodes:
        for metric in METRICS:
            try:
                grouped[(row["method"], int(row["map_number"]), int(row["training_seed"]), metric)].append(float(row[metric]))
            except (KeyError, TypeError, ValueError):
                pass
    table_rows = []
    method_maps = sorted({(method, map_number) for method, map_number, _seed, _metric in grouped})
    for method, map_number in method_maps:
        row = {"method": method, "map_number": map_number}
        for metric in METRICS:
            seed_values = [np.mean(values) for (candidate, candidate_map, _seed, candidate_metric), values in grouped.items() if candidate == method and candidate_map == map_number and candidate_metric == metric]
            row[f"{metric}_mean"] = float(np.mean(seed_values)) if seed_values else float("nan")
            row[f"{metric}_std"] = float(np.std(seed_values, ddof=1)) if len(seed_values) > 1 else float("nan")
        table_rows.append(row)
    with (root / "main_results_by_map.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(table_rows[0]))
        writer.writeheader()
        writer.writerows(table_rows)

    filter_rows = required_csv(root / "statistics/safety_filter/filter_paired_summary.csv")
    intervention_rows = required_csv(root / "statistics/value_interventions/value_intervention_summary.csv")
    complexity_rows = required_csv(root / "complexity/policy_complexity_profiles.csv")
    validate_complete_artifacts(
        root, validation, episodes, filter_rows, intervention_rows, complexity_rows
    )
    lines = [
        "# Five-day controlled experiment report", "",
        "## Protocol", "",
        "Five learned configurations were trained with seeds 1, 2, and 3. Map 3 and Map 9 runs started independently from the same seed-specific initialization; no legacy checkpoint or cross-map continuation was used. All training runs disabled the action-modifying safety filter. The four architecture variants disabled value-difference shaping, while `dual_cf015` differed from `dual_cf0` only by a shaping coefficient of 0.15.", "",
        f"Evaluation passed the strict paired validator for {validation['records']} episode records and {validation['paired_units']} scenario units. Every comparison reused the fixed start-goal routes and, on dynamic maps, the same seeded obstacle trajectory. The episode limit was 2,000 steps for every map.", "",
        "## Policy-only results", "",
        "Values are mean +/- sample standard deviation across independent training seeds; episodes are nested scenario samples, not independent training repeats.", "",
        "| Method | Map | Agent SR | Collision rate | Timeout rate | SPL |", "|---|---:|---:|---:|---:|---:|",
    ]
    for row in table_rows:
        lines.append("| {method} | {map_number} | {sr} +/- {sr_std} | {cr} +/- {cr_std} | {to} +/- {to_std} | {spl} +/- {spl_std} |".format(
            method=row["method"], map_number=row["map_number"],
            sr=number(row["agent_success_rate_mean"]), sr_std=number(row["agent_success_rate_std"]),
            cr=number(row["collision_rate_mean"]), cr_std=number(row["collision_rate_std"]),
            to=number(row["timeout_rate_mean"]), to_std=number(row["timeout_rate_std"]),
            spl=number(row["spl_mean"]), spl_std=number(row["spl_std"]),
        ))
    lines.extend(["", "## Safety filter", "", "Filter-on results describe the policy plus the external rule filter. They are not used as evidence that the learned policy itself is safer.", ""])
    if filter_rows:
        lines.extend(["| Method | Metric | Paired on-off delta | Across-seed SD |", "|---|---|---:|---:|"])
        for row in filter_rows:
            lines.append(f"| {row['method']} | {row['metric']} | {number(row['mean_paired_delta_on_minus_off'])} | {number(row['std_across_seeds'])} |")
    lines.extend(["", "## Controlled value intervention", "", "The critic was recomputed on the same observed state with frozen weights after zero-agent, mean-agent, social-token, and obstacle-token interventions. These deltas establish model sensitivity under the stated intervention; they do not turn the architecture ablation into a causal claim about the environment.", ""])
    if intervention_rows:
        lines.extend(["| Method | Intervention | Mean absolute delta V | Across-seed SD |", "|---|---|---:|---:|"])
        for row in intervention_rows:
            lines.append(f"| {row['method']} | {row['intervention']} | {number(row['mean_abs_delta_v_across_seeds'])} | {number(row['std_abs_delta_v_across_seeds'])} |")
    lines.extend(["", "## Cost", ""])
    if complexity_rows:
        lines.extend(["| Method | Device | Parameters | Mean latency (ms) | P95 (ms) |", "|---|---|---:|---:|---:|"])
        for row in complexity_rows:
            lines.append(f"| {row['method']} | {row['device_label']} | {int(float(row['total_parameters'])):,} | {number(row['latency_ms_mean'])} | {number(row['latency_ms_p95'])} |")
    lines.extend(["", "## Statistical interpretation", "", "The accompanying seed summary, Friedman tests, Holm-adjusted paired tests, effect sizes, and hierarchical paired bootstrap intervals are under `statistics/filter_off`. With three training seeds, inferential power remains limited; effect sizes, intervals, and individual seed results should be reported alongside p-values.", ""])
    (root / "EXPERIMENT_REPORT.md").write_text("\n".join(lines), encoding="utf-8")

    latex = ["\\begin{tabular}{llrrrr}", "\\toprule", "Method & Map & SR & CR & Timeout & SPL \\\\", "\\midrule"]
    for row in table_rows:
        method_label = row["method"].replace("_", "\\_")
        latex.append(f"{method_label} & {row['map_number']} & {number(row['agent_success_rate_mean'])} & {number(row['collision_rate_mean'])} & {number(row['timeout_rate_mean'])} & {number(row['spl_mean'])} \\\\")
    latex.extend(["\\bottomrule", "\\end{tabular}"])
    (root / "main_results_table.tex").write_text("\n".join(latex) + "\n", encoding="utf-8")
    print(f"wrote experiment report to {root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
