#!/usr/bin/env bash
set -euo pipefail

ROOT="/home/wj/work/multi-robot-exploration-rl"
SRC="$ROOT/src/gnn_marl_training_DGTA_nobuffer"
TEST_SCRIPT="$SRC/gnn_marl_training/test_gnn_mappo.py"
LOCAL_MAP_SCRIPT="$ROOT/scripts/plot_lidar_local_map.py"
AGG_SCRIPT="$ROOT/scripts/aggregate_cross_map_eval.py"
ATTN_PLOT_SCRIPT="$ROOT/scripts/plot_gat_attention.py"
RISK_PLOT_SCRIPT="$ROOT/scripts/plot_risk_field.py"
KILL_SCRIPT="$ROOT/kill_all_ros.sh"

CKPT="${CKPT:-$ROOT/ray_results/intersection_narrow_pathtrack_dyn4_long_fixed/GNN_MAPPO_Stage1_Cont_intersection_narrow_pathtrack_dyn4_long_fixed_EnvStage1/best}"
NUM_EPISODES="${NUM_EPISODES:-5}"
MAPS="${MAPS:-3 4 5 9}"
NUM_AGENTS="${NUM_AGENTS:-4}"
NUM_DYNAMIC_OBS="${NUM_DYNAMIC_OBS:-4}"
CAPTURE_ATTENTION="${CAPTURE_ATTENTION:-1}"   # 1=采集GNN注意力(F)+风险场(D)数据并绘图
ATTN_AGENT="${ATTN_AGENT:-agent_0}"           # 注意力时间-token图渲染哪个agent
ATTN_EPISODE="${ATTN_EPISODE:-0}"             # 注意力时间-token图渲染哪个episode
OBS_SPEED_SCALE="${OBS_SPEED_SCALE:-0.25}"
SAFETY_FILTER_ENABLE="${SAFETY_FILTER_ENABLE:-1}"
EVAL_SEED="${EVAL_SEED:-0}"
ROS_DOMAIN_ID_VIS="${ROS_DOMAIN_ID_VIS:-114}"
GAZEBO_PORT_VIS="${GAZEBO_PORT_VIS:-11814}"
OUT_DIR="${OUT_DIR:-$ROOT/paper_results/cross_map_visual_eval_$(date +%Y%m%d_%H%M%S)}"
RESULTS_JSONL="$OUT_DIR/episodes.jsonl"

CONDA_SH="${CONDA_SH:-/home/wj/anaconda3/etc/profile.d/conda.sh}"
ROS2_CONDA_ENV="${ROS2_CONDA_ENV:-ros2}"
ROS_SETUP="/opt/ros/humble/setup.bash"
WS_SETUP="$ROOT/install/setup.bash"
DISPLAY_FOR_GUI="${DISPLAY:-:1}"
XAUTHORITY_FOR_GUI="${XAUTHORITY:-/run/user/$(id -u)/gdm/Xauthority}"

export CONDA_SH ROS2_CONDA_ENV ROS_SETUP WS_SETUP SRC ROS_DOMAIN_ID_VIS GAZEBO_PORT_VIS DISPLAY_FOR_GUI XAUTHORITY_FOR_GUI

mkdir -p "$OUT_DIR/logs" "$OUT_DIR/local_map_obs"

setup_env_prefix='set +u; source "$CONDA_SH"; conda activate "$ROS2_CONDA_ENV"; source "$ROS_SETUP"; [[ -f "$WS_SETUP" ]] && source "$WS_SETUP"; set -u; export PYTHONPATH="$SRC:${PYTHONPATH:-}"; export ROS_DOMAIN_ID="$ROS_DOMAIN_ID_VIS"; export GAZEBO_MASTER_URI="http://127.0.0.1:$GAZEBO_PORT_VIS"; export GAZEBO_MODEL_DATABASE_URI=""; export TURTLEBOT3_MODEL=burger; export DISPLAY="$DISPLAY_FOR_GUI"; [[ -f "$XAUTHORITY_FOR_GUI" ]] && export XAUTHORITY="$XAUTHORITY_FOR_GUI"; export no_proxy=localhost,127.0.0.1; unset http_proxy https_proxy all_proxy HTTP_PROXY HTTPS_PROXY ALL_PROXY'

map_label() {
  case "$1" in
    3) echo "map3_corridor_swap" ;;
    4) echo "map4_intersection" ;;
    5) echo "map5_warehouse_aisles" ;;
    9) echo "map9_warehouse_dynamic" ;;
    *) echo "map$1" ;;
  esac
}

# 每张地图的 episode 步数上限：大图(3/4/5)给足到达时间，map9 维持原样。
map_max_steps() {
  case "$1" in
    3|4)   echo "${MAX_STEPS_BIG:-2000}" ;;
    5)     echo "${MAX_STEPS_MAP5:-3000}" ;;
    9)     echo "${MAX_STEPS_MAP9:-1000}" ;;
    *)     echo "${MAX_STEPS_DEFAULT:-1000}" ;;
  esac
}

cleanup_vis_port() {
  KILL_ALL_ROS_SCOPE=port_only \
  GAZEBO_PORT="$GAZEBO_PORT_VIS" \
  GAZEBO_MASTER_URI="http://127.0.0.1:$GAZEBO_PORT_VIS" \
  bash "$KILL_SCRIPT" >/dev/null 2>&1 || true
}

stop_ros_launch() {
  if [[ -n "${ROS_PID:-}" ]] && kill -0 "$ROS_PID" 2>/dev/null; then
    kill "$ROS_PID" 2>/dev/null || true
    sleep 3
    kill -9 "$ROS_PID" 2>/dev/null || true
  fi
  cleanup_vis_port
}

wait_for_gazebo() {
  local log="$1"
  local waited=0
  while (( waited < 180 )); do
    # 等待全部 NUM_AGENTS 台机器人 spawn 完成（spawn 顺序不保证，故按计数判断）。
    # 用 grep -E 而非 rg：rg 不一定在运行时 PATH 中。
    # grep -c 总会打印一个数字；不要再 || echo 0（会拼出 "0\n0" 触发算术错误）
    local spawned
    spawned="$(grep -cE "Successfully spawned entity \[tb3_[0-9]+\]" "$log" 2>/dev/null || true)"
    spawned="${spawned:-0}"
    if (( spawned >= NUM_AGENTS )); then
      sleep 8
      return 0
    fi
    if ! kill -0 "$ROS_PID" 2>/dev/null; then
      echo "[FATAL] ros2 launch exited early; log=$log" >&2
      tail -n 120 "$log" >&2 || true
      return 1
    fi
    sleep 2
    waited=$((waited + 2))
    if (( waited % 20 == 0 )); then
      echo "[wait] Gazebo/RViz ${waited}s/180s log=$log"
    fi
  done
  echo "[FATAL] Gazebo/RViz did not become ready in 180s; log=$log" >&2
  tail -n 160 "$log" >&2 || true
  return 1
}

run_map() {
  local map="$1"
  local label
  label="$(map_label "$map")"
  local ros_log="$OUT_DIR/logs/${label}_ros_visual.log"
  local eval_log="$OUT_DIR/logs/${label}_eval_visual.log"
  local obs_log="$OUT_DIR/logs/${label}_local_map.log"
  local rviz_name="rviz_${label}"

  echo
  echo "===== VISUAL EVAL $label ====="
  cleanup_vis_port

  bash -lc "$setup_env_prefix; ros2 launch start_rl_environment_tb3 main.launch.py map_number:=$map robot_number:=$NUM_AGENTS num_obstacles:=$NUM_DYNAMIC_OBS obs_speed_scale:=$OBS_SPEED_SCALE rviz_node_name:=$rviz_name" >"$ros_log" 2>&1 &
  ROS_PID=$!
  echo "[ros+gui] pid=$ROS_PID log=$ros_log"
  wait_for_gazebo "$ros_log"

  local max_steps attn_npz attn_dir
  max_steps="$(map_max_steps "$map")"
  attn_dir="$OUT_DIR/attention_risk"
  mkdir -p "$attn_dir"
  attn_npz="$attn_dir/${label}_attn_risk.npz"
  echo "[eval] running visual policy episodes for $label (max_episode_steps=$max_steps, collision cutoff disabled)"
  set +e
  (
    set -o pipefail
    bash -lc "$setup_env_prefix; python3 '$TEST_SCRIPT' --checkpoint_path '$CKPT' --num_episodes '$NUM_EPISODES' --seed '$EVAL_SEED' --map_number '$map' --num_dynamic_obstacles '$NUM_DYNAMIC_OBS' --obs_speed_scale '$OBS_SPEED_SCALE' --shield_enable '$SAFETY_FILTER_ENABLE' --auto_reset_agents 0 --min_active_agents_to_continue 0 --max_episode_steps '$max_steps' --max_failed_agents_before_cutoff 0 --diag_steps 0 --capture_attention '$CAPTURE_ATTENTION' --attention_out '$attn_npz' --results_jsonl '$RESULTS_JSONL' --method_label 'gnn_mappo_relative_motion_visual' --scenario_label '$label'" 2>&1 | tee "$eval_log"
  ) &
  EVAL_PID=$!

  echo "[obs] collecting per-robot local-map heatmaps during policy rollout for $label"
  # 只需短暂预热让 /scan 话题就绪即可开始采集，尽量贴合 episode 起始的运动阶段；
  # 采集窗口(samples/stride/timeout)保持在活动期内，避免采到 episode 结束后静止的机器人。
  sleep "${OBS_WARMUP_S:-10}"
  local -a OBS_PIDS=()
  for rid in $(seq 0 $((NUM_AGENTS - 1))); do
    robot="tb3_${rid}"
    robot_obs_log="$OUT_DIR/logs/${label}_${robot}_local_map.log"
    bash -lc "$setup_env_prefix; python3 '$LOCAL_MAP_SCRIPT' --robot '$robot' --samples '${OBS_SAMPLES:-180}' --stride '${OBS_STRIDE:-3}' --timeout-s '${OBS_TIMEOUT_S:-120}' --out-dir '$OUT_DIR/local_map_obs' --prefix '${label}_${robot}_rollout'" >"$robot_obs_log" 2>&1 &
    OBS_PIDS+=("$!")
  done

  local obs_rc=0
  for obs_pid in "${OBS_PIDS[@]}"; do
    if ! wait "$obs_pid"; then
      obs_rc=1
    fi
  done
  OBS_PIDS=()
  if (( obs_rc != 0 )); then
    echo "[WARN] one or more local-map rollout captures failed for $label; see $OUT_DIR/logs/${label}_tb3_*_local_map.log" >&2
  fi

  wait "$EVAL_PID"
  local rc=$?
  set -e

  stop_ros_launch
  if (( rc != 0 )); then
    echo "[FATAL] visual eval failed for $label rc=$rc log=$eval_log" >&2
    return "$rc"
  fi

  # F + D: 从逐步日志绘制 GNN 注意力热力图 + 空间风险场热力图
  if [[ "$CAPTURE_ATTENTION" == "1" && -f "$attn_npz" ]]; then
    echo "[viz] plotting GNN attention (F) + risk field (D) for $label"
    bash -lc "$setup_env_prefix; python3 '$ATTN_PLOT_SCRIPT' '$attn_npz' --out-dir '$attn_dir' --prefix '$label' --agent '$ATTN_AGENT' --episode '$ATTN_EPISODE'" \
      >"$OUT_DIR/logs/${label}_attn_plot.log" 2>&1 || echo "[WARN] attention plot failed for $label" >&2
    bash -lc "$setup_env_prefix; python3 '$RISK_PLOT_SCRIPT' '$attn_npz' --out-dir '$attn_dir' --prefix '$label'" \
      >"$OUT_DIR/logs/${label}_risk_plot.log" 2>&1 || echo "[WARN] risk-field plot failed for $label" >&2
  fi
}

main() {
  if [[ ! -f "$CKPT/algorithm_state.pkl" ]]; then
    echo "[FATAL] invalid checkpoint: $CKPT" >&2
    exit 2
  fi
  echo "[INFO] visual output=$OUT_DIR"
  echo "[INFO] checkpoint=$CKPT"
  echo "[INFO] maps=$MAPS visual_episodes_per_map=$NUM_EPISODES dyn_obs=$NUM_DYNAMIC_OBS speed_scale=$OBS_SPEED_SCALE safety_filter=$SAFETY_FILTER_ENABLE"
  echo "[INFO] ROS_DOMAIN_ID=$ROS_DOMAIN_ID_VIS GAZEBO_PORT=$GAZEBO_PORT_VIS"

  : > "$RESULTS_JSONL"
  for map in $MAPS; do
    run_map "$map"
  done

  bash -lc "$setup_env_prefix; python3 '$AGG_SCRIPT' '$RESULTS_JSONL' --outdir '$OUT_DIR'" 2>&1 | tee "$OUT_DIR/aggregate.log"
  echo "[INFO] complete visual output=$OUT_DIR"
}

trap stop_ros_launch EXIT
main "$@"
