#!/usr/bin/env python3
"""Aggregate training monitors into seed-level and cross-seed learning curves."""

from __future__ import annotations

import argparse
from collections import defaultdict
import csv
from pathlib import Path
import statistics

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


METRICS = ("episode_reward", "agent_success", "collision_rate", "timeout_rate")


def finite(row, key):
    try:
        return float(row[key])
    except (KeyError, TypeError, ValueError):
        return None


def read_curves(root: Path):
    curves = defaultdict(dict)
    for monitor in sorted(root.glob("*/seed*/map*/attempt*/*/*/training_monitor.csv")):
        relative = monitor.relative_to(root).parts
        variant, seed_text, map_text, attempt_text = relative[:4]
        seed, map_number = int(seed_text.removeprefix("seed")), int(map_text.removeprefix("map"))
        attempt = int(attempt_text.removeprefix("attempt"))
        base_path = root / variant / seed_text / map_text / attempt_text / "resume_base_steps.txt"
        try:
            base = int(base_path.read_text(encoding="utf-8").strip())
        except (FileNotFoundError, ValueError):
            base = 0
        with monitor.open(newline="", encoding="utf-8") as handle:
            for row in csv.DictReader(handle):
                local_step = finite(row, "environment_steps")
                if local_step is None:
                    continue
                step = int(base + local_step)
                values = {metric: finite(row, metric) for metric in METRICS}
                if all(value is None for value in values.values()):
                    continue
                key = (variant, seed, map_number)
                previous = curves[key].get(step)
                if previous is None or attempt >= previous[0]:
                    curves[key][step] = (attempt, values)
    return curves


def write_csv(path, rows):
    fields = list(rows[0]) if rows else []
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        if fields:
            writer.writeheader()
            writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-root", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args()
    curves = read_curves(args.train_root.resolve())
    if not curves:
        raise SystemExit("no training_monitor.csv files found")
    per_seed = []
    grouped = defaultdict(list)
    for (variant, seed, map_number), steps in sorted(curves.items()):
        for step, (_attempt, values) in sorted(steps.items()):
            row = {"method": variant, "training_seed": seed, "map_number": map_number, "environment_steps": step, **values}
            per_seed.append(row)
            for metric, value in values.items():
                if value is not None:
                    grouped[(variant, map_number, step, metric)].append(value)
    summary = []
    for (variant, map_number, step, metric), values in sorted(grouped.items()):
        summary.append({
            "method": variant, "map_number": map_number, "environment_steps": step,
            "metric": metric, "n_training_seeds": len(values),
            "mean": statistics.fmean(values),
            "std": statistics.stdev(values) if len(values) > 1 else float("nan"),
        })
    args.out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.out_dir / "learning_curves_per_seed.csv", per_seed)
    write_csv(args.out_dir / "learning_curves_mean_std.csv", summary)

    methods = sorted({row["method"] for row in summary})
    maps = sorted({row["map_number"] for row in summary})
    fig, axes = plt.subplots(len(maps), 3, figsize=(13, 4 * len(maps)), squeeze=False)
    for map_index, map_number in enumerate(maps):
        for metric_index, metric in enumerate(METRICS[:3]):
            axis = axes[map_index][metric_index]
            for method in methods:
                rows = [row for row in summary if row["method"] == method and row["map_number"] == map_number and row["metric"] == metric and row["n_training_seeds"] >= 2]
                if not rows:
                    continue
                rows.sort(key=lambda row: row["environment_steps"])
                x = [row["environment_steps"] for row in rows]
                y = [row["mean"] for row in rows]
                std = [row["std"] for row in rows]
                axis.plot(x, y, label=method, linewidth=1.5)
                axis.fill_between(x, [a - b for a, b in zip(y, std)], [a + b for a, b in zip(y, std)], alpha=0.12)
            axis.set_title(f"Map {map_number}: {metric}")
            axis.set_xlabel("Environment steps")
            axis.grid(alpha=0.25)
    axes[0][0].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(args.out_dir / "learning_curves_cross_seed.png", dpi=180)
    fig.savefig(args.out_dir / "learning_curves_cross_seed.pdf")
    plt.close(fig)
    print(f"wrote learning curves to {args.out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
