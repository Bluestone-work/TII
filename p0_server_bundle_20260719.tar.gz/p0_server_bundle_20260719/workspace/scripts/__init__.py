"""Experiment orchestration and paper-analysis utilities."""
