#!/usr/bin/env python3
"""Summarize the paired Map 3 safety-filter supplement by training seed."""

from __future__ import annotations

import argparse
from collections import defaultdict
import csv
import json
import math
from pathlib import Path
import statistics


METHODS = ("p0_graph_off", "p0_unified_graph", "p0_dual_graph")
SEEDS = (1, 2, 3)
CONDITIONS = ("filter_off", "filter_on")
MEAN_METRICS = {
    "SR": "agent_success_rate",
    "TSR": "team_success",
    "CR": "collision_rate",
    "Timeout": "timeout_rate",
    "PathLength": "path_length",
    "SPL": "spl",
}
RATIO_METRICS = {
    "SuccessOnlyTTG": (
        "successful_agent_completion_time_sum",
        "successful_agent_completion_time_count",
    ),
    "FilterInterventionRate": (
        "filter_intervention_count",
        "filter_action_samples",
    ),
}
REPORT_METRICS = (
    "SR", "TSR", "CR", "Timeout", "SuccessOnlyTTG", "PathLength", "SPL",
    "FilterInterventionRate",
)


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def weighted_ratio(rows: list[dict], numerator: str, denominator: str) -> tuple[float, float, int]:
    numerator_sum = sum(float(row[numerator]) for row in rows)
    denominator_sum = sum(int(row[denominator]) for row in rows)
    value = numerator_sum / denominator_sum if denominator_sum else float("nan")
    return value, numerator_sum, denominator_sum


def display(value: float) -> str:
    return f"{value:.3f}" if math.isfinite(value) else "NA"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--episodes", type=int, default=50)
    args = parser.parse_args()
    records = [
        json.loads(line)
        for line in args.input.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    grouped = defaultdict(list)
    for record in records:
        if int(record["map_number"]) != 3:
            raise SystemExit(f"P1 supplement accepts Map 3 only: {record['map_number']}")
        condition = str(record["experiment_condition"])
        expected_filter = condition == "filter_on"
        if condition not in CONDITIONS or bool(record["shield_enable"]) != expected_filter:
            raise SystemExit(f"P1 filter attribution mismatch: {condition}")
        grouped[(
            str(record["method"]), condition, int(record["training_seed"]),
        )].append(record)

    expected = {
        (method, condition, seed)
        for method in METHODS for condition in CONDITIONS for seed in SEEDS
    }
    if set(grouped) != expected:
        raise SystemExit(
            f"P1 coverage mismatch missing={sorted(expected - set(grouped))} "
            f"extra={sorted(set(grouped) - expected)}"
        )

    per_seed = []
    for key in sorted(grouped):
        method, condition, seed = key
        rows = grouped[key]
        if len(rows) != args.episodes:
            raise SystemExit(f"P1 episode count mismatch key={key} count={len(rows)}")
        output = {
            "method": method,
            "condition": condition,
            "map_number": 3,
            "training_seed": seed,
            "episodes": len(rows),
        }
        for label, field in MEAN_METRICS.items():
            output[label] = statistics.fmean(float(row[field]) for row in rows)
        for label, (numerator, denominator) in RATIO_METRICS.items():
            value, numerator_sum, denominator_sum = weighted_ratio(rows, numerator, denominator)
            output[label] = value
            output[f"{label}_numerator"] = numerator_sum
            output[f"{label}_denominator"] = denominator_sum
        per_seed.append(output)

    across_seed = []
    for method in METHODS:
        for condition in CONDITIONS:
            rows = [
                row for row in per_seed
                if row["method"] == method and row["condition"] == condition
            ]
            output = {
                "method": method,
                "condition": condition,
                "map_number": 3,
                "n_training_seeds": len(rows),
            }
            for label in REPORT_METRICS:
                values = [float(row[label]) for row in rows]
                output[f"{label}_mean"] = statistics.fmean(values)
                output[f"{label}_std"] = statistics.stdev(values)
            across_seed.append(output)

    paired_effects = []
    for method in METHODS:
        for label in REPORT_METRICS:
            differences = []
            for seed in SEEDS:
                by_condition = {
                    row["condition"]: float(row[label])
                    for row in per_seed
                    if row["method"] == method and int(row["training_seed"]) == seed
                }
                differences.append(by_condition["filter_on"] - by_condition["filter_off"])
            paired_effects.append({
                "method": method,
                "metric": label,
                "difference_definition": "filter_on_minus_filter_off",
                "n_training_seeds": len(differences),
                "mean_paired_difference": statistics.fmean(differences),
                "std_paired_difference": statistics.stdev(differences),
            })

    args.out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.out_dir / "per_training_seed.csv", per_seed)
    write_csv(args.out_dir / "mean_std_across_training_seeds.csv", across_seed)
    write_csv(args.out_dir / "paired_filter_effect_across_seeds.csv", paired_effects)

    lines = [
        "# P1 Map 3 Policy and Safety-Filter Supplement",
        "",
        "Both conditions use the same fixed episodes. Values are mean +/- sample standard "
        "deviation across three training seeds.",
        "",
        "`Success-only TTG` averages simulated arrival time over successful agents. "
        "Filter rate is modified agent-actions divided by all executed agent-actions.",
        "",
        "| Method | Condition | SR | TSR | CR | Timeout | TTG success (s) | Path (m) | SPL | Filter rate |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in across_seed:
        cells = [
            f"{display(row[f'{label}_mean'])} +/- {display(row[f'{label}_std'])}"
            for label in REPORT_METRICS
        ]
        lines.append(
            f"| {row['method']} | {row['condition']} | " + " | ".join(cells) + " |"
        )
    lines.extend([
        "",
        "The filter-on minus filter-off seed-level differences are stored in "
        "`paired_filter_effect_across_seeds.csv`. This supplement is descriptive and is "
        "not substituted for the P0 Map 4/9/5 architecture comparison.",
    ])
    (args.out_dir / "REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote P1 Map 3 results to {args.out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
