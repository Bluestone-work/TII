#!/usr/bin/env python3
"""Summarize per-timestep counterfactual credit around events/interventions."""

import argparse
import csv
import gzip
import json
import math
import os
import random
from collections import defaultdict, deque

import numpy as np


class OnlineStats:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.m2 = 0.0
        self.abs_sum = 0.0

    def add(self, value):
        if value is None:
            return
        value = float(value)
        if not math.isfinite(value):
            return
        self.n += 1
        delta = value - self.mean
        self.mean += delta / self.n
        self.m2 += delta * (value - self.mean)
        self.abs_sum += abs(value)

    def row(self):
        std = math.sqrt(self.m2 / self.n) if self.n else float("nan")
        return self.n, self.mean if self.n else float("nan"), std, self.abs_sum / self.n if self.n else float("nan")


class Reservoir:
    def __init__(self, capacity=50000, seed=20260715):
        self.capacity = int(capacity)
        self.values = []
        self.seen = 0
        self.rng = random.Random(seed)

    def add(self, value):
        value = float(value)
        if not math.isfinite(value):
            return
        self.seen += 1
        if len(self.values) < self.capacity:
            self.values.append(value)
            return
        index = self.rng.randrange(self.seen)
        if index < self.capacity:
            self.values[index] = value


def open_trace(path):
    if path.endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8")
    return open(path, "r", encoding="utf-8")


def truthy(value):
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes"}
    return bool(value)


def trace_episode_key(record):
    return (
        int(record["map_number"]),
        int(record["episode"]),
        int(record["training_seed"]),
        int(record["eval_seed"]),
    )


def episode_csv_steps(path):
    steps_by_key = {}
    with open(path, "r", newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            key = (
                int(row["map_number"]),
                int(row["episode_index"]),
                int(row["training_seed"]),
                int(row["seed"]),
            )
            if key in steps_by_key:
                raise ValueError(f"duplicate episode key in {path}: {key}")
            steps_by_key[key] = int(row["steps"])
    return steps_by_key


def episode_jsonl_steps(path):
    steps_by_key = {}
    with open(path, "r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            record = parse_trace_record(line, path, line_number)
            key = (
                int(record["map_number"]),
                int(record["episode_index"]),
                int(record["training_seed"]),
                int(record["seed"]),
            )
            if key in steps_by_key:
                raise ValueError(f"duplicate episode key in {path}: {key}")
            steps_by_key[key] = int(record["steps"])
    return steps_by_key


def parse_trace_record(line, path, line_number):
    try:
        return json.loads(line)
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON at {path}:{line_number}: {exc}") from exc


def scan_trace_blocks(path):
    block_indices_by_key = defaultdict(list)
    block_count_by_key = defaultdict(int)
    max_step_by_block = {}
    previous_key = None
    block_index = -1
    records = 0
    with open_trace(path) as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            record = parse_trace_record(line, path, line_number)
            key = trace_episode_key(record)
            if key != previous_key:
                block_index += 1
                block_count_by_key[key] += 1
                block_indices_by_key[key].append(block_index)
                previous_key = key
            max_step_by_block[block_index] = max(
                max_step_by_block.get(block_index, 0), int(record["step"])
            )
            records += 1
    return block_indices_by_key, block_count_by_key, max_step_by_block, records


def iter_analysis_records(path):
    """Yield raw records, or final episode blocks when a sibling episode CSV exists."""
    episodes_csv = os.path.join(os.path.dirname(os.path.abspath(path)), "episodes.csv")
    if not os.path.isfile(episodes_csv):
        with open_trace(path) as handle:
            for line_number, line in enumerate(handle, 1):
                if line.strip():
                    yield parse_trace_record(line, path, line_number)
        return

    episodes_jsonl = os.path.join(os.path.dirname(os.path.abspath(path)), "episodes.jsonl")
    if not os.path.isfile(episodes_jsonl):
        raise ValueError(f"missing sibling episode JSONL for trace validation: {episodes_jsonl}")
    block_indices, block_counts, max_steps, input_records = scan_trace_blocks(path)
    expected_steps = episode_csv_steps(episodes_csv)
    json_steps = episode_jsonl_steps(episodes_jsonl)
    if expected_steps != json_steps:
        csv_keys, json_keys = set(expected_steps), set(json_steps)
        step_mismatches = sorted(
            key for key in csv_keys & json_keys
            if expected_steps[key] != json_steps[key]
        )
        raise ValueError(
            f"CSV/JSONL episode mismatch for {path}: "
            f"missing_json={sorted(csv_keys - json_keys)[:10]} "
            f"extra_json={sorted(json_keys - csv_keys)[:10]} "
            f"step_mismatches={step_mismatches[:10]}"
        )
    expected, observed = set(expected_steps), set(block_indices)
    if expected != observed:
        missing = sorted(expected - observed)
        extra = sorted(observed - expected)
        raise ValueError(
            f"trace/episode key mismatch for {path}: missing={missing[:10]} extra={extra[:10]}"
        )
    last_blocks = {}
    for key, expected_step in expected_steps.items():
        completed = [
            block_index for block_index in block_indices[key]
            if max_steps.get(block_index) == expected_step
        ]
        if not completed:
            observed_steps = [max_steps.get(index) for index in block_indices[key]]
            raise ValueError(
                f"no completed trace block for {path} key={key}: "
                f"expected_step={expected_step} observed_max_steps={observed_steps}"
            )
        last_blocks[key] = completed[-1]
    previous_key = None
    block_index = -1
    kept = 0
    with open_trace(path) as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            record = parse_trace_record(line, path, line_number)
            key = trace_episode_key(record)
            if key != previous_key:
                block_index += 1
                previous_key = key
            if block_index == last_blocks[key]:
                kept += 1
                yield record
    duplicate_blocks = sum(count - 1 for count in block_counts.values())
    print(
        f"[trace-validation] path={path} episodes={len(observed)} "
        f"csv_jsonl_match=1 duplicate_blocks={duplicate_blocks} "
        f"kept={kept} dropped={input_records - kept}"
    )


def record_categories(record):
    yield "all"
    event = str(record.get("event") or "")
    if event:
        yield f"event_{event}"
    if truthy(record.get("shield_active")):
        yield "intervention_shield"
    else:
        yield "no_shield"
    if truthy(record.get("motion_filter_active")):
        yield "intervention_motion_filter"
    if truthy(record.get("swept_filter_active")):
        yield "intervention_swept_filter"
    if truthy(record.get("yield_active")):
        yield "intervention_yield"
    risk = record.get("dynamic_obs_ttc_risk")
    if risk is not None and float(risk) >= 0.5:
        yield "high_dynamic_ttc_risk"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("traces", nargs="+", help="CF trace JSONL or JSONL.GZ files")
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--pre-event-window", type=int, default=20)
    args = parser.parse_args()
    window = max(1, int(args.pre_event_window))

    condition_stats = defaultdict(OnlineStats)
    alignment_stats = defaultdict(OnlineStats)
    attribution_stats = defaultdict(OnlineStats)
    sign_flip_counts = defaultdict(lambda: [0, 0])
    previous_credits = {}
    gate_risk_stats = defaultdict(lambda: (OnlineStats(), OnlineStats()))
    distribution_samples = defaultdict(Reservoir)
    histories = defaultdict(lambda: deque(maxlen=window + 1))

    for path in args.traces:
        source = os.path.basename(os.path.dirname(os.path.abspath(path)))
        for record in iter_analysis_records(path):
            credit = record.get("counterfactual_credit")
            if credit is None:
                continue
            method = str(record.get("method") or source)
            map_number = int(record.get("map_number", -1))
            agent = str(record.get("agent", ""))
            base_key = (method, map_number)
            attribution_stats[base_key + (agent,)].add(credit)
            distribution_samples[base_key].add(credit)
            for category in record_categories(record):
                condition_stats[base_key + (category,)].add(credit)

            history_key = (
                path,
                map_number,
                int(record.get("episode", -1)),
                str(record.get("agent", "")),
            )
            history = histories[history_key]
            history.append(float(credit))
            previous = previous_credits.get(history_key)
            if previous is not None and previous != 0.0 and float(credit) != 0.0:
                sign_flip_counts[base_key][1] += 1
                if (previous > 0.0) != (float(credit) > 0.0):
                    sign_flip_counts[base_key][0] += 1
            previous_credits[history_key] = float(credit)

            gate = record.get("gate_mean")
            risk = record.get("dynamic_obs_ttc_risk")
            if gate is not None and risk is not None:
                gate = float(gate)
                risk = float(risk)
                if math.isfinite(gate) and math.isfinite(risk):
                    risk_bin = min(9, max(0, int(np.clip(risk, 0.0, 0.999999) * 10.0)))
                    gate_stats, credit_stats = gate_risk_stats[base_key + (risk_bin,)]
                    gate_stats.add(gate)
                    credit_stats.add(credit)
            event = str(record.get("event") or "")
            if event in {"goal", "collision"}:
                values = list(history)
                for index, value in enumerate(values):
                    offset = index - len(values) + 1
                    alignment_stats[base_key + (event, offset)].add(value)
                    condition_stats[base_key + (f"pre_{event}_{window}",)].add(value)

    os.makedirs(args.out_dir, exist_ok=True)
    summary_path = os.path.join(args.out_dir, "cf_credit_condition_summary.csv")
    with open(summary_path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["method", "map_number", "condition", "n", "credit_mean", "credit_std", "credit_abs_mean"])
        for (method, map_number, condition), stats in sorted(condition_stats.items()):
            writer.writerow([method, map_number, condition, *stats.row()])

    alignment_path = os.path.join(args.out_dir, "cf_credit_event_alignment.csv")
    with open(alignment_path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["method", "map_number", "event", "offset_steps", "n", "credit_mean", "credit_std", "credit_abs_mean"])
        for (method, map_number, event, offset), stats in sorted(alignment_stats.items()):
            writer.writerow([method, map_number, event, offset, *stats.row()])

    attribution_path = os.path.join(args.out_dir, "cf_credit_attribution_ranking.csv")
    attribution_rows = []
    for (method, map_number, agent), stats in attribution_stats.items():
        n, mean, std, abs_mean = stats.row()
        attribution_rows.append((method, map_number, agent, n, mean, std, abs_mean))
    attribution_rows.sort(key=lambda row: (row[0], row[1], -row[6], row[2]))
    with open(attribution_path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["method", "map_number", "agent", "n", "credit_mean", "credit_std", "credit_abs_mean"])
        writer.writerows(attribution_rows)

    sign_path = os.path.join(args.out_dir, "cf_credit_sign_flip_rate.csv")
    with open(sign_path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["method", "map_number", "sign_flips", "valid_transitions", "credit_sign_flip_rate"])
        for (method, map_number), (flips, transitions) in sorted(sign_flip_counts.items()):
            writer.writerow([method, map_number, flips, transitions, flips / transitions if transitions else float("nan")])

    gate_path = os.path.join(args.out_dir, "gate_activation_vs_risk.csv")
    with open(gate_path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "method", "map_number", "risk_bin", "risk_low", "risk_high", "n",
            "gate_mean", "gate_std", "credit_mean", "credit_std",
        ])
        for (method, map_number, risk_bin), (gate_stats, credit_stats) in sorted(gate_risk_stats.items()):
            gate_n, gate_mean, gate_std, _ = gate_stats.row()
            _credit_n, credit_mean, credit_std, _ = credit_stats.row()
            writer.writerow([
                method, map_number, risk_bin, risk_bin / 10.0, (risk_bin + 1) / 10.0,
                gate_n, gate_mean, gate_std, credit_mean, credit_std,
            ])

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        if distribution_samples:
            fig, ax = plt.subplots(figsize=(7.2, 4.2))
            for (method, map_number), reservoir in sorted(distribution_samples.items()):
                if reservoir.values:
                    ax.hist(
                        reservoir.values,
                        bins=60,
                        density=True,
                        histtype="step",
                        linewidth=1.4,
                        label=f"{method} M{map_number}",
                    )
            ax.set_xlabel("Counterfactual credit")
            ax.set_ylabel("Density")
            ax.grid(alpha=0.2)
            ax.legend(fontsize=7, ncol=2)
            fig.tight_layout()
            fig.savefig(os.path.join(args.out_dir, "cf_credit_distribution.png"), dpi=200)
            fig.savefig(os.path.join(args.out_dir, "cf_credit_distribution.pdf"))
            plt.close(fig)

        if gate_risk_stats:
            fig, ax = plt.subplots(figsize=(7.2, 4.2))
            series = defaultdict(list)
            for (method, map_number, risk_bin), (gate_stats, _credit_stats) in gate_risk_stats.items():
                _n, mean, std, _abs_mean = gate_stats.row()
                series[(method, map_number)].append(((risk_bin + 0.5) / 10.0, mean, std))
            for (method, map_number), values in sorted(series.items()):
                values.sort()
                x = np.asarray([row[0] for row in values])
                y = np.asarray([row[1] for row in values])
                std = np.asarray([row[2] for row in values])
                ax.plot(x, y, marker="o", label=f"{method} M{map_number}")
                ax.fill_between(x, y - std, y + std, alpha=0.12)
            ax.set_xlabel("Dynamic TTC risk")
            ax.set_ylabel("Mean graph gate")
            ax.set_xlim(0.0, 1.0)
            ax.grid(alpha=0.2)
            ax.legend(fontsize=7, ncol=2)
            fig.tight_layout()
            fig.savefig(os.path.join(args.out_dir, "gate_activation_vs_risk.png"), dpi=200)
            fig.savefig(os.path.join(args.out_dir, "gate_activation_vs_risk.pdf"))
            plt.close(fig)
    except Exception as exc:
        print(f"warning: diagnostic plotting failed: {exc}")

    print(f"wrote {summary_path}")
    print(f"wrote {alignment_path}")
    print(f"wrote {attribution_path}")
    print(f"wrote {sign_path}")
    print(f"wrote {gate_path}")


if __name__ == "__main__":
    main()
