#!/usr/bin/env python3
"""Check whether robot_policy_node can consume a formal RLlib checkpoint."""

from __future__ import annotations

import argparse
import ast
import json
import pickle
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
FORMAL_SOURCE = ROOT / "src" / "gnn_marl_training_DGTA_nobuffer"
DEFAULT_NODE = FORMAL_SOURCE / "gnn_marl_training" / "robot_policy_node.py"


def _literal_constants(tree: ast.AST) -> dict[str, Any]:
    values: dict[str, Any] = {}
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        value = node.value
        for target in targets:
            if not isinstance(target, ast.Name):
                continue
            try:
                values[target.id] = ast.literal_eval(value)
            except (ValueError, TypeError):
                pass
    return values


def _restores_checkpoint_model_config(tree: ast.AST) -> bool:
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Name) or node.func.id != "ModelClass":
            continue
        for keyword in node.keywords:
            if keyword.arg != "model_config":
                continue
            return not isinstance(keyword.value, ast.Dict) or bool(keyword.value.keys)
    return False


def load_checkpoint_config(checkpoint: Path) -> dict[str, Any]:
    sys.path.insert(0, str(FORMAL_SOURCE))
    with checkpoint.open("rb") as handle:
        state = pickle.load(handle)
    config = state.get("config")
    if hasattr(config, "to_dict"):
        config = config.to_dict()
    if not isinstance(config, dict):
        raise ValueError("checkpoint does not contain a dictionary config")
    return config


def audit(config: dict[str, Any], deployment_source: str) -> dict[str, Any]:
    tree = ast.parse(deployment_source)
    constants = _literal_constants(tree)
    model = config.get("model", {})
    custom = model.get("custom_model_config", {}) if isinstance(model, dict) else {}
    if not isinstance(custom, dict):
        custom = {}

    required = {
        "num_agents",
        "max_neighbors",
        "neighbor_feature_dim",
        "scan_history_len",
        "target_obs_dim",
        "base_safety_feature_dim",
        "neighbor_prediction_dim",
        "obstacle_motion_dim",
        "local_map_dim",
        "agent_id_dim",
    }
    missing = sorted(required - set(custom))
    issues: list[dict[str, Any]] = []
    if missing:
        issues.append({"code": "checkpoint_contract_missing", "fields": missing})

    if not _restores_checkpoint_model_config(tree):
        issues.append({
            "code": "checkpoint_model_config_not_restored",
            "detail": "deployment wrapper constructs ModelClass with an empty model_config",
        })

    comparisons = (
        ("SCAN_HISTORY_LEN", "scan_history_len"),
        ("SAFETY_FEAT_DIM", "base_safety_feature_dim"),
        ("NEIGHBOR_FEAT_DIM", "neighbor_feature_dim"),
    )
    for deployment_name, checkpoint_name in comparisons:
        deployment_value = constants.get(deployment_name)
        checkpoint_value = custom.get(checkpoint_name)
        if deployment_value is not None and checkpoint_value is not None:
            if int(deployment_value) != int(checkpoint_value):
                issues.append({
                    "code": "feature_dimension_mismatch",
                    "feature": checkpoint_name,
                    "checkpoint": int(checkpoint_value),
                    "deployment": int(deployment_value),
                })

    source_lower = deployment_source.lower()
    source_features = (
        ("local_map_dim", "local_map"),
        ("agent_id_dim", "agent_id"),
        ("neighbor_prediction_dim", "neighbor_prediction"),
        ("obstacle_motion_dim", "obstacle_motion"),
    )
    for checkpoint_name, source_marker in source_features:
        checkpoint_value = int(custom.get(checkpoint_name, 0) or 0)
        if checkpoint_value > 0 and source_marker not in source_lower:
            issues.append({
                "code": "required_feature_not_constructed",
                "feature": checkpoint_name,
                "checkpoint_dimension": checkpoint_value,
            })

    formal_base_dim = None
    formal_observation_dim = None
    deployment_observation_dim = None
    if not missing:
        formal_base_dim = (
            int(custom["target_obs_dim"])
            + 2
            + int(custom["base_safety_feature_dim"])
            + int(custom["neighbor_prediction_dim"])
            + int(custom["obstacle_motion_dim"])
            + int(custom["agent_id_dim"])
        )
        formal_observation_dim = (
            formal_base_dim
            + int(custom["local_map_dim"])
            + int(custom["neighbor_feature_dim"]) * int(custom["max_neighbors"])
            + 1
            + int(custom["num_agents"]) * formal_base_dim
        )
        deployment_observation_dim = (
            int(constants.get("SCAN_HISTORY_LEN", 0))
            * int(constants.get("OBSTACLE_TOP_K_DEFAULT", 0))
            * int(constants.get("OBSTACLE_POINT_FEAT_DIM", 0))
            + 2
            + 2
            + int(constants.get("SAFETY_FEAT_DIM", 0))
            + int(constants.get("NEIGHBOR_FEAT_DIM", 0))
            * int(custom["max_neighbors"])
        )
        if formal_observation_dim != deployment_observation_dim:
            issues.append({
                "code": "observation_dimension_mismatch",
                "checkpoint": formal_observation_dim,
                "deployment": deployment_observation_dim,
            })

    return {
        "compatible": not issues,
        "formal_base_dimension": formal_base_dim,
        "formal_observation_dimension": formal_observation_dim,
        "deployment_observation_dimension": deployment_observation_dim,
        "issues": issues,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("checkpoint", type=Path, help="RLlib algorithm_state.pkl")
    parser.add_argument("--deployment-node", type=Path, default=DEFAULT_NODE)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    try:
        config = load_checkpoint_config(args.checkpoint)
        result = audit(config, args.deployment_node.read_text(encoding="utf-8"))
    except Exception as exc:
        result = {"compatible": False, "issues": [{"code": "audit_error", "detail": str(exc)}]}

    payload = json.dumps(result, indent=2, sort_keys=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload + "\n", encoding="utf-8")
    print(payload)
    return 0 if result["compatible"] else 3


if __name__ == "__main__":
    raise SystemExit(main())
