#!/usr/bin/env python3
"""Validate the five-day matrix and its common-initialization controls."""

from __future__ import annotations

import csv
import argparse
import hashlib
import json
import re
from pathlib import Path

import gymnasium as gym
import torch

from gnn_marl_training.gat_rllib_model import GATRLlibModel


ROOT = Path("/home/wj/work/multi-robot-exploration-rl")
MATRIX = ROOT / "experiments/five_day_fair_training_matrix.tsv"


def option(arguments: str, name: str, default: str | None = None) -> str | None:
    match = re.search(rf"(?:^|\s){re.escape(name)}\s+([^\s]+)", arguments)
    return match.group(1) if match else default


def gat_config(ablation: str, residual_scale: float) -> dict:
    return {
        "custom_model_config": {
            "num_agents": 4,
            "max_neighbors": 5,
            "neighbor_feature_dim": 7,
            "hidden_dim": 128,
            "gat_hidden_dim": 128,
            "lstm_hidden_dim": 256,
            "n_gat_heads": 4,
            "actor_graph_mode": "neighbor",
            "graph_ablation": ablation,
            "graph_architecture": "dual",
            "graph_gate_mode": "vector",
            "graph_residual_scale": residual_scale,
            "critic_mode": "mlp",
            "scan_history_len": 8,
            "target_obs_dim": 6,
            "base_safety_feature_dim": 2,
            "predictive_feature_dim": 0,
            "gap_feature_dim": 0,
            "neighbor_prediction_dim": 14,
            "neighbor_prediction_feature_dim": 7,
            "obstacle_motion_dim": 21,
            "obstacle_motion_feature_dim": 7,
            "local_map_dim": 4096,
            "agent_id_dim": 8,
        }
    }


def build_gat(ablation: str, residual_scale: float, seed: int) -> GATRLlibModel:
    torch.manual_seed(seed)
    return GATRLlibModel(
        gym.spaces.Box(-1.0, 1.0, shape=(4397,)),
        gym.spaces.Box(-1.0, 1.0, shape=(2,)),
        4,
        gat_config(ablation, residual_scale),
        f"fair_{ablation}_{residual_scale}_{seed}",
    )


def validate_matrix() -> None:
    with MATRIX.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    expected = {
        "graph_off_cf0",
        "social_cf0",
        "obstacle_cf0",
        "dual_cf0",
        "dual_cf015",
    }
    if {row["variant"] for row in rows} != expected:
        raise ValueError("five-day variant set mismatch")
    for row in rows:
        arguments = row["extra_args"]
        expected_cf = 0.15 if row["variant"] == "dual_cf015" else 0.0
        if float(option(arguments, "--counterfactual_advantage_coef", "0")) != expected_cf:
            raise ValueError(f"CF must be disabled in {row['variant']}")
    graph_off = next(row for row in rows if row["variant"] == "graph_off_cf0")
    if option(graph_off["extra_args"], "--graph_gate_mode") != "vector":
        raise ValueError("graph-off must keep the vector-gate shell")
    if float(option(graph_off["extra_args"], "--graph_residual_scale", "1")) != 0.0:
        raise ValueError("graph-off residual scale must be zero")
    dual_cf0 = next(row for row in rows if row["variant"] == "dual_cf0")
    dual_cf015 = next(row for row in rows if row["variant"] == "dual_cf015")
    normalized_cf0 = re.sub(r"--counterfactual_advantage_coef\s+\S+", "", dual_cf0["extra_args"])
    normalized_cf15 = re.sub(r"--counterfactual_advantage_coef\s+\S+", "", dual_cf015["extra_args"])
    if normalized_cf0.split() != normalized_cf15.split():
        raise ValueError("dual shaping on/off rows differ by more than the shaping coefficient")


def state_hash(model: GATRLlibModel) -> str:
    digest = hashlib.sha256()
    for name, tensor in model.state_dict().items():
        digest.update(name.encode("utf-8"))
        digest.update(tensor.detach().cpu().numpy().tobytes())
    return digest.hexdigest()


def validate_models() -> dict:
    manifest = {"training_seeds": {}}
    for seed in (1, 2, 3):
        variants = [
            build_gat("dual_graph", 0.0, seed),
            build_gat("social_only", 1.0, seed),
            build_gat("obstacle_only", 1.0, seed),
            build_gat("dual_graph", 1.0, seed),
            build_gat("dual_graph", 1.0, seed),
        ]
        hashes = [state_hash(model) for model in variants]
        if len(set(hashes)) != 1:
            raise RuntimeError(f"common initialization mismatch for seed={seed}")
        observations = torch.zeros((2, 4397), dtype=torch.float32)
        state = [torch.zeros((2, 256)), torch.zeros((2, 256))]
        for model in variants:
            actions, _ = model(
                {"obs": observations, "obs_flat": observations},
                state,
                torch.tensor([1, 1]),
            )
            if actions.shape != (2, 4) or not torch.isfinite(actions).all():
                raise RuntimeError("non-finite graph-model preflight output")
        manifest["training_seeds"][str(seed)] = {"initial_state_sha256": hashes[0]}
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    validate_matrix()
    manifest = validate_models()
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print("OK five-day fair protocol: matrix, common initialization, and model forwards")
