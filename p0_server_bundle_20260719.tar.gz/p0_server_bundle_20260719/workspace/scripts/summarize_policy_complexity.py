#!/usr/bin/env python3
"""Build CSV and Markdown complexity artifacts from checkpoint profiles."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path


def load_profiles(paths: list[Path]) -> list[dict]:
    return [json.loads(path.read_text(encoding="utf-8")) for path in paths]


def write_csv(path: Path, rows: list[dict]) -> None:
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def load_team_scaling(path: Path | None) -> list[dict]:
    if path is None or not path.is_file():
        return []
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    selected = []
    for row in rows:
        if row.get("factor") == "team_size":
            selected.append(row)
        elif row.get("condition") == "baseline":
            baseline = dict(row)
            baseline["factor"] = "team_size"
            baseline["factor_value"] = row.get("num_agents", "4")
            selected.append(baseline)
    return selected


def number(value, digits=2):
    try:
        result = float(value)
    except (TypeError, ValueError):
        return "NA"
    return f"{result:.{digits}f}" if math.isfinite(result) else "NA"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("profiles", nargs="+", type=Path)
    parser.add_argument("--team-scaling", type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args()
    rows = load_profiles(args.profiles)
    if not rows:
        raise SystemExit("no policy profiles")
    profiled_batches = {
        int(row["fixed_micro_batch_size"])
        for row in rows if row.get("fixed_micro_batch_size") is not None
    }
    if profiled_batches and profiled_batches != {1}:
        raise SystemExit(f"latency profiles do not share fixed micro-batch=1: {profiled_batches}")
    for device in {str(row["device_label"]) for row in rows}:
        hardware = {
            str(row.get("hardware")) for row in rows
            if str(row["device_label"]) == device
        }
        if len(hardware) != 1:
            raise SystemExit(f"hardware changed within device stratum {device}: {hardware}")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.out_dir / "policy_complexity_profiles.csv", rows)
    scaling = load_team_scaling(args.team_scaling)

    lines = [
        "# Policy Complexity and Decision-Time Report",
        "",
        "## Empirical checkpoint profile",
        "",
        "| Method | Device | Robots | Batch | Total params (M) | Effective actor (M) | Active graph (M) | Team mean (ms) | Per robot (ms) | P95 | P99 | 10 Hz P99 |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in sorted(
        rows,
        key=lambda item: (
            item["method"], item["device_label"], int(item.get("profiled_team_size", 1)),
        ),
    ):
        lines.append(
            "| {method} | {device} | {team} | {batch} | {params:.3f} | {actor:.3f} | {graph:.3f} | {mean:.2f} | {per_robot:.2f} | {p95:.2f} | {p99:.2f} | {deadline} |".format(
                method=row["method"], device=row["device_label"],
                team=int(row.get("profiled_team_size", 1)),
                batch=int(row.get("fixed_micro_batch_size", 1)),
                params=row["total_parameters"] / 1e6,
                actor=row.get("effective_actor_parameters", row["actor_parameters_by_name"]) / 1e6,
                graph=row.get("active_graph_parameters", 0) / 1e6,
                mean=row["latency_ms_mean"],
                per_robot=row.get("per_robot_latency_ms_mean", row["latency_ms_mean"]),
                p95=row["latency_ms_p95"], p99=row["latency_ms_p99"],
                deadline="yes" if row["meets_10hz_at_p99"] else "no",
            )
        )

    lines.extend([
        "",
        "Each device is a separate fixed-hardware stratum. Team latency is one sequential decision cycle for N shared decentralized actors with micro-batch 1; per-robot latency is team latency divided by N. The centralized training critic is bypassed. Total parameters cover the complete common actor-critic shell, while effective actor parameters count only modules that can influence the deployed action. Inactive graph modules remain in checkpoints solely to preserve common initialization.",
        "",
        "Hardware: " + "; ".join(
            f"{device}={next(str(row.get('hardware')) for row in rows if str(row['device_label']) == device)}"
            for device in sorted({str(row["device_label"]) for row in rows})
        ),
        "",
        "## Team-size decision-time scaling",
        "",
    ])
    if scaling:
        lines.extend([
            "| Robots | Episodes | Mean decision time (ms) | P95 (ms) | Agent success (%) | Collision (%) |",
            "|---:|---:|---:|---:|---:|---:|",
        ])
        for row in sorted(scaling, key=lambda item: float(item["factor_value"])):
            lines.append(
                f"| {int(float(row['factor_value']))} | {row['n_episodes']} | {number(row.get('inference_ms_mean'))} | {number(row.get('inference_ms_p95'))} | {number(row.get('agent_success_pct'))} | {number(row.get('agent_collision_pct'))} |"
            )
    else:
        lines.append(
            "No simulator-based team-size navigation artifact was supplied; actor-only "
            "1/4/8-robot latency scaling is reported in the empirical profile above."
        )

    lines.extend([
        "",
        "## Asymptotic complexity",
        "",
        "Let `N` be the number of robots, `M` the perceived moving obstacles per robot, `K_s` and `K_o` the retained social and obstacle tokens, `d` the graph width, `H` the LSTM width, and `I` its input width.",
        "",
        "- Pairwise risk/token construction costs `O(N(N + M))` for the whole team and `O(N + M)` per decentralized robot. Top-k retention bounds the downstream token counts by `K_s` and `K_o`.",
        "- One LSTM decision costs `O(H(I + H))` per robot. The exact four-gate constant is represented in the measured latency and partial-FLOP profile.",
        "- A star-shaped GAT branch costs `O(K d^2 + K d)` per robot; enabling token-token edges changes its attention term to `O(K^2 d)`. The dual graph adds the social and obstacle branch costs, not their Cartesian product.",
        "- With bounded top-k tokens, decentralized actor execution is linear in team size: `O(N[H(I+H) + (K_s+K_o)d^2])`. Without top-k bounding and with dense token-token edges, the graph term can become quadratic in perceived entities.",
        "- The centralized critic is training-only. Counterfactual credit evaluates the full state and leave-one-agent-out states, adding up to `O(N C_critic)` critic work per joint batch (vectorized in the implementation). It does not add a counterfactual pass to the deployed actor, so Full and no-CF have the same actor architecture and asymptotic decision cost.",
        "- The geometric safety filter is separate from policy inference and costs `O(N + M)` per robot for neighbor/obstacle checks. Policy latency, filter latency, simulator real-time factor, and ROS transport latency must therefore be reported as distinct layers.",
        "",
        "The empirical profile measures the RLlib policy wrapper with deterministic actions on a zero observation after warm-up. Simulator episode artifacts remain the primary deployment-proximal timing evidence; no result here represents sensor-to-actuator ROS or physical-robot latency.",
    ])
    (args.out_dir / "COMPLEXITY_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote {len(rows)} profiles to {args.out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
