#!/usr/bin/env python3
"""Reject formal training runs with Ray recovery or non-progress iterations."""

from __future__ import annotations

import argparse
import csv
import json
import re
import time
from pathlib import Path


EVENT_PATTERNS = {
    "oom": re.compile(r"workers? \(tasks / actors\) killed due to memory pressure \(OOM\)", re.I),
    "no_samples": re.compile(r"No samples returned from remote workers", re.I),
    "actor_unavailable": re.compile(r"actor .* unavailable", re.I),
}


def _prefer_final_attempt_log(log_path: Path) -> Path:
    """Use the latest checkpoint's attempt log when a matrix log is cumulative."""
    match = re.fullmatch(r"(?P<variant>.+)_seed(?P<seed>\d+)_map(?P<map>\d+)\.log", log_path.name)
    manifest = log_path.parent / "training_manifest.tsv"
    if not match or not manifest.is_file():
        return log_path

    variant = match.group("variant")
    seed = match.group("seed")
    map_number = match.group("map")
    checkpoint = ""
    with manifest.open(encoding="utf-8") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            if (
                row.get("variant") == variant
                and row.get("seed") == seed
                and row.get("map") == map_number
                and row.get("status") == "trained"
            ):
                checkpoint = row.get("checkpoint", "")
    if not checkpoint:
        return log_path
    run_id = Path(checkpoint).parent.parent.name
    attempt_log = log_path.parent.parent / run_id / "stage1_train.log"
    return attempt_log if attempt_log.is_file() else log_path


def audit(log_path: Path, monitor_path: Path) -> dict:
    retry_marker = log_path.parent / "health_retry_in_progress"
    while retry_marker.is_file():
        time.sleep(30)
    log_path = _prefer_final_attempt_log(log_path)
    text = log_path.read_text(encoding="utf-8", errors="replace")
    events = {name: len(pattern.findall(text)) for name, pattern in EVENT_PATTERNS.items()}

    with monitor_path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    steps = [int(float(row["environment_steps"])) for row in rows]
    step_counts: dict[int, int] = {}
    for step in steps:
        step_counts[step] = step_counts.get(step, 0) + 1
    duplicate_steps = {
        str(step): count for step, count in step_counts.items() if count > 1
    }
    zero_progress_rows = sum(
        1 for row in rows if int(float(row.get("steps_this_iter", "0") or 0)) == 0
    )
    issues = []
    for name, count in events.items():
        if count:
            issues.append({"code": name, "count": count})
    if duplicate_steps:
        issues.append({"code": "duplicate_environment_steps", "steps": duplicate_steps})
    if zero_progress_rows:
        issues.append({"code": "zero_progress_iterations", "count": zero_progress_rows})
    return {
        "healthy": not issues,
        "log": str(log_path),
        "monitor": str(monitor_path),
        "rows": len(rows),
        "last_environment_steps": steps[-1] if steps else None,
        "events": events,
        "issues": issues,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("log", type=Path)
    parser.add_argument("monitor", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = audit(args.log, args.monitor)
    payload = json.dumps(result, indent=2, sort_keys=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload + "\n", encoding="utf-8")
    print(payload)
    return 0 if result["healthy"] else 3


if __name__ == "__main__":
    raise SystemExit(main())
