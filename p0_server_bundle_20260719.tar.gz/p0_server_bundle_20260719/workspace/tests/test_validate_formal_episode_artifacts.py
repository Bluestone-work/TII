import hashlib
import json

from scripts.validate_formal_episode_artifacts import validate_record


def record(dynamic_obstacles=0, eligible=True):
    routes = {"agent_0": {"goal": [1.0, 0.0], "start": [0.0, 0.0]}}
    payload = json.dumps(routes, sort_keys=True, separators=(",", ":"))
    return {
        "steps": 10, "reached_agents": 1, "collided_agents": 0,
        "truncated": False, "agent_success_rate": 1.0, "team_success": True,
        "collision_rate": 0.0, "timeout_rate": 0.0, "SR": 1.0,
        "TSR": 1.0, "CR": 0.0, "spl": 1.0, "path_length": 1.0,
        "completion_time": 1.0,
        "successful_agent_completion_time_mean": 1.0,
        "successful_agent_completion_time_sum": 1.0,
        "successful_agent_completion_time_count": 1,
        "minimum_clearance": 0.5, "clearance_p05": 0.6,
        "near_collision_count": 0, "deadlock": False, "oscillation_count": 0,
        "control_jerk": 0.0, "filter_intervention_rate": 0.0,
        "filter_intervention_count": 0, "filter_action_samples": 10,
        "filter_action_difference": 0.0,
        "policy_only_inference_latency_ms_mean": 1.0, "control_dt": 0.1,
        "safety_filter_latency_ms_mean": 0.1, "safety_filter_latency_samples": 10,
        "episode_wall_time_s": 2.0, "real_time_factor": 0.5,
        "episode_index": 0, "episode_seed": 7, "num_agents": 1,
        "map_number": 5, "num_dynamic_obstacles": dynamic_obstacles,
        "max_episode_steps": 3000, "shield_enable": True,
        "evaluation_system": "policy_plus_safety_filter", "controller": "policy",
        "seed": 7, "training_seed": 1, "method": "full", "scenario": "map5",
        "initial_start_goal": routes,
        "initial_state_fingerprint": hashlib.sha256(payload.encode("ascii")).hexdigest(),
        "paired_scenario_eligible": eligible,
        "pairing_basis": (
            "start_goal_static_environment" if dynamic_obstacles == 0
            else "unverified_dynamic_obstacle_trajectory"
        ),
        "dynamic_obstacle_trajectory_fingerprint": "",
        "dynamic_obstacle_trajectory_spec": {},
    }


def test_valid_static_record():
    assert validate_record(record(), {5: 3000}, {}) == []


def test_dynamic_record_cannot_claim_pairing():
    errors = validate_record(record(dynamic_obstacles=2, eligible=True), {5: 3000}, {})
    assert any("lacks fixed trajectory basis" in error for error in errors)


def test_seeded_dynamic_record_can_be_strictly_paired():
    row = record(dynamic_obstacles=2, eligible=True)
    row["pairing_basis"] = "fixed_start_goal_and_dynamic_trajectory"
    row["dynamic_obstacle_trajectory_fingerprint"] = "a" * 64
    assert validate_record(row, {5: 3000}, {}) == []


def test_fingerprint_tampering_is_rejected():
    row = record()
    row["initial_start_goal"]["agent_0"]["goal"] = [2.0, 0.0]
    errors = validate_record(row, {5: 3000}, {})
    assert any("does not match" in error for error in errors)


def test_scenario_manifest_route_mismatch_is_rejected():
    row = record()
    row["scenario_case"] = "fixed"
    scenario = {
        "fixed": {
            "map_number": 5,
            "num_agents": 1,
            "max_episode_steps": 3000,
            "num_dynamic_obstacles": 0,
            "route_plan": {"agent_0": [[0.5, 0.0], [1.0, 0.0]]},
        }
    }
    errors = validate_record(row, {5: 3000}, scenario)
    assert any("frozen scenario route plan" in error for error in errors)


def test_shield_off_requires_policy_only_attribution():
    row = record()
    row["shield_enable"] = False
    row["evaluation_system"] = "policy_plus_safety_filter"
    errors = validate_record(row, {5: 3000}, {})
    assert any("policy_only attribution" in error for error in errors)
