import csv

from scripts.validate_formal_training_logs import REQUIRED_FIELDS, validate


def test_training_log_validation(tmp_path):
    path = tmp_path / "training_monitor.csv"
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(REQUIRED_FIELDS))
        writer.writeheader()
        writer.writerow({field: 1.0 for field in REQUIRED_FIELDS})
    missing, empty = validate(path, require_gpu=True)
    assert missing == []
    assert empty == []
