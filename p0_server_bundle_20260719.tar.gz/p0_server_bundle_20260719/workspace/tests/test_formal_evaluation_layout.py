from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_paired_evaluation_isolates_variant_outputs():
    runner = (ROOT / "experiments" / "run_formal_paired_evaluation.sh").read_text(
        encoding="utf-8"
    )

    assert 'out="$OUT_ROOT/$group/${condition}_${variant}/seed${seed}"' in runner
    assert 'out="$OUT_ROOT/$group/$condition/seed${seed}"' not in runner
