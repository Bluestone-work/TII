import csv

from scripts.audit_formal_training_health import audit


def write_monitor(path, steps_this_iter):
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["environment_steps", "steps_this_iter"],
        )
        writer.writeheader()
        for index, value in enumerate(steps_this_iter):
            writer.writerow({"environment_steps": value, "steps_this_iter": value - (index * 2000)})


def test_rejects_ray_recovery_and_duplicate_progress(tmp_path):
    log = tmp_path / "run.log"
    log.write_text(
        "workers (tasks / actors) killed due to memory pressure (OOM)\n"
        "No samples returned from remote workers\n"
        "actor abc unavailable\n",
        encoding="utf-8",
    )
    monitor = tmp_path / "monitor.csv"
    write_monitor(monitor, [2000, 4000, 4000])
    result = audit(log, monitor)
    assert not result["healthy"]
    assert {issue["code"] for issue in result["issues"]} >= {
        "oom", "no_samples", "actor_unavailable", "duplicate_environment_steps",
    }


def test_accepts_clean_progress(tmp_path):
    log = tmp_path / "run.log"
    log.write_text("training iteration complete\n", encoding="utf-8")
    monitor = tmp_path / "monitor.csv"
    write_monitor(monitor, [2000, 4000, 6000])
    result = audit(log, monitor)
    assert result["healthy"], result["issues"]
