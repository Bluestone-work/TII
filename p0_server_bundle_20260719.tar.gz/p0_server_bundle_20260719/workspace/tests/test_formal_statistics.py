from scripts.formal_statistics import (
    hierarchical_paired_bootstrap,
    holm_adjust,
    inferential_tests,
    summarize_across_seeds,
    validate_records,
)


def records():
    rows = []
    for seed in range(1, 6):
        for episode in range(4):
            for method, offset in (("full", 0.2), ("no_cf", 0.1), ("social", 0.0)):
                rows.append({
                    "method": method,
                    "training_seed": seed,
                    "scenario": "map9",
                    "map_number": 9,
                    "episode_index": episode,
                    "initial_state_fingerprint": f"seed{seed}-episode{episode}",
                    "paired_scenario_eligible": True,
                    "pairing_basis": "fixed_scenario_bank",
                    "spl": seed * 0.01 + episode * 0.001 + offset,
                })
    return rows


def test_seed_aware_statistics():
    rows = records()
    validate_records(rows, require_pairing_metadata=True)
    summary = summarize_across_seeds(rows, ["spl"])
    assert len(summary) == 3
    assert all(row["n_training_seeds"] == 5 for row in summary)
    observed, low, high, n_seeds, n_units = hierarchical_paired_bootstrap(
        rows, "spl", "full", "social", samples=1000
    )
    assert n_seeds == 5
    assert n_units == 20
    assert low <= observed <= high
    friedman, pairwise, bootstrap = inferential_tests(rows, ["spl"], "full", 1000)
    assert len(friedman) == 1
    assert len(pairwise) == 2
    assert len(bootstrap) == 2


def test_bootstrap_excludes_mismatched_and_ineligible_scenarios():
    rows = records()
    for row in rows:
        if row["method"] == "social" and row["episode_index"] == 0:
            row["initial_state_fingerprint"] = "different"
        if row["episode_index"] == 1:
            row["paired_scenario_eligible"] = False
            row["pairing_basis"] = "unverified_dynamic_obstacle_trajectory"
    _observed, _low, _high, n_seeds, n_units = hierarchical_paired_bootstrap(
        rows, "spl", "full", "social", samples=1000
    )
    assert n_seeds == 5
    assert n_units == 10


def test_non_learning_baseline_has_no_training_seed_variance():
    rows = records()
    for row in list(rows):
        if row["method"] != "full":
            continue
        for seed in range(1, 6):
            duplicate = dict(row, method="orca_dwa", training_seed=seed, spl=0.5)
            rows.append(duplicate)
    summary = summarize_across_seeds(rows, ["spl"])
    orca = next(row for row in summary if row["method"] == "orca_dwa")
    assert orca["n_training_seeds"] == 0
    assert orca["mean_across_seeds"] == 0.5


def test_holm_is_monotone_in_sorted_p_order():
    raw = [0.04, 0.001, 0.02]
    adjusted = holm_adjust(raw)
    ordered = sorted(zip(raw, adjusted))
    assert [value for _raw, value in ordered] == sorted(value for _raw, value in ordered)
