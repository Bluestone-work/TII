from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

from analyze_paired_interventions import validate_rows  # noqa: E402
from paired_intervention_metrics import (  # noqa: E402
    compute_metrics,
    random_mask_distribution,
    spearman_correlation,
)


def sample_rows(states: int = 6, agents: int = 4) -> list[dict]:
    rows = []
    for state in range(states):
        for agent in range(agents):
            marginal = float((agent + 1) * (state + 1))
            rows.append({
                "state_id": f"state_{state}",
                "num_agents": agents,
                "agent": f"agent_{agent}",
                "agent_index": agent,
                "estimated_credit": marginal,
                "baseline_return": 20.0 + state,
                "intervention_return": 20.0 + state - marginal,
                "marginal_return": marginal,
                "baseline_start_fingerprint": f"fp_{state}",
                "intervention_start_fingerprint": f"fp_{state}",
            })
    return rows


def test_spearman_uses_average_tie_ranks() -> None:
    assert np.isclose(spearman_correlation([1, 1, 2], [3, 3, 4]), 1.0)
    assert np.isnan(spearman_correlation([1, 1, 1], [1, 2, 3]))


def test_primary_metrics_on_perfect_credit() -> None:
    result = compute_metrics(sample_rows())
    assert np.isclose(result.spearman, 1.0)
    assert np.isclose(result.sign_agreement, 1.0)
    assert np.isclose(result.top1_accuracy, 1.0)
    assert result.n_states == 6
    assert result.n_pairs == 24


def test_random_mask_breaks_agent_assignment() -> None:
    rows = sample_rows(states=80)
    _repeats, summary = random_mask_distribution(rows, repeats=400, seed=7)
    top1_mean = summary["top1_accuracy"][0]
    assert 0.20 < top1_mean < 0.30
    assert summary["spearman"][0] < 0.1


def test_validation_rejects_fingerprint_mismatch_and_incomplete_state(tmp_path: Path) -> None:
    rows = sample_rows(states=2, agents=2)
    rows[0]["intervention_start_fingerprint"] = "different"
    rows.pop()
    path = tmp_path / "pairs.jsonl"
    path.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
    accepted, quality = validate_rows([path], identity_tolerance=1e-6)
    assert accepted == []
    assert quality["fingerprint_mismatch"] == 1
    assert quality["incomplete_states"] == 2


def test_validation_accepts_mixed_team_sizes(tmp_path: Path) -> None:
    rows = sample_rows(states=1, agents=2)
    rows.extend(
        dict(row, state_id="state_three", num_agents=3, agent=f"agent_{row['agent_index']}")
        for row in sample_rows(states=1, agents=3)
    )
    path = tmp_path / "mixed_pairs.jsonl"
    path.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
    accepted, quality = validate_rows([path], identity_tolerance=1e-6)
    assert len(accepted) == 5
    assert quality["accepted_states"] == 2
    assert quality["expected_agents_per_state"] == [2, 3]


def test_selector_outputs_complete_stratified_states(tmp_path: Path) -> None:
    trace = tmp_path / "trace.jsonl"
    records = []
    for map_number in (3, 9):
        for step in range(20, 100, 10):
            for agent in range(2):
                records.append({
                    "method": "dual_cf015",
                    "training_seed": 1,
                    "eval_seed": 10,
                    "episode_seed": 11 + map_number,
                    "episode": 0,
                    "map_number": map_number,
                    "step": step,
                    "agent": f"agent_{agent}",
                    "agent_index": agent,
                    "counterfactual_credit": float(agent + step),
                    "event": "",
                    "terminated": False,
                    "truncated": False,
                })
    trace.write_text("".join(json.dumps(row) + "\n" for row in records), encoding="utf-8")
    output = tmp_path / "plan.jsonl"
    subprocess.run([
        sys.executable,
        str(SCRIPTS / "select_paired_intervention_states.py"),
        str(trace),
        "--output", str(output),
        "--target-states", "6",
        "--expected-agents", "2",
        "--min-step-gap", "20",
    ], check=True)
    selected = [json.loads(line) for line in output.read_text(encoding="utf-8").splitlines()]
    assert len(selected) == 6
    assert {row["map_number"] for row in selected} == {3, 9}
    assert all(len(row["agents"]) == 2 for row in selected)


def test_analysis_cli_writes_value_and_random_mask_rows(tmp_path: Path) -> None:
    pairs = tmp_path / "pairs.jsonl"
    pairs.write_text(
        "".join(json.dumps(row) + "\n" for row in sample_rows()),
        encoding="utf-8",
    )
    output = tmp_path / "analysis"
    subprocess.run([
        sys.executable,
        str(SCRIPTS / "analyze_paired_interventions.py"),
        str(pairs),
        "--out-dir", str(output),
        "--random-repeats", "20",
        "--bootstrap-repeats", "20",
    ], check=True)
    lines = (output / "paired_intervention_metrics.csv").read_text(
        encoding="utf-8").splitlines()
    assert len(lines) == 3
    assert "value_difference" in lines[1]
    assert "random_mask" in lines[2]
    assert (output / "REPORT.md").is_file()
