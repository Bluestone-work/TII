import csv
import json
import subprocess
import sys


def test_generates_data_backed_tables_and_factor_figures(tmp_path):
    episodes = tmp_path / "episodes.jsonl"
    rows = []
    for seed in range(1, 6):
        for agents in (2, 4, 6):
            for count in (2, 4):
                for speed in (0.05, 0.10):
                    for shield in (False, True):
                        rows.append({
                            "method": "full" if shield else "full_filter_off",
                            "training_seed": seed,
                            "scenario": f"scenario_{count}_{speed}",
                            "episode_index": 0,
                            "graph_architecture": "dual" if shield else "single",
                            "counterfactual_advantage_coef": 0.15,
                            "shield_enable": shield,
                            "num_agents": agents,
                            "num_dynamic_obstacles": count,
                            "obs_speed": speed,
                            "agent_success_rate": 0.8,
                            "team_success": True,
                            "collision_rate": 0.1,
                            "timeout_rate": 0.1,
                            "spl": 0.7,
                            "path_length": 5.0,
                            "completion_time": 10.0,
                            "minimum_clearance": 0.4,
                            "clearance_p05": 0.5,
                            "minimum_ttc": 1.0,
                            "deadlock": False,
                            "control_jerk": 0.2,
                            "filter_action_difference": 0.1,
                            "policy_only_inference_latency_ms_mean": agents * 0.5,
                            "safety_filter_latency_ms_mean": agents * 0.05,
                            "real_time_factor": 0.8,
                        })
    episodes.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
    resources = tmp_path / "team_n4" / "seed1" / "resources.csv"
    resources.parent.mkdir(parents=True)
    resources.write_text(
        "elapsed_s,process_rss_kb,process_cpu_pct,system_available_kb,process_gpu_memory_mb\n"
        "0,1024,10,100000,256\n5,2048,20,99000,512\n",
        encoding="utf-8",
    )
    out_dir = tmp_path / "out"
    subprocess.run([
        sys.executable,
        "-m",
        "scripts.generate_formal_artifacts",
        str(episodes),
        "--resource-files",
        str(resources),
        "--out-dir",
        str(out_dir),
    ], check=True)
    assert (out_dir / "main_performance_table.csv").is_file()
    assert (out_dir / "single_vs_dual_by_scenario.png").is_file()
    assert (out_dir / "safety_filter_intervention_analysis.png").is_file()
    assert (out_dir / "team_size_generalization.png").is_file()
    assert (out_dir / "speed_count_interaction_heatmap.png").is_file()
    assert (out_dir / "runtime_scaling.png").is_file()
    assert (out_dir / "runtime_memory_scaling.csv").is_file()
    with (out_dir / "artifact_status.csv").open(newline="", encoding="utf-8") as handle:
        status = {row["artifact"]: row["generated"] for row in csv.DictReader(handle)}
    assert status["training_curves_seed_bands"] == "0"
