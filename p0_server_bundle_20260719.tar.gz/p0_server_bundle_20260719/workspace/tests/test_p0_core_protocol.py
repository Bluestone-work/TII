import csv
import json

from scripts.summarize_p0_core_results import MAPS, METHODS, SEEDS, main as summarize_main
from scripts.summarize_p0_p1_results import main as summarize_p1_main


def test_p0_matrix_initialization_and_capacity_match():
    __import__("pytest").importorskip("gymnasium")
    from scripts.validate_p0_core_protocol import (
        build_model,
        read_matrix,
        validate_models,
        validate_scenario_banks,
    )

    rows = read_matrix(
        __import__("pathlib").Path("experiments/p0_core_training_matrix.tsv")
    )
    assert [row["variant"] for row in rows] == list(METHODS)
    manifest = validate_models()
    counts = manifest["active_graph_parameters"]
    assert counts["p0_graph_off"] == 0
    assert counts["unified_dual_relative_gap"] < 0.01
    assert len(manifest["training_seeds"]) == 3
    assert validate_scenario_banks()["p0_p1_map3_v1"] == ["paired_map3"]

    from scripts.profile_policy_complexity import effective_actor_parameter_count
    effective = {
        "graph_off": effective_actor_parameter_count(build_model("dual", 0.0, 1)),
        "unified": effective_actor_parameter_count(build_model("single", 1.0, 1)),
        "dual": effective_actor_parameter_count(build_model("dual", 1.0, 1)),
    }
    assert effective["graph_off"] < effective["unified"]
    assert abs(effective["unified"] - effective["dual"]) / effective["dual"] < 0.01

    model = build_model("dual", 0.0, 1)
    model._encode_neighbor_social_branch = lambda *_args, **_kwargs: (_ for _ in ()).throw(
        AssertionError("graph-off executed social graph")
    )
    model._encode_obstacle_graph_branch = lambda *_args, **_kwargs: (_ for _ in ()).throw(
        AssertionError("graph-off executed obstacle graph")
    )
    import torch
    observations = torch.zeros((1, 4397), dtype=torch.float32)
    model(
        {"obs": observations, "obs_flat": observations},
        [torch.zeros((1, 256)), torch.zeros((1, 256))],
        torch.tensor([1]),
    )


def test_p0_summary_uses_training_seed_as_unit(tmp_path, monkeypatch):
    records = []
    for method_index, method in enumerate(METHODS):
        for map_number in MAPS:
            for seed in SEEDS:
                for episode in range(2):
                    records.append({
                        "method": method,
                        "map_number": map_number,
                        "training_seed": seed,
                        "agent_success_rate": 0.1 * method_index + 0.01 * seed,
                        "team_success": float(episode == 0),
                        "collision_rate": 0.2,
                        "timeout_rate": 0.3,
                        "path_length": 4.0 + episode,
                        "spl": 0.6,
                        "successful_agent_completion_time_sum": 1.0 + episode,
                        "successful_agent_completion_time_count": 1,
                        "filter_intervention_count": episode,
                        "filter_action_samples": 10,
                    })
    source = tmp_path / "episodes.jsonl"
    source.write_text(
        "".join(json.dumps(record) + "\n" for record in records),
        encoding="utf-8",
    )
    out = tmp_path / "out"
    monkeypatch.setattr(
        "sys.argv",
        ["summarize_p0_core_results.py", str(source), "--out-dir", str(out), "--episodes", "2"],
    )
    assert summarize_main() == 0
    with (out / "per_training_seed.csv").open(newline="", encoding="utf-8") as handle:
        per_seed = list(csv.DictReader(handle))
    with (out / "mean_std_across_training_seeds.csv").open(newline="", encoding="utf-8") as handle:
        across_seed = list(csv.DictReader(handle))
    assert len(per_seed) == len(METHODS) * len(MAPS) * len(SEEDS)
    assert len(across_seed) == len(METHODS) * len(MAPS)
    assert all(int(row["n_training_seeds"]) == 3 for row in across_seed)
    assert all(float(row["SuccessOnlyTTG"]) == 1.5 for row in per_seed)
    assert all(float(row["FilterInterventionRate"]) == 0.05 for row in per_seed)


def test_p1_summary_keeps_filter_conditions_separate(tmp_path, monkeypatch):
    records = []
    for method in METHODS:
        for condition in ("filter_off", "filter_on"):
            for seed in SEEDS:
                for episode in range(2):
                    records.append({
                        "method": method,
                        "map_number": 3,
                        "training_seed": seed,
                        "experiment_condition": condition,
                        "shield_enable": condition == "filter_on",
                        "agent_success_rate": 0.5,
                        "team_success": 0.0,
                        "collision_rate": 0.25,
                        "timeout_rate": 0.0,
                        "path_length": 4.0 + episode,
                        "spl": 0.6,
                        "successful_agent_completion_time_sum": 1.0 + episode,
                        "successful_agent_completion_time_count": 1,
                        "filter_intervention_count": episode + 1 if condition == "filter_on" else 0,
                        "filter_action_samples": 10,
                    })
    source = tmp_path / "p1.jsonl"
    source.write_text(
        "".join(json.dumps(record) + "\n" for record in records),
        encoding="utf-8",
    )
    out = tmp_path / "p1_out"
    monkeypatch.setattr(
        "sys.argv",
        ["summarize_p0_p1_results.py", str(source), "--out-dir", str(out), "--episodes", "2"],
    )
    assert summarize_p1_main() == 0
    with (out / "per_training_seed.csv").open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == len(METHODS) * len(SEEDS) * 2
    on_rows = [row for row in rows if row["condition"] == "filter_on"]
    off_rows = [row for row in rows if row["condition"] == "filter_off"]
    assert all(float(row["FilterInterventionRate"]) == 0.15 for row in on_rows)
    assert all(float(row["FilterInterventionRate"]) == 0.0 for row in off_rows)
