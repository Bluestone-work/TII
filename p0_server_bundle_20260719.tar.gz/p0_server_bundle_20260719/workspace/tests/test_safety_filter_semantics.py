import ast
from types import SimpleNamespace
from pathlib import Path


def load_shield_method():
    path = Path(
        "src/gnn_marl_training_DGTA_nobuffer/gnn_marl_training/gnn_marl_env.py"
    )
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == "IndependentRobotEnv":
            for item in node.body:
                if isinstance(item, ast.FunctionDef) and item.name == "_apply_safety_shield":
                    module = ast.Module(body=[item], type_ignores=[])
                    namespace = {}
                    exec(compile(ast.fix_missing_locations(module), str(path), "exec"), namespace)
                    return namespace[item.name]
    raise AssertionError("_apply_safety_shield not found")


def test_shield_off_returns_raw_command_even_under_emergency_geometry():
    agent = SimpleNamespace(
        shield_enable=False,
        _predict_swept_clearance=lambda _v, _w: -0.25,
        _predict_command_motion_safety=lambda _v, _w: {
            "margin": -0.5,
            "source": "test_obstacle",
        },
    )
    raw = (0.19, 1.1)
    linear, angular, turn_in_place = load_shield_method()(
        agent,
        *raw,
        front_min=0.01,
        left_min=0.01,
        right_min=0.01,
        target_angle=3.14,
        neighbor_min_dist=0.01,
        front_left_min=0.01,
        front_right_min=0.01,
    )
    assert (linear, angular) == raw
    assert turn_in_place is False
    assert agent._last_swept_filter_active is False
    assert agent._last_motion_filter_active is False
    assert agent._last_motion_safety_margin == -0.5
