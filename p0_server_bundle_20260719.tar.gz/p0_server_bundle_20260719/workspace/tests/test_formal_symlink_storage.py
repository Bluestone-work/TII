from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parents[1]


def test_find_h_follows_symlinked_result_root(tmp_path):
    target = tmp_path / "target"
    record = target / "group" / "condition" / "seed1" / "episodes.jsonl"
    record.parent.mkdir(parents=True)
    record.write_text("{}\n", encoding="ascii")
    logical = tmp_path / "logical"
    logical.symlink_to(target, target_is_directory=True)

    result = subprocess.run(
        ["find", "-H", str(logical), "-type", "f", "-name", "episodes.jsonl"],
        check=True,
        capture_output=True,
        text=True,
    )

    assert result.stdout.strip() == str(logical / "group" / "condition" / "seed1" / "episodes.jsonl")


def test_formal_collectors_follow_logical_storage_roots():
    expected = {
        "experiments/run_formal_paired_evaluation.sh": 'find -H "$OUT_ROOT"',
        "experiments/run_formal_micro_scenarios.sh": 'find -H "$OUT_ROOT"',
        "experiments/run_formal_phase6.sh": 'find -H "$PAIRED_ROOT" "$MICRO_ROOT"',
    }

    for relative_path, command in expected.items():
        source = (ROOT / relative_path).read_text(encoding="utf-8")
        assert command in source
