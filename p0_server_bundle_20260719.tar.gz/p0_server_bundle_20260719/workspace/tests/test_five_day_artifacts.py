import csv
import gzip
import json
import subprocess
import sys

import pytest

from scripts.generate_five_day_report import (
    CONDITIONS,
    DEVICES,
    FILTER_METRICS,
    INTERVENTION_METHODS,
    INTERVENTIONS,
    MAPS,
    METHODS,
    TRAINING_SEEDS,
    validate_complete_artifacts,
)


def write_rows(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def test_value_intervention_analysis_checks_fixed_state_identity(tmp_path):
    trace = tmp_path / "trace.jsonl.gz"
    row = {
        "method": "dual_cf0", "training_seed": 1, "v_full": 2.0,
        "v_zero_agent": 1.0, "delta_v_zero_agent": 1.0,
        "v_mean_agent": 1.5, "delta_v_mean_agent": 0.5,
        "v_zero_social": 1.8, "delta_v_zero_social": 0.2,
        "v_zero_obstacle": 1.7, "delta_v_zero_obstacle": 0.3,
    }
    with gzip.open(trace, "wt", encoding="utf-8") as handle:
        handle.write(json.dumps(row) + "\n")
    out = tmp_path / "out"
    subprocess.run([
        sys.executable, "scripts/analyze_value_interventions.py", str(trace),
        "--out-dir", str(out),
    ], check=True)
    with (out / "value_intervention_summary.csv").open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert {row["intervention"] for row in rows} == {
        "zero_agent", "mean_agent", "zero_social", "zero_obstacle"
    }


def test_paired_collection_validator_rejects_trajectory_mismatch(tmp_path):
    path = tmp_path / "episodes.jsonl"
    rows = []
    for method, trajectory in (("a", "1" * 64), ("b", "2" * 64)):
        rows.append({
            "method": method, "training_seed": 1, "experiment_condition": "filter_off",
            "scenario_case": "paired_map9", "episode_index": 0, "episode_seed": 7,
            "paired_scenario_eligible": True, "shield_enable": False,
            "initial_state_fingerprint": "0" * 64,
            "dynamic_obstacle_trajectory_fingerprint": trajectory,
            "num_dynamic_obstacles": 2,
        })
    path.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
    completed = subprocess.run([
        sys.executable, "scripts/validate_paired_collection.py", str(path),
        "--methods", "a", "b", "--seeds", "1", "--conditions", "filter_off",
        "--episodes-per-case", "1", "--output", str(tmp_path / "summary.json"),
    ], capture_output=True, text=True)
    assert completed.returncode != 0


def test_five_day_report_gate_requires_every_formal_artifact(tmp_path):
    validation = {
        "status": "ok", "records": 3000, "expected_records": 3000,
        "methods": list(METHODS), "training_seeds": list(TRAINING_SEEDS),
        "conditions": list(CONDITIONS),
        "scenario_cases": [f"map{value}" for value in MAPS], "paired_units": 100,
    }
    episodes = [
        {
            "method": method, "map_number": map_number, "training_seed": seed,
            "agent_success_rate": 0.5, "collision_rate": 0.2,
            "timeout_rate": 0.3, "spl": 0.4,
        }
        for method in METHODS for map_number in MAPS for seed in TRAINING_SEEDS
        for _episode in range(25)
    ]
    filter_rows = [
        {
            "method": method, "metric": metric, "n_training_seeds": 3,
            "mean_paired_delta_on_minus_off": 0.1, "std_across_seeds": 0.01,
        }
        for method in METHODS for metric in FILTER_METRICS
    ]
    write_rows(tmp_path / "statistics/safety_filter/filter_paired_by_seed.csv", [
        {
            "method": method, "training_seed": seed, "metric": metric,
            "paired_delta_on_minus_off": 0.1, "n_paired_episodes": 100,
        }
        for method in METHODS for seed in TRAINING_SEEDS for metric in FILTER_METRICS
    ])
    intervention_rows = [
        {
            "method": method, "intervention": intervention, "n_training_seeds": 3,
            "mean_abs_delta_v_across_seeds": 0.2,
            "std_abs_delta_v_across_seeds": 0.02,
        }
        for method in INTERVENTION_METHODS for intervention in INTERVENTIONS
    ]
    write_rows(tmp_path / "statistics/value_interventions/value_intervention_by_seed.csv", [
        {
            "method": method, "training_seed": seed, "intervention": intervention,
            "n_states": 10,
        }
        for method in INTERVENTION_METHODS for seed in TRAINING_SEEDS
        for intervention in INTERVENTIONS
    ])
    complexity_rows = [
        {
            "method": method, "device_label": device,
            "actual_device": "cpu" if device == "cpu" else "cuda:0",
            "total_parameters": 100, "latency_repeats": 200,
            "latency_ms_mean": 1.0, "latency_ms_p95": 1.2,
        }
        for method in METHODS for device in DEVICES
    ]
    write_rows(tmp_path / "learning_curves/learning_curves_per_seed.csv", [
        {
            "method": method, "training_seed": seed, "map_number": map_number,
            "environment_steps": 60000,
        }
        for method in METHODS for seed in TRAINING_SEEDS for map_number in (3, 9)
    ])
    write_rows(tmp_path / "learning_curves/learning_curves_mean_std.csv", [
        {
            "method": method, "map_number": map_number,
            "environment_steps": 60000, "metric": metric,
            "n_training_seeds": 3, "mean": 0.5, "std": 0.1,
        }
        for method in METHODS for map_number in (3, 9)
        for metric in ("episode_reward", "agent_success", "collision_rate", "timeout_rate")
    ])
    for name in ("learning_curves_cross_seed.png", "learning_curves_cross_seed.pdf"):
        (tmp_path / "learning_curves" / name).write_bytes(b"artifact")
    for condition in CONDITIONS:
        stats_root = tmp_path / "statistics" / condition
        write_rows(stats_root / "seed_summary.csv", [{"n_training_seeds": 3}])
        for name in ("friedman_tests.csv", "wilcoxon_holm_effect_sizes.csv", "paired_scenario_bootstrap.csv"):
            write_rows(stats_root / name, [{"present": 1}])

    validate_complete_artifacts(
        tmp_path, validation, episodes, filter_rows, intervention_rows, complexity_rows
    )
    with pytest.raises(SystemExit, match="CPU/GPU complexity coverage mismatch"):
        validate_complete_artifacts(
            tmp_path, validation, episodes, filter_rows, intervention_rows,
            complexity_rows[:-1],
        )
