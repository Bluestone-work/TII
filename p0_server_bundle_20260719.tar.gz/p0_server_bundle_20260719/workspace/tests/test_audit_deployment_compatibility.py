from scripts.audit_deployment_compatibility import audit


FORMAL_CONFIG = {
    "model": {
        "custom_model_config": {
            "num_agents": 4,
            "max_neighbors": 5,
            "neighbor_feature_dim": 7,
            "scan_history_len": 8,
            "target_obs_dim": 6,
            "base_safety_feature_dim": 2,
            "neighbor_prediction_dim": 14,
            "obstacle_motion_dim": 21,
            "local_map_dim": 4096,
            "agent_id_dim": 8,
        }
    }
}


def test_rejects_legacy_deployment_contract():
    source = """
SCAN_HISTORY_LEN = 4
SAFETY_FEAT_DIM = 7
NEIGHBOR_FEAT_DIM = 5
OBSTACLE_TOP_K_DEFAULT = 9
OBSTACLE_POINT_FEAT_DIM = 4
def build(ModelClass):
    return ModelClass(model_config={})
"""
    result = audit(FORMAL_CONFIG, source)
    codes = {issue["code"] for issue in result["issues"]}
    assert not result["compatible"]
    assert "checkpoint_model_config_not_restored" in codes
    assert "feature_dimension_mismatch" in codes
    assert "required_feature_not_constructed" in codes
    assert "observation_dimension_mismatch" in codes


def test_accepts_matching_contract():
    source = """
SCAN_HISTORY_LEN = 1
SAFETY_FEAT_DIM = 2
NEIGHBOR_FEAT_DIM = 7
OBSTACLE_TOP_K_DEFAULT = 9
OBSTACLE_POINT_FEAT_DIM = 5
local_map = agent_id = neighbor_prediction = obstacle_motion = True
def build(ModelClass, checkpoint_model_config):
    return ModelClass(model_config=checkpoint_model_config)
"""
    compatible_config = {
        "model": {
            "custom_model_config": {
                **FORMAL_CONFIG["model"]["custom_model_config"],
                "scan_history_len": 1,
                "local_map_dim": 0,
                "agent_id_dim": 0,
                "neighbor_prediction_dim": 0,
                "obstacle_motion_dim": 0,
            }
        }
    }
    result = audit(compatible_config, source)
    assert result["compatible"], result["issues"]
