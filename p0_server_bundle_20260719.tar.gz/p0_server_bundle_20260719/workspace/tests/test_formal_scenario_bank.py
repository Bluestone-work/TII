import json

from gnn_marl_training.formal_scenario_bank import (
    get_scenario,
    get_scenario_bank,
    write_scenario_manifest,
)


def test_micro_bank_covers_required_categories(tmp_path):
    cases = get_scenario_bank()
    assert {case.category for case in cases} == {
        "head_on", "merge", "crossing", "bottleneck", "deadlock"
    }
    assert len({case.case_id for case in cases}) == len(cases)
    for case in cases:
        assert case.num_agents == len(case.route_plan())
        assert case.max_episode_steps > 0
    path = write_scenario_manifest(tmp_path / "scenarios.json")
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert payload["bank"] == "paper_micro_v1"
    assert len(payload["cases"]) == len(cases)
    assert get_scenario("head_on_main").category == "head_on"


def test_paired_navigation_bank_has_uniform_limits_and_dynamic_cases():
    cases = get_scenario_bank("paired_nav_v1")
    assert [case.map_number for case in cases] == [3, 4, 5, 9]
    assert {case.max_episode_steps for case in cases} == {2000}
    assert all(case.num_agents == 4 for case in cases)
    assert any(case.num_dynamic_obstacles > 0 for case in cases)


def test_p0_core_bank_has_primary_and_held_out_maps():
    cases = get_scenario_bank("p0_core_v1")
    assert [case.map_number for case in cases] == [4, 9, 5]
    assert {case.max_episode_steps for case in cases} == {2000}
    assert [case.num_dynamic_obstacles for case in cases] == [2, 6, 0]
