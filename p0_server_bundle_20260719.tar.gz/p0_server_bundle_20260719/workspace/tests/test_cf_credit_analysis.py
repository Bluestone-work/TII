import csv
import json
import subprocess
import sys


def test_cf_analysis_outputs(tmp_path):
    trace = tmp_path / "trace.jsonl"
    records = []
    for step, credit in enumerate((-1.0, 1.0, -0.5, 0.5), 1):
        records.append({
            "episode": 0,
            "step": step,
            "agent": "agent_0",
            "method": "full",
            "map_number": 9,
            "counterfactual_credit": credit,
            "dynamic_obs_ttc_risk": 0.1 * step,
            "gate_mean": 0.2 * step,
            "event": "goal" if step == 4 else "",
        })
    trace.write_text("".join(json.dumps(row) + "\n" for row in records), encoding="utf-8")
    out_dir = tmp_path / "out"
    subprocess.run([
        sys.executable,
        "scripts/analyze_cf_credit_trace.py",
        str(trace),
        "--out-dir",
        str(out_dir),
    ], check=True)
    with (out_dir / "cf_credit_sign_flip_rate.csv").open(newline="", encoding="utf-8") as handle:
        row = next(csv.DictReader(handle))
    assert int(row["sign_flips"]) == 3
    assert (out_dir / "cf_credit_attribution_ranking.csv").is_file()
    assert (out_dir / "gate_activation_vs_risk.csv").is_file()


def test_cf_analysis_keeps_last_recovery_block(tmp_path):
    trace = tmp_path / "cf_credit_trace.jsonl"
    base = {
        "agent": "agent_0", "method": "full", "map_number": 5,
        "training_seed": 1, "eval_seed": 7, "dynamic_obs_ttc_risk": 0.0,
        "gate_mean": 0.5, "event": "",
    }
    rows = [
        dict(base, episode=0, step=1, counterfactual_credit=-1.0),
        dict(base, episode=1, step=1, counterfactual_credit=0.25),
        dict(base, episode=0, step=1, counterfactual_credit=1.0),
        dict(base, episode=0, step=2, counterfactual_credit=2.0),
    ]
    trace.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
    with (tmp_path / "episodes.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["map_number", "episode_index", "training_seed", "seed", "steps"],
        )
        writer.writeheader()
        writer.writerows([
            {"map_number": 5, "episode_index": 0, "training_seed": 1, "seed": 7, "steps": 2},
            {"map_number": 5, "episode_index": 1, "training_seed": 1, "seed": 7, "steps": 1},
        ])
    (tmp_path / "episodes.jsonl").write_text(
        "".join(json.dumps(row) + "\n" for row in [
            {"map_number": 5, "episode_index": 0, "training_seed": 1, "seed": 7, "steps": 2},
            {"map_number": 5, "episode_index": 1, "training_seed": 1, "seed": 7, "steps": 1},
        ]),
        encoding="utf-8",
    )
    out_dir = tmp_path / "deduplicated"
    completed = subprocess.run([
        sys.executable, "scripts/analyze_cf_credit_trace.py", str(trace),
        "--out-dir", str(out_dir),
    ], check=True, capture_output=True, text=True)
    assert "duplicate_blocks=1" in completed.stdout
    with (out_dir / "cf_credit_condition_summary.csv").open(
        newline="", encoding="utf-8"
    ) as handle:
        all_row = next(row for row in csv.DictReader(handle) if row["condition"] == "all")
    assert int(all_row["n"]) == 3
    assert abs(float(all_row["credit_mean"]) - (0.25 + 1.0 + 2.0) / 3.0) < 1e-9
