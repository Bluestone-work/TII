#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SEEDS=""
MAX_PARALLEL=2
VARIANTS=all
RUN_TAG=""
DETACH=1
DRY_RUN=0
CONDA_SH="${CONDA_SH:-$HOME/anaconda3/etc/profile.d/conda.sh}"
ROS2_CONDA_ENV="${ROS2_CONDA_ENV:-ros2}"

while (($#)); do
  case "$1" in
    --seeds) SEEDS="$2"; shift 2 ;;
    --parallel) MAX_PARALLEL="$2"; shift 2 ;;
    --variants) VARIANTS="$2"; shift 2 ;;
    --tag) RUN_TAG="$2"; shift 2 ;;
    --foreground) DETACH=0; shift ;;
    --dry-run) DRY_RUN=1; shift ;;
    *) echo "[FATAL] unknown argument: $1" >&2; exit 2 ;;
  esac
done

[[ -n "$SEEDS" ]] || { echo "[FATAL] --seeds is required" >&2; exit 2; }
for seed in $SEEDS; do
  [[ "$seed" =~ ^[123]$ ]] || { echo "[FATAL] seeds must be selected from 1,2,3" >&2; exit 2; }
done
[[ "$MAX_PARALLEL" =~ ^[1-3]$ ]] || { echo "[FATAL] --parallel must be 1, 2, or 3" >&2; exit 2; }
RUN_TAG="${RUN_TAG:-p0_core_$(echo "$SEEDS" | tr ' ' '_')_$(date +%Y%m%d)}"
SAFE_TAG="$(echo "$RUN_TAG" | sed 's/[^A-Za-z0-9_.-]/_/g')"
TRAIN_ROOT="$ROOT/ray_results/$SAFE_TAG"
LOG_ROOT="$ROOT/curriculum_logs/$SAFE_TAG"
PYTHON_BIN=""

set +u
source "$CONDA_SH"
conda activate "$ROS2_CONDA_ENV"
source /opt/ros/humble/setup.bash
[[ -f "$ROOT/install/setup.bash" ]] && source "$ROOT/install/setup.bash"
set -u
PYTHON_BIN="$(command -v python)"

CONDA_SH="$CONDA_SH" ROS2_CONDA_ENV="$ROS2_CONDA_ENV" \
  bash "$ROOT/server_tools/preflight.sh"

declare -a ENVIRONMENT=(
  "MODE=formal"
  "RUN_TAG=$SAFE_TAG"
  "MATRIX=$ROOT/experiments/p0_core_training_matrix.tsv"
  "TRAIN_ROOT=$TRAIN_ROOT"
  "LOG_ROOT=$LOG_ROOT"
  "SEEDS=$SEEDS"
  "MAPS=4 9"
  "STEPS_PER_MAP=400000"
  "MAX_PARALLEL=$MAX_PARALLEL"
  "MAX_RETRIES=2"
  "RESUME_ACROSS_MAPS=1"
  "EARLY_STOP_PATIENCE_ITERS=0"
  "VARIANTS=$VARIANTS"
  "PROTOCOL_VERIFY_SCRIPT=$ROOT/experiments/verify_p0_core_protocol.sh"
  "P0_PROTOCOL_HASH=$ROOT/paper_results/p0_core_v1/source_sha256.txt"
  "PYTHON=$PYTHON_BIN"
  "CONDA_SH=$CONDA_SH"
  "ROS2_CONDA_ENV=$ROS2_CONDA_ENV"
  "RAY_GPU_PER_RUN=0.30"
  "RAY_CPUS_PER_RUN=2"
  "RAY_OBJECT_STORE_MEMORY_MB=256"
  "TRAIN_SAFETY_FILTER=0"
  "ALLOW_SHIELD_DURING_TRAINING=0"
  "MIN_FREE_GB=20"
)

if [[ "$DRY_RUN" == "1" ]]; then
  echo "[ready] training dry-run passed"
  echo "[plan] tag=$SAFE_TAG seeds=[$SEEDS] variants=[$VARIANTS] parallel=$MAX_PARALLEL"
  echo "[plan] maps=[4 9] steps_per_map=400000 resume_across_maps=1"
  exit 0
fi

if [[ "$DETACH" == "0" ]]; then
  cd "$ROOT"
  exec env "${ENVIRONMENT[@]}" bash "$ROOT/experiments/run_formal_training_matrix.sh"
fi

UNIT="p0-${SAFE_TAG}.service"
systemctl --user reset-failed "$UNIT" 2>/dev/null || true
SYSTEMD_ARGS=(
  --user --unit="$UNIT" --collect --working-directory="$ROOT"
)
for item in "${ENVIRONMENT[@]}"; do SYSTEMD_ARGS+=(--setenv="$item"); done
systemd-run "${SYSTEMD_ARGS[@]}" /bin/bash "$ROOT/experiments/run_formal_training_matrix.sh"
echo "[started] unit=$UNIT seeds=[$SEEDS] variants=[$VARIANTS] parallel=$MAX_PARALLEL"
echo "[logs] $LOG_ROOT/master.log"
echo "[monitor] systemctl --user status $UNIT"
