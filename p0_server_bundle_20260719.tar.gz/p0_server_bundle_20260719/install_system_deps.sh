#!/usr/bin/env bash
set -euo pipefail

if [[ "$(. /etc/os-release; echo "$VERSION_ID")" != "22.04" ]]; then
  echo "[FATAL] P0 server bundle expects Ubuntu 22.04" >&2
  exit 2
fi

sudo apt-get update
sudo apt-get install -y \
  rsync \
  python3-colcon-common-extensions \
  gazebo11 \
  ros-humble-gazebo-ros-pkgs \
  ros-humble-simple-launch \
  ros-humble-turtlebot3-gazebo \
  ros-humble-turtlebot3-description \
  ros-humble-nav2-map-server

echo "[complete] system dependencies installed"

