#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONDA_SH="${CONDA_SH:-$HOME/anaconda3/etc/profile.d/conda.sh}"
ROS2_CONDA_ENV="${ROS2_CONDA_ENV:-ros2}"

[[ -f "$CONDA_SH" && -f /opt/ros/humble/setup.bash ]] || {
  echo "[FATAL] missing conda or ROS 2 Humble setup" >&2
  exit 2
}
set +u
source "$CONDA_SH"
conda activate "$ROS2_CONDA_ENV"
source /opt/ros/humble/setup.bash
[[ -f "$ROOT/install/setup.bash" ]] && source "$ROOT/install/setup.bash"
set -u

python - <<'PY'
import sys
import gymnasium
import numpy
import ray
import scipy
import torch
assert sys.version_info[:2] == (3, 10)
print(f"python={sys.version.split()[0]} ray={ray.__version__} torch={torch.__version__}")
print(f"gymnasium={gymnasium.__version__} numpy={numpy.__version__} scipy={scipy.__version__}")
PY
command -v gzserver >/dev/null
command -v ros2 >/dev/null
df -h "$ROOT"
free -h
nvidia-smi --query-gpu=name,driver_version,memory.total,memory.free --format=csv,noheader

PYTHON="$(command -v python)" P0_PROTOCOL_HASH="$ROOT/paper_results/p0_core_v1/source_sha256.txt" \
  bash "$ROOT/experiments/verify_p0_core_protocol.sh"
PYTHON="$(command -v python)" bash "$ROOT/experiments/run_p0_core_pipeline.sh"
echo "[ready] P0 server preflight passed; training remains stopped"

