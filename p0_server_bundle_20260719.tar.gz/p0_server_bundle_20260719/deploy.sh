#!/usr/bin/env bash
set -euo pipefail

BUNDLE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_ROOT="$BUNDLE_ROOT/workspace"
TARGET_ROOT="${TARGET_ROOT:-$HOME/work/multi-robot-exploration-rl}"
ORIGINAL_ROOT="/home/wj/work/multi-robot-exploration-rl"
CONDA_ENV="${CONDA_ENV:-ros2}"
CONDA_SH="${CONDA_SH:-$HOME/anaconda3/etc/profile.d/conda.sh}"
CREATE_CONDA_ENV="${CREATE_CONDA_ENV:-0}"

[[ -d "$SOURCE_ROOT/experiments" && -s "$SOURCE_ROOT/bundle_source_sha256.txt" ]] || {
  echo "[FATAL] incomplete bundle source tree: $SOURCE_ROOT" >&2
  exit 2
}

(
  cd "$SOURCE_ROOT"
  sha256sum --check bundle_source_sha256.txt >/dev/null
) || {
  echo "[FATAL] deployment bundle checksum mismatch" >&2
  exit 3
}

[[ -f /opt/ros/humble/setup.bash ]] || {
  echo "[FATAL] ROS 2 Humble is missing; run install_system_deps.sh first" >&2
  exit 4
}
command -v gzserver >/dev/null || {
  echo "[FATAL] Gazebo Classic is missing; run install_system_deps.sh first" >&2
  exit 4
}
[[ -f "$CONDA_SH" ]] || {
  echo "[FATAL] conda setup not found: $CONDA_SH" >&2
  exit 5
}

set +u
source "$CONDA_SH"
set -u
if [[ "$CREATE_CONDA_ENV" == "1" ]]; then
  conda env remove -n "$CONDA_ENV" -y >/dev/null 2>&1 || true
  conda env create -n "$CONDA_ENV" -f "$BUNDLE_ROOT/environment.yml"
fi
conda activate "$CONDA_ENV"
[[ "$(python -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')" == "3.10" ]] || {
  echo "[FATAL] conda environment must use Python 3.10" >&2
  exit 6
}

if [[ -e "$TARGET_ROOT" ]] && find -H "$TARGET_ROOT" -mindepth 1 -print -quit | grep -q .; then
  echo "[FATAL] target workspace is not empty: $TARGET_ROOT" >&2
  echo "        use a fresh TARGET_ROOT to prevent legacy checkpoint reuse" >&2
  exit 7
fi
mkdir -p "$TARGET_ROOT"
rsync -a --exclude='__pycache__/' --exclude='*.pyc' "$SOURCE_ROOT/" "$TARGET_ROOT/"
rm -f "$TARGET_ROOT/bundle_source_sha256.txt"
mkdir -p "$TARGET_ROOT/server_tools"
install -m 0755 "$BUNDLE_ROOT/preflight.sh" "$TARGET_ROOT/server_tools/preflight.sh"
install -m 0755 "$BUNDLE_ROOT/run_training.sh" "$TARGET_ROOT/server_tools/run_training.sh"
install -m 0755 "$BUNDLE_ROOT/collect_results.sh" "$TARGET_ROOT/server_tools/collect_results.sh"
install -m 0644 "$BUNDLE_ROOT/environment.yml" "$TARGET_ROOT/server_tools/environment.yml"

if [[ "$TARGET_ROOT" != "$ORIGINAL_ROOT" ]]; then
  while IFS= read -r -d '' path; do
    if grep -Iq . "$path" && grep -qF "$ORIGINAL_ROOT" "$path"; then
      sed -i "s|$ORIGINAL_ROOT|$TARGET_ROOT|g" "$path"
    fi
  done < <(find "$TARGET_ROOT" -type f -print0)
fi

HASH_FILE="$TARGET_ROOT/paper_results/p0_core_v1/source_sha256.txt"
HASH_TMP="$(mktemp)"
(
  cd "$TARGET_ROOT"
  while read -r _hash path; do
    sha256sum "$path"
  done <"$HASH_FILE"
) >"$HASH_TMP"
mv "$HASH_TMP" "$HASH_FILE"

set +u
source /opt/ros/humble/setup.bash
set -u
cd "$TARGET_ROOT"
colcon build --symlink-install \
  --packages-select gnn_marl_training start_rl_environment_tb3 \
  --event-handlers console_direct+

CONDA_SH="$CONDA_SH" ROS2_CONDA_ENV="$CONDA_ENV" \
  bash "$TARGET_ROOT/server_tools/preflight.sh"
echo "[complete] deployed P0 workspace=$TARGET_ROOT conda_env=$CONDA_ENV"

