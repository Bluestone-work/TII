#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUN_TAG="${1:?usage: collect_results.sh RUN_TAG [OUTPUT_DIR]}"
OUTPUT_DIR="${2:-$PWD}"
TRAIN_ROOT="$ROOT/ray_results/$RUN_TAG"
LOG_ROOT="$ROOT/curriculum_logs/$RUN_TAG"
STAMP="$(date +%Y%m%d_%H%M%S)"
ARCHIVE="$OUTPUT_DIR/${RUN_TAG}_results_${STAMP}.tar.gz"
META_DIR="$(mktemp -d)"
META="$META_DIR/server_metadata.txt"

[[ -d "$TRAIN_ROOT" && -s "$LOG_ROOT/training_manifest.tsv" ]] || {
  echo "[FATAL] missing training outputs for RUN_TAG=$RUN_TAG" >&2
  exit 2
}
mkdir -p "$OUTPUT_DIR"
{
  date --iso-8601=seconds
  uname -a
  nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader
  sha256sum "$ROOT/paper_results/p0_core_v1/source_sha256.txt"
} >"$META"

tar -czf "$ARCHIVE" \
  -C "$ROOT" \
  "ray_results/$RUN_TAG" \
  "curriculum_logs/$RUN_TAG" \
  "paper_results/p0_core_v1/source_sha256.txt" \
  -C "$META_DIR" server_metadata.txt
rm -rf "$META_DIR"
sha256sum "$ARCHIVE" >"$ARCHIVE.sha256"
echo "[complete] archive=$ARCHIVE"
echo "[checksum] $ARCHIVE.sha256"
