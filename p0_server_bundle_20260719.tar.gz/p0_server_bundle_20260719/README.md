# P0 Server Bundle

This bundle installs and runs the frozen P0/P1 experiment on an Ubuntu 22.04
server. It contains source code and scenario assets, but not legacy checkpoints
or historical results.

## Host prerequisites

- Ubuntu 22.04, NVIDIA driver, and an NVIDIA GPU.
- ROS 2 Humble and Gazebo Classic 11.
- Miniconda/Anaconda with a Python 3.10 environment named `ros2`.
- At least 16 GiB available RAM per two concurrent training chains and 50 GiB
  free disk space.

To install missing ROS packages on a host where the ROS 2 apt repository is
already configured:

```bash
bash install_system_deps.sh
```

To create the Python environment instead of reusing an existing one:

```bash
CREATE_CONDA_ENV=1 bash deploy.sh
```

Otherwise deployment uses the existing `ros2` conda environment:

```bash
bash deploy.sh
```

The default target is `$HOME/work/multi-robot-exploration-rl`. Override it with
`TARGET_ROOT=/path/to/workspace`. The installer relocates path-only constants,
rebuilds the protocol hash, builds both ROS packages, and runs the complete
preflight without starting training.

## Training

For a three-server experiment, assign one training seed per server. This keeps
every method represented on every hardware host:

```bash
cd "$HOME/work/multi-robot-exploration-rl"
./server_tools/run_training.sh --seeds 1 --parallel 2
```

Use seeds 2 and 3 on the other servers. To run all seeds on one server:

```bash
./server_tools/run_training.sh --seeds "1 2 3" --parallel 2
```

The command starts a persistent systemd user service and prints its unit name.
Monitor it with:

```bash
systemctl --user status UNIT_NAME
journalctl --user -u UNIT_NAME -f
tail -f curriculum_logs/RUN_TAG/master.log
```

The server must not run duplicate `(method, seed)` chains. Partition by seed or
variant before starting multiple hosts.

To verify a server assignment without starting it:

```bash
./server_tools/run_training.sh --seeds 1 --parallel 2 --dry-run
```

## Result transfer

After the assigned training chains complete:

```bash
./server_tools/collect_results.sh RUN_TAG
```

This creates one archive containing checkpoints, the training manifest, logs,
the frozen source hash, and server metadata. Copy it back to the evaluation
host. Preserve the `variant/seed/map` directory hierarchy when merging results.
